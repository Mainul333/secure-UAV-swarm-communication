# Experiment harness

`run_all.py` runs the repeated experiments on the Go code in `../reviewer_experiments/protocol_go`, records every run, and writes summary CSVs, LaTeX table bodies, figures with 95% confidence intervals, and `analysis/REPORT.md`. `config.py` points to that folder through relative paths, so nothing needs editing after cloning.

## Run

Linux or WSL2 with Go 1.26 or newer and Python 3.10 or newer:

```bash
pip install -r requirements.txt     # or use a virtual environment
python3 run_all.py --check          # build the tools and run one small trial of each
python3 run_all.py                  # full campaign, about 2.5 hours on an i9-13900HX
```

On Windows with WSL2, double-click `run_in_wsl.bat` instead. It runs the same program inside WSL with a private Python environment (`~/.venvs/uav_revision`). Further options: `--plan` lists the runs and a rough duration, `--only baseline,dkg` runs a subset, `--resume results/campaign_...` continues an interrupted campaign (finished runs are skipped), `--analyze DIR` redoes only the analysis, and `--mock --quick` is a one-minute self-test with stand-in tools whose output is marked MOCK DATA.

## Experiments

| Experiment | What it measures | Runs | Mode |
|---|---|---|---|
| `baseline` | Common-platform comparison of the proposed framework, FHotStuff with FROST, and authenticated PBFT in fair mode: total and critical-path computation, 30 trials per method, scenario, and size | 1,350 | one at a time, shuffled |
| `dkg` | GJKR key generation (`dkgdemo`), 5 runs per size | 25 | one at a time |
| `loss_margin` | Application-layer emulator with f silent followers and threshold t = n − f − u | 120 | parallel (simulated time) |
| `custom` | The original (legacy) computation of `publishedbaselinebench` at n = 100 | 30 | one at a time |

Before the experiments, `tools/install_and_build.sh` adds `cmd/revisionbaselinebench` and `cmd/revisionprotocolbench` to `protocol_go` if they are missing (no existing file is changed) and builds them together with `dkgdemo` into `protocol_go/bin/`.

## Benchmark modes

`revisionbaselinebench -mode legacy` executes the computation of `publishedbaselinebench` unchanged. `-mode fair`, the default, applies the same standard optimizations to both threshold schemes: public key shares are computed once at setup instead of by polynomial evaluation in every share verification, each partial signature is verified once (Kyber's `tbls.Recover` verifies every partial a second time), and FROST nonce commitments are generated in FROST's preprocessing stage outside the timed interval. PBFT is identical in both modes. Both modes also report `critical_path_ms`, the computation on the critical path when every party runs on its own processor. Message deliveries and network bytes come from a per-message byte model applied identically to the three protocols, not from network measurements.

## Outputs

Each campaign writes to `results/campaign_*/`: `analysis/REPORT.md` with the main numbers, `analysis/*_summary.csv` and `analysis/failures.csv`, `analysis/table_*.tex`, `analysis/fig_*.png`, and, for every run, the command, exit code, timing, load average, and full log (`runs.jsonl`, `raw/`), plus the build log and the machine description (`prepare_log.txt`, `environment.json`).
