@echo off
rem Double-click from Windows; the experiments run inside WSL2, where the
rem paper's measurements were made. To use a specific distribution, set
rem DISTRO below, e.g.  set "DISTRO=-d Ubuntu-22.04"
setlocal
set "DISTRO="
cd /d "%~dp0"
where wsl >nul 2>nul || (echo WSL is not installed on this computer. & pause & exit /b 1)
set "WSLDIR="
for /f "usebackq delims=" %%i in (`wsl %DISTRO% -e wslpath -a "%~dp0."`) do set "WSLDIR=%%i"
if not defined WSLDIR (echo Could not translate this folder to a WSL path. & pause & exit /b 1)
echo Running inside WSL in %WSLDIR%
wsl %DISTRO% -e bash -lc "cd '%WSLDIR%' && bash ./run_wsl.sh %*"
echo.
echo Done. Results are in the "results" folder next to this file.
pause
