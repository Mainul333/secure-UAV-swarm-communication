#!/usr/bin/env python3
"""Stand-in tools for `run_all.py --mock`. They print or write results in the
three formats the harness can parse (JSON file, key=value text, CSV file) so
that the complete pipeline can be tested in about a minute.

EVERY NUMBER PRODUCED HERE IS SYNTHETIC. Never report it as a result.
"""
import argparse, csv, json, math, random, sys

N = [4, 10, 20, 50, 100]
# rough shapes only, so the mock plots look sensible
PROC = {"proposed_threshold_bls": [7.2, 17.0, 38.5, 134, 398],
        "wang_fhotstuff_frost_independent": [5.3, 18.4, 59.4, 303, 1122],
        "huo_inspired_authenticated_pbft": [0.93, 5.7, 22.3, 141, 562]}
BYTES = {"proposed_threshold_bls": [4554, 13450, 28788, 77788, 169930],
         "wang_fhotstuff_frost_independent": [10227, 30555, 64694, 168594, 346995],
         "huo_inspired_authenticated_pbft": [6408, 33048, 118408, 681688, 2644488]}
DKG = [89.7, 965, 6669, 95024, 756348]


def interp(table, n):
    return float(math.exp(__import__("numpy").interp(math.log(n), [math.log(x) for x in N], [math.log(v) for v in table])))


def baseline(a):
    rng = random.Random(a.seed * 7919 + a.n + sum(map(ord, a.method)))
    if rng.random() < 0.02:                          # occasional crash to exercise retries
        print("mock: simulated crash", file=sys.stderr)
        sys.exit(3)
    f = (a.n - 1) // 3
    t = a.n - f
    proc = interp(PROC[a.method], a.n) * rng.gauss(1, 0.03)
    deliv = {"proposed_threshold_bls": 2 * (a.n - 1) + t, "wang_fhotstuff_frost_independent": 3 * (a.n - 1) + 3 * t,
             "huo_inspired_authenticated_pbft": (a.n - 1) * (2 * a.n + 1)}[a.method]
    par = {"proposed_threshold_bls": 0.45, "wang_fhotstuff_frost_independent": 0.25,
           "huo_inspired_authenticated_pbft": 0.6}[a.method]
    res = dict(success=True, processing_ms=round(proc, 4),
               total_latency_ms=round(proc + (5000 if a.scenario == "leader_withholding" else 0), 4),
               critical_path_ms=round(proc * par, 4), network_bytes=int(interp(BYTES[a.method], a.n)),
               network_deliveries=deliv, application_messages=deliv // 2, certificate_bytes=104 + 4 * t,
               rejected_invalid=f if a.scenario == "malformed_followers" else 0,
               signature_operations=2 * t + 2, verification_operations=3 * t + 2)
    with open(a.out, "w") as fh:
        json.dump(res, fh)
    print("mock baseline done")


def dkg(a):
    rng = random.Random(a.seed * 104729 + a.n)
    n = a.n
    ms = interp(DKG, n) * rng.lognormvariate(0, 0.08)
    print(f"gjkr_status=passed qual_size={n}")
    print(f"dkg_ms={ms:.3f}")
    print(f"deal_objects={n * (n - 1)} response_objects={n * (n - 1)} response_deliveries={n * (n - 1) ** 2} "
          f"secret_commit_deliveries={n * (n - 1)}")
    print(f"partial_sign_verify_ms={2.5 * n * rng.gauss(1, 0.03):.3f} reconstruction_ms={2.15 * n * rng.gauss(1, 0.03):.3f} "
          f"final_verification_ms={0.8 * rng.gauss(1, 0.03):.3f}")


def emulator(a):
    rng = random.Random(a.seed * 31337 + a.n * 7 + a.t)
    loss = {"ideal": 0.0, "wifi_light": 0.0099, "wifi_stressed": 0.09}[a.profile]
    q = (1 - loss) ** 2
    succ, views, msgs, drops = 0, 0, 0, 0
    for _ in range(a.rounds):
        if a.scenario == "benign":
            ok, v = True, 1
        else:
            answers = 1 + sum(rng.random() < q for _ in range(a.n - a.f - 1))
            ok, v = answers >= a.t, (1 if answers >= a.t else 2)
        m = 3 * (a.n - 1)
        d = sum(rng.random() < loss for _ in range(m))
        succ += ok; views += v; msgs += m - d; drops += d
    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["rounds", "successes", "mean_views", "logical_messages", "dropped_messages", "mean_latency_ms"])
        w.writerow([a.rounds, succ, views / a.rounds, msgs, drops, 3.0 if loss == 0 else 13.5])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="tool", required=True)
    b = sub.add_parser("baseline"); b.add_argument("--method"); b.add_argument("--n", type=int)
    b.add_argument("--scenario"); b.add_argument("--seed", type=int); b.add_argument("--out")
    k = sub.add_parser("dkg"); k.add_argument("--n", type=int); k.add_argument("--seed", type=int)
    e = sub.add_parser("emulator")
    for x in ["--n", "--f", "--t", "--seed", "--rounds"]:
        e.add_argument(x, type=int)
    e.add_argument("--profile"); e.add_argument("--scenario"); e.add_argument("--out")
    a = ap.parse_args()
    {"baseline": baseline, "dkg": dkg, "emulator": emulator}[a.tool](a)
