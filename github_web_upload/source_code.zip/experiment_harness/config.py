# =============================================================================
# config.py -- points to ../reviewer_experiments/protocol_go in this repository.
# Check the setup with:  python3 run_all.py --check   (Windows: run_in_wsl.bat --check)
#
# What happens before the experiments ("prepare"): tools/install_and_build.sh
# copies two NEW commands into protocol_go/cmd/ (revisionbaselinebench and
# revisionprotocolbench; no existing file is changed) and builds them together
# with dkgdemo into protocol_go/bin/.
#
# Placeholders filled in by run_all.py:
#   {repo} {harness} {python}  folders and the Python interpreter (quoted)
#   {n} {f} {t} {u} {method} {scenario} {profile} {trial} {run} {seed} {rounds}
#   {run_dir}  a fresh folder for each run (quoted)
# =============================================================================

import os
_HERE = os.path.dirname(os.path.abspath(__file__))
REPO_DIR = os.path.normpath(os.path.join(_HERE, "..", "reviewer_experiments", "protocol_go"))
MERGE_SCRIPT = os.path.normpath(os.path.join(_HERE, "..", "reviewer_experiments", "scripts", "merge_dkg_results.py"))


def kv(*names):
    """Regexes for lines such as 'dkg_ms=12.3'."""
    return {n: rf"^{n}\s*[=:]\s*([-+0-9.eE]+|true|false|passed|failed)\s*$" for n in names}


def baseline_command(method, mode="fair"):
    # One method, one measured trial, one discarded warm-up run per process.
    # {seed} = 1000 + trial selects a different deterministic payload per trial.
    return (f"./bin/revisionbaselinebench -mode {mode} -methods {method} -nodes {{n}} "
            "-scenarios {scenario} -trials 1 -first-trial {seed} -warmup 1 -output-dir {run_dir}")


BASELINE_PARSE = {"type": "csv", "file": "published_baseline_trials.csv",
                  "rename": {"certificate_bytes_actual": "certificate_bytes"}}

CONFIG = {
    "repo_dir": REPO_DIR,
    "results_dir": "results",
    "windows_shell": "cmd",
    "prepare": "bash {harness}/tools/install_and_build.sh",
    # loss_margin first: it runs in parallel and must not overlap the timing runs
    "order": ["loss_margin", "baseline", "dkg", "custom"],

    # ------------------------------------------------------------- 1. baseline
    # Common-platform comparison. Mode "fair": the same standard optimizations
    # for both threshold schemes (public key shares computed once, each partial
    # verified once, FROST nonces preprocessed). Also records critical_path_ms.
    "baseline": {
        "enabled": True,
        "trials": 30,
        "warmup_runs": 1,
        "nodes": [4, 10, 20, 50, 100],
        "scenarios": ["normal", "leader_withholding", "malformed_followers"],
        "methods": {m: baseline_command(m) for m in [
            "proposed_threshold_bls", "wang_fhotstuff_frost_independent", "huo_inspired_authenticated_pbft"]},
        "parse": BASELINE_PARSE,
        "timeout_s": 900,
        "retries": 1,
    },

    # ------------------------------------------------------------- 2. dkg
    # Repeated GJKR key generation, 5 runs per size.
    # 5 runs of n=100 take about 65 minutes.
    "dkg": {
        "enabled": True,
        "runs": 5,
        "nodes": [4, 10, 20, 50, 100],
        "command": "{python} {harness}/tools/dkg_kv.py --bin ./bin/dkgdemo --merge-script "
                   + f"'{MERGE_SCRIPT}'" + " -n {n} -t {t} --log {run_dir}/dkg_output.txt",
        "parse": {"type": "regex", "patterns": dict(
            kv("dkg_ms", "qual_size", "deal_objects", "response_objects", "response_deliveries",
               "secret_commit_deliveries", "partial_sign_verify_ms", "reconstruction_ms",
               "final_verification_ms"),
            success=r"^success=(\w+)$")},
        "timeout_s": 3600,
        "retries": 1,
    },

    # ------------------------------------------------------------- 3. loss_margin
    # Loss margin: the application-layer
    # emulator with f silent followers and t = n - f - u. Simulated time with
    # fixed seeds, so the results are identical on every computer.
    "loss_margin": {
        "enabled": True,
        "n": 100,
        "configs": [[33, 0], [30, 4], [25, 12]],     # [f, u]
        "profiles": ["ideal", "wifi_light", "wifi_stressed"],
        "seeds": 10,
        "rounds": 50,
        "command": "./bin/revisionprotocolbench -sizes {n} -profiles {profile} -scenarios {scenario} "
                   "-rounds {rounds} -seed-count 1 -seed-start {seed} -fault-bound {f} -loss-margin {u} "
                   "-output {run_dir}/protocol.csv -json {run_dir}/protocol.json",
        "parse": {"type": "csv", "file": "protocol.csv"},
        "workers": 0,
        "timeout_s": 1800,
        "retries": 1,
    },

    # ------------------------------------------------------------- 4. custom
    # Documents the published measurement: the same benchmark in "legacy" mode
    # (the computation of publishedbaselinebench) for n = 100, normal operation.
    "custom": {
        "enabled": True,
        "items": [
            {"name": f"legacy_{m}_n100",
             "command": baseline_command(m, "legacy").replace("{n}", "100").replace("{scenario}", "normal"),
             "repeats": 10, "parse": BASELINE_PARSE, "required": ["processing_ms", "critical_path_ms"]}
            for m in ["proposed_threshold_bls", "wang_fhotstuff_frost_independent", "huo_inspired_authenticated_pbft"]
        ],
    },

    "estimates_s": {
        "baseline_overhead_s": 0.5,
        "baseline_per_n_s": {"4": 0.1, "10": 0.1, "20": 0.2, "50": 0.6, "100": 1.5},
        "dkg_s": {"4": 1, "10": 2, "20": 8, "50": 100, "100": 780},
        "loss_margin_run_s": 5,
        "custom_run_s": 4,
    },
}
