#!/usr/bin/env python3
"""Single entry point for the command-certification experiments.

    python3 run_all.py                    preflight check, all experiments, analysis
    python3 run_all.py --mock --quick     self-test with stand-in tools (MOCK data, ~1 min)
    python3 run_all.py --plan             list the runs and the estimated duration
    python3 run_all.py --check            preflight only (one small run per tool)
    python3 run_all.py --resume DIR       continue an interrupted campaign
    python3 run_all.py --only baseline,dkg
    python3 run_all.py --analyze DIR      redo the analysis of a finished campaign

Experiments (see config.py):
  baseline     baseline comparison, N trials per condition          (sequential: timing)
  dkg          repeated GJKR key generation                         (sequential: timing)
  loss_margin  silent-follower runs with a loss margin u_e > 0      (parallel: virtual time)
  custom       any further command repeated R times, e.g. PX4 runs  (sequential)
"""
import argparse, csv, datetime as dt, importlib.util, json, math, os, platform, random, re
import hashlib, shlex, signal, subprocess, sys, threading, time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

HERE = os.path.dirname(os.path.abspath(__file__))
IS_WIN = os.name == "nt"
RUNNING, RUNNING_LOCK = set(), threading.Lock()   # child processes, killed on Ctrl+C
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Metrics each tool must report (after renaming); everything else is optional.
REQUIRED = {
    "baseline": ["processing_ms", "network_bytes", "network_deliveries"],
    "dkg": ["dkg_ms"],
    "loss_margin": ["rounds", "successes"],
    "custom": [],
}
OPTIONAL = {
    "baseline": ["success", "total_latency_ms", "critical_path_ms", "application_messages",
                 "certificate_bytes", "rejected_invalid", "signature_operations",
                 "verification_operations", "failure_reason"],
    "dkg": ["success", "qual_size", "deal_objects", "response_objects", "response_deliveries",
            "secret_commit_deliveries", "partial_sign_verify_ms", "reconstruction_ms",
            "final_verification_ms"],
    "loss_margin": ["mean_latency_ms", "p95_latency_ms", "mean_views", "logical_messages",
                    "dropped_messages", "timeout_certificates"],
    "custom": [],
}
TIMING = {"baseline": True, "dkg": True, "loss_margin": False, "custom": True}
DEFAULT_ORDER = ["loss_margin", "baseline", "dkg", "custom"]


# ----------------------------------------------------------------------------- config
def load_config(mock):
    if mock:
        return mock_config()
    path = os.path.join(HERE, "config.py")
    spec = importlib.util.spec_from_file_location("user_config", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.CONFIG


def mock_config():
    py, tool = quote(sys.executable), quote(os.path.join(HERE, "mock_tools.py"))
    return {
        "repo_dir": HERE, "results_dir": os.path.join(HERE, "results"), "mock": True,
        "order": DEFAULT_ORDER,
        "baseline": {
            "enabled": True, "trials": 30, "warmup_runs": 1, "nodes": [4, 10, 20, 50, 100],
            "scenarios": ["normal", "leader_withholding", "malformed_followers"],
            "methods": {m: f"{py} {tool} baseline --method {m} --n {{n}} --scenario {{scenario}} "
                           f"--seed {{seed}} --out {{result_path}}"
                        for m in ["proposed_threshold_bls", "wang_fhotstuff_frost_independent",
                                  "huo_inspired_authenticated_pbft"]},
            "parse": {"type": "json"}, "timeout_s": 120, "retries": 1,
        },
        "dkg": {
            "enabled": True, "runs": 5, "nodes": [4, 10, 20, 50, 100],
            "command": f"{py} {tool} dkg --n {{n}} --seed {{seed}}",
            "parse": {"type": "regex", "patterns": {
                "dkg_ms": r"dkg_ms=([0-9.]+)", "success": r"gjkr_status=(\w+)",
                "qual_size": r"qual_size=(\d+)", "deal_objects": r"deal_objects=(\d+)",
                "response_objects": r"response_objects=(\d+)",
                "response_deliveries": r"response_deliveries=(\d+)",
                "secret_commit_deliveries": r"secret_commit_deliveries=(\d+)",
                "partial_sign_verify_ms": r"partial_sign_verify_ms=([0-9.]+)",
                "reconstruction_ms": r"reconstruction_ms=([0-9.]+)",
                "final_verification_ms": r"final_verification_ms=([0-9.]+)"}},
            "timeout_s": 120, "retries": 1,
        },
        "loss_margin": {
            "enabled": True, "n": 100, "configs": [[33, 0], [30, 4], [25, 12]],
            "profiles": ["ideal", "wifi_light", "wifi_stressed"], "seeds": 10, "rounds": 50,
            "command": f"{py} {tool} emulator --n {{n}} --f {{f}} --t {{t}} --profile {{profile}} "
                       f"--scenario {{scenario}} --seed {{seed}} --rounds {{rounds}} --out {{result_path}}",
            "parse": {"type": "csv"}, "workers": 0, "timeout_s": 120, "retries": 1,
        },
        "custom": {"enabled": False, "items": []},
    }


def quote(s):
    return '"%s"' % s if IS_WIN else shlex.quote(s)


def check_config(cfg, only):
    problems = []
    for exp in experiments_enabled(cfg, only):
        e = cfg[exp]
        cmds = list(e["methods"].values()) if exp == "baseline" else \
            [i["command"] for i in e.get("items", [])] if exp == "custom" else [e["command"]]
        for c in cmds:
            if "TODO" in c:
                problems.append(f"{exp}: command still contains TODO -> {c[:90]}")
    return problems


def experiments_enabled(cfg, only):
    order = cfg.get("order", DEFAULT_ORDER)
    return [x for x in order if cfg.get(x, {}).get("enabled") and (not only or x in only)]


# ----------------------------------------------------------------------------- planning
def fault_bound(n):
    return (n - 1) // 3


def plan(cfg, exp, quick=False, trials_override=None):
    e, runs, seed0 = cfg[exp], [], 20261121
    if exp == "baseline":
        trials = trials_override or (3 if quick else e["trials"])
        for m in e["methods"]:
            for sc in e["scenarios"]:
                for n in e["nodes"]:
                    f = fault_bound(n)
                    for k in range(trials):
                        runs.append(dict(experiment=exp, method=m, scenario=sc, n=n, f=f, u=0,
                                         t=n - f, trial=k, seed=1000 + k))
        random.Random(seed0).shuffle(runs)   # interleave methods and sizes against drift
        warm = [dict(experiment=exp, method=m, scenario="normal", n=n, f=fault_bound(n), u=0,
                     t=n - fault_bound(n), trial=-1 - w, seed=999, warmup=True)
                for m in e["methods"] for n in e["nodes"] for w in range(e.get("warmup_runs", 0))]
        runs = warm + runs
    elif exp == "dkg":
        reps = 2 if quick else e["runs"]
        for n in e["nodes"]:
            f = fault_bound(n)
            for k in range(reps):
                runs.append(dict(experiment=exp, n=n, f=f, u=0, t=n - f, run=k + 1, seed=2000 + k))
        random.Random(seed0 + 1).shuffle(runs)
    elif exp == "loss_margin":
        n, seeds, rounds = e["n"], (3 if quick else e["seeds"]), (20 if quick else e["rounds"])
        for f, u in e["configs"]:
            assert n >= 3 * f + 2 * u + 1, f"n={n} violates n >= 3f+2u+1 for f={f}, u={u}"
            for p in e["profiles"]:
                for s in range(1, seeds + 1):
                    runs.append(dict(experiment=exp, n=n, f=f, u=u, t=n - f - u, profile=p,
                                     scenario="follower_silence_f", seed=s, rounds=rounds))
        f0 = fault_bound(n)
        for p in e["profiles"]:      # benign runs measure the loss rate of each profile
            for s in range(1, seeds + 1):
                runs.append(dict(experiment=exp, n=n, f=f0, u=0, t=n - f0, profile=p,
                                 scenario="benign", seed=s, rounds=rounds))
    elif exp == "custom":
        for item in e.get("items", []):
            for k in range(2 if quick else item.get("repeats", 3)):
                runs.append(dict(experiment=exp, item=item["name"], trial=k, seed=3000 + k))
    for r in runs:
        r["key"] = run_key(r)
    return runs


def run_key(r):
    skip = {"experiment", "key", "warmup"}
    parts = [f"{k}={r[k]}" for k in sorted(r) if k not in skip]
    return r["experiment"] + "|" + "|".join(parts)


def slug(s):
    short = re.sub(r"[^A-Za-z0-9_.=-]+", "_", s)[:60].rstrip("._")
    return short + "_" + hashlib.sha1(s.encode()).hexdigest()[:10]


def command_for(cfg, r):
    e = cfg[r["experiment"]]
    if r["experiment"] == "baseline":
        tpl = e["methods"][r["method"]]
    elif r["experiment"] == "custom":
        tpl = next(i for i in e["items"] if i["name"] == r["item"])["command"]
    else:
        tpl = e["command"]
    return tpl


def parse_spec(cfg, r):
    if r["experiment"] == "custom":
        return next(i for i in cfg["custom"]["items"] if i["name"] == r["item"]).get("parse", {"type": "regex", "patterns": {}})
    return cfg[r["experiment"]]["parse"]


# ----------------------------------------------------------------------------- execution
def to_value(v):
    if isinstance(v, (int, float, bool)) or v is None:
        return v
    s = str(v).strip()
    low = s.lower()
    if low in ("true", "passed", "ok", "success", "yes"):
        return True
    if low in ("false", "failed", "fail", "no", "error"):
        return False
    try:
        x = float(s)
        return int(x) if x.is_integer() and "." not in s and "e" not in low else x
    except ValueError:
        return s


def parse_metrics(spec, text, result_path):
    t, data = spec.get("type", "regex"), {}
    try:
        if t == "json":
            with open(result_path, encoding="utf-8-sig") as fh:
                data = json.load(fh)
        elif t == "json_stdout":
            lines = [ln for ln in text.splitlines() if ln.strip().startswith("{")]
            data = json.loads(lines[-1]) if lines else {}
        elif t == "csv":
            with open(result_path, newline="", encoding="utf-8-sig") as fh:
                rows = list(csv.DictReader(fh))
            data = rows[-1] if rows else {}
        elif t == "regex":
            for k, pat in spec.get("patterns", {}).items():
                hits = re.findall(pat, text, re.M)
                if hits:
                    data[k] = hits[-1] if isinstance(hits[-1], str) else hits[-1][0]
    except (OSError, ValueError, json.JSONDecodeError) as ex:
        data = {"_parse_error": str(ex)}
    ren = spec.get("rename", {})
    return {ren.get(k, k): to_value(v) for k, v in data.items()}


def kill_tree(p):
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            os.killpg(p.pid, signal.SIGKILL)
    except Exception:
        pass


def execute(cmd, cwd, timeout, log_path, shell_name="auto"):
    with open(log_path, "w", encoding="utf-8") as log:
        log.write(f"$ {cmd}\n")
        log.flush()
        if IS_WIN:
            flags = subprocess.CREATE_NEW_PROCESS_GROUP
            if shell_name == "powershell":
                p = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
                                     cwd=cwd, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
            else:
                p = subprocess.Popen(cmd, shell=True, cwd=cwd, stdout=log, stderr=subprocess.STDOUT,
                                     creationflags=flags)
        else:
            p = subprocess.Popen(cmd, shell=True, cwd=cwd, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True, executable="/bin/bash")
        with RUNNING_LOCK:
            RUNNING.add(p)
        deadline, timed_out, rc = time.time() + timeout, False, None
        try:
            while True:                       # short waits keep Ctrl+C responsive on Windows
                try:
                    rc = p.wait(timeout=0.5)
                    break
                except subprocess.TimeoutExpired:
                    if time.time() > deadline:
                        kill_tree(p)
                        p.wait()
                        timed_out, rc = True, None
                        break
        except KeyboardInterrupt:
            kill_tree(p)
            raise
        finally:
            with RUNNING_LOCK:
                RUNNING.discard(p)
    with open(log_path, encoding="utf-8", errors="replace") as fh:
        return rc, timed_out, fh.read()


def machine_load():
    """1-minute load average on Linux; on Windows the CPU use in percent (needs psutil)."""
    if hasattr(os, "getloadavg"):
        return round(os.getloadavg()[0], 2)
    try:
        import psutil
        return round(psutil.cpu_percent(interval=0.2) / 100.0 * (os.cpu_count() or 1), 2)
    except Exception:
        return None


def run_one(cfg, r, base_dir):
    exp = r["experiment"]
    e = cfg[exp]
    spec = parse_spec(cfg, r)
    ext = {"json": ".json", "csv": ".csv"}.get(spec.get("type"), ".txt")
    run_dir = os.path.join(base_dir, "raw", exp, slug(r["key"]))
    os.makedirs(run_dir, exist_ok=True)
    result_path = os.path.join(run_dir, spec.get("file", "result" + ext))
    # paths are quoted automatically, so folders with spaces or parentheses work;
    # the *_raw variants are unquoted for commands that need to build paths themselves
    fields = dict(r, repo=quote(cfg["repo_dir"]), run_dir=quote(run_dir), result_path=quote(result_path),
                  harness=quote(HERE), python=quote(sys.executable),
                  repo_raw=cfg["repo_dir"], run_dir_raw=run_dir, result_path_raw=result_path)
    cmd = command_for(cfg, r).format_map(fields)
    required = list(REQUIRED[exp]) + ([] if exp != "custom" else
                                       next(i for i in e["items"] if i["name"] == r["item"]).get("required", []))
    attempts, out = 0, None
    while attempts <= e.get("retries", 1):
        attempts += 1
        if os.path.exists(result_path):
            os.remove(result_path)
        load = machine_load()
        t0 = time.time()
        rc, timed_out, text = execute(cmd, cfg["repo_dir"], e.get("timeout_s", 3600),
                                      os.path.join(run_dir, f"log_attempt{attempts}.txt"),
                                      cfg.get("windows_shell", "cmd"))
        wall = time.time() - t0
        m = parse_metrics(spec, text, result_path)
        succ = m.get("success")
        if timed_out:
            status, reason = "exec_error", "timeout"
        elif succ is False:
            status, reason = "protocol_failure", str(m.get("failure_reason", "no certificate reported"))
        elif rc != 0 and succ is None:
            status, reason = "exec_error", f"exit code {rc}"
        else:
            missing = [k for k in required if k not in m]
            status, reason = ("ok", "") if not missing else ("exec_error", "missing metrics: " + ",".join(missing))
        out = dict(r, command=cmd, status=status, failure_reason=reason, exit_code=rc,
                   timed_out=timed_out, attempts=attempts, wall_s=round(wall, 3), loadavg_1m=load,
                   finished=dt.datetime.now().isoformat(timespec="seconds"), metrics=m,
                   log_tail=text[-1500:] if status != "ok" else "")
        if status != "exec_error":
            break
    return out


class State:
    def __init__(self, path):
        self.path, self.lock, self.done = path, threading.Lock(), {}
        if os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                for ln in fh:
                    try:
                        rec = json.loads(ln)
                    except json.JSONDecodeError:
                        continue
                    if rec.get("status") != "exec_error":
                        self.done[rec["key"]] = rec

    def add(self, rec):
        with self.lock:
            with open(self.path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, default=str) + "\n")
            if rec["status"] != "exec_error":
                self.done[rec["key"]] = rec


def fmt_dur(s):
    s = int(max(s, 0))
    return f"{s // 3600}h{(s % 3600) // 60:02d}m" if s >= 3600 else f"{s // 60}m{s % 60:02d}s"


def describe(r):
    keys = [k for k in ("method", "item", "scenario", "profile", "n", "f", "u", "t", "trial", "run", "seed") if k in r]
    return " ".join(f"{k}={r[k]}" for k in keys)


def run_experiment(cfg, exp, runs, state, base_dir):
    e = cfg[exp]
    todo = [r for r in runs if r["key"] not in state.done or r.get("warmup")]
    warm = [r for r in todo if r.get("warmup")]
    todo = [r for r in todo if not r.get("warmup")]
    if not todo:
        print(f"[{exp}] all {len(runs)} runs already completed")
        return
    if warm and len([r for r in runs if not r.get("warmup") and r["key"] in state.done]) == 0:
        print(f"[{exp}] {len(warm)} warm-up runs (discarded)")
        for r in warm:
            run_one(cfg, r, os.path.join(base_dir, "warmup"))
    parallel = not TIMING[exp]
    workers = (e.get("workers") or max(1, (os.cpu_count() or 2) - 1)) if parallel else 1
    print(f"[{exp}] {len(todo)} runs, {'parallel x' + str(workers) if parallel else 'sequential (timing-sensitive)'}")
    t_start, done, lock = time.time(), [0], threading.Lock()

    def report(rec):
        with lock:
            done[0] += 1
            el = time.time() - t_start
            eta = el / done[0] * (len(todo) - done[0])
            m = rec["metrics"]
            main = next((f"{k}={m[k]}" for k in ("processing_ms", "dkg_ms", "successes") if k in m), "")
            flag = {"ok": "ok", "protocol_failure": "PROTOCOL FAILURE", "exec_error": "EXEC ERROR"}[rec["status"]]
            print(f"  [{exp} {done[0]}/{len(todo)}] {describe(rec)} -> {main} {flag}"
                  f"{' (' + rec['failure_reason'] + ')' if rec['failure_reason'] else ''}  ETA {fmt_dur(eta)}", flush=True)

    if parallel:
        pool = ThreadPoolExecutor(max_workers=workers)
        pending = {pool.submit(run_one, cfg, r, base_dir) for r in todo}
        try:
            while pending:
                finished, pending = wait(pending, timeout=0.5, return_when=FIRST_COMPLETED)
                for fu in finished:
                    rec = fu.result()
                    state.add(rec)
                    report(rec)
        except KeyboardInterrupt:
            for fu in pending:
                fu.cancel()
            with RUNNING_LOCK:
                for p in list(RUNNING):
                    kill_tree(p)
            pool.shutdown(wait=False)
            raise
        pool.shutdown(wait=True)
    else:
        for r in todo:
            rec = run_one(cfg, r, base_dir)
            state.add(rec)
            report(rec)


def preflight(cfg, exps, base_dir):
    print("Preflight: one small run per tool, checking that every required metric is parsed\n")
    ok = True
    for exp in exps:
        runs = plan(cfg, exp, quick=True)
        picks = []
        if exp == "baseline":
            n0 = min(cfg[exp]["nodes"])
            for m in cfg[exp]["methods"]:
                picks.append(next(r for r in runs if r.get("method") == m and r["n"] == n0
                                  and r["scenario"] == "normal" and not r.get("warmup")))
        elif exp == "dkg":
            picks.append(min(runs, key=lambda r: r["n"]))
        elif exp == "loss_margin":
            picks.append(next(r for r in runs if r["scenario"] == "follower_silence_f"))
        else:
            seen = set()
            for r in runs:
                if r["item"] not in seen:
                    seen.add(r["item"])
                    picks.append(r)
        for r in picks:
            rec = run_one(cfg, r, os.path.join(base_dir, "preflight"))
            req = REQUIRED[exp]
            found = sorted(rec["metrics"])
            missing = [k for k in req if k not in rec["metrics"]]
            opt_missing = [k for k in OPTIONAL[exp] if k not in rec["metrics"]]
            good = rec["status"] == "ok"
            ok &= good
            print(f"  {'PASS' if good else 'FAIL'}  {exp}: {describe(r)}  ({rec['wall_s']} s)")
            parsed = ", ".join("%s=%s" % (k, rec["metrics"][k]) for k in found) or "nothing"
            print("        parsed: " + parsed)
            if missing:
                print(f"        missing REQUIRED: {', '.join(missing)}")
            if opt_missing:
                print(f"        missing optional: {', '.join(opt_missing)}")
            if not good:
                print(f"        reason: {rec['failure_reason']}\n        command: {rec['command']}")
                print("        last output lines:\n" + "\n".join("          | " + ln for ln in rec["log_tail"].splitlines()[-12:]))
    print()
    return ok


def prepare(cfg, base):
    """Runs the optional one-time preparation command (e.g. building the tools)."""
    cmd = cfg.get("prepare")
    if not cmd:
        return True
    cmd = cmd.format_map(dict(repo=quote(cfg["repo_dir"]), harness=quote(HERE), python=quote(sys.executable)))
    print("Preparing the tools (build)...")
    log = os.path.join(base, "prepare_log.txt")
    rc, timed_out, text = execute(cmd, cfg["repo_dir"], cfg.get("prepare_timeout_s", 1800), log,
                                  cfg.get("windows_shell", "cmd"))
    tail = "\n".join("  | " + ln for ln in text.strip().splitlines()[-8:])
    if rc != 0 or timed_out:
        print(f"Preparation failed (exit code {rc}). Last output:\n{tail}\nFull log: {log}")
        return False
    print(tail + "\n")
    return True


def environment_info(cfg):
    def sh(args):
        try:
            return subprocess.run(args, capture_output=True, text=True, timeout=30).stdout.strip()
        except Exception:
            return ""
    cpu, mem = platform.processor(), ""
    if os.path.exists("/proc/cpuinfo"):
        with open("/proc/cpuinfo") as fh:
            cpu = next((ln.split(":", 1)[1].strip() for ln in fh if ln.startswith("model name")), cpu)
        with open("/proc/meminfo") as fh:
            mem = next((ln.strip() for ln in fh if ln.startswith("MemTotal")), "")
    elif IS_WIN:
        ps = ["powershell", "-NoProfile", "-Command"]
        cpu = sh(ps + ["(Get-CimInstance Win32_Processor).Name"]) or cpu
        b = sh(ps + ["(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory"])
        mem = f"{int(b) / 2**30:.1f} GiB" if b.isdigit() else ""
    repo = cfg["repo_dir"]
    return dict(started=dt.datetime.now().isoformat(timespec="seconds"), host=platform.node(),
                platform=platform.platform(), python=sys.version.split()[0], cpu_model=cpu,
                cpu_count=os.cpu_count(), memory=mem, go_version=sh(["go", "version"]),
                repo_dir=repo, repo_commit=sh(["git", "-C", repo, "rev-parse", "HEAD"]),
                repo_dirty=bool(sh(["git", "-C", repo, "status", "--porcelain"])),
                mock=bool(cfg.get("mock")))


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mock", action="store_true", help="use the stand-in tools (MOCK data, for testing only)")
    ap.add_argument("--quick", action="store_true", help="few trials, for testing the pipeline")
    ap.add_argument("--plan", action="store_true", help="print the run plan and exit")
    ap.add_argument("--check", action="store_true", help="run the preflight check only")
    ap.add_argument("--skip-preflight", action="store_true")
    ap.add_argument("--only", default="", help="comma-separated subset: baseline,dkg,loss_margin,custom")
    ap.add_argument("--trials", type=int, default=None, help="override baseline trials per condition")
    ap.add_argument("--resume", default=None, help="campaign directory to continue")
    ap.add_argument("--analyze", default=None, help="campaign directory to analyze only")
    a = ap.parse_args()

    missing = [m for m in ("numpy", "pandas", "scipy", "matplotlib") if importlib.util.find_spec(m) is None]
    if missing:
        print("Missing Python packages: " + ", ".join(missing))
        print("Install them with:  python -m pip install -r requirements.txt"
              + ("" if IS_WIN else "   (on Ubuntu first: sudo apt install python3-pip)"))
        sys.exit(2)
    try:                                  # fail now, not after hours of experiments
        import analysis  # noqa: F401
    except Exception as ex:
        print(f"The analysis libraries cannot be loaded: {type(ex).__name__}: {ex}")
        print("On WSL, start the program with run_in_wsl.bat (it uses a private environment).")
        sys.exit(2)
    if a.analyze:
        import analysis
        analysis.analyze(a.analyze)
        return
    if a.resume and os.path.exists(os.path.join(a.resume, "options.json")):
        with open(os.path.join(a.resume, "options.json"), encoding="utf-8") as fh:
            saved = json.load(fh)          # a resumed campaign keeps its original plan
        a.mock, a.quick, a.trials, a.only = saved["mock"], saved["quick"], saved["trials"], saved["only"]
    cfg = load_config(a.mock)
    cfg["repo_dir"] = os.path.abspath(os.path.expanduser(cfg["repo_dir"]))
    if not os.path.isabs(cfg["results_dir"]):
        cfg["results_dir"] = os.path.join(HERE, cfg["results_dir"])
    if not os.path.isdir(cfg["repo_dir"]) and not a.plan:
        print(f"REPO_DIR does not exist: {cfg['repo_dir']}  (set it at the top of config.py)")
        sys.exit(2)
    only = [x.strip() for x in a.only.split(",") if x.strip()]
    exps = experiments_enabled(cfg, only)
    problems = check_config(cfg, only)
    if problems and not a.plan:
        print("config.py is not filled in yet:\n  " + "\n  ".join(problems))
        print("\nEdit config.py (see README.md), or try the pipeline with:  python3 run_all.py --mock --quick")
        sys.exit(2)

    plans = {x: plan(cfg, x, a.quick, a.trials) for x in exps}
    if a.plan:
        est = cfg.get("estimates_s", {})
        total = 0.0
        for x, runs in plans.items():
            secs = sum(est_seconds(est, r) for r in runs)
            if not TIMING[x]:
                secs /= max(1, (os.cpu_count() or 2) - 1)
            total += secs
            print(f"{x:12s} {len(runs):6d} runs   ~{fmt_dur(secs)}")
        print(f"{'total':12s} {sum(len(r) for r in plans.values()):6d} runs   ~{fmt_dur(total)}  (rough; see estimates_s in config.py)")
        return

    if a.resume:
        base = a.resume
    else:
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        base = os.path.join(cfg["results_dir"], ("MOCK_" if cfg.get("mock") else "") + "campaign_" + stamp)
    os.makedirs(base, exist_ok=True)
    with open(os.path.join(base, "environment.json"), "w", encoding="utf-8") as fh:
        json.dump(environment_info(cfg), fh, indent=2)
    if not a.resume:
        with open(os.path.join(base, "options.json"), "w", encoding="utf-8") as fh:
            json.dump(dict(mock=a.mock, quick=a.quick, trials=a.trials, only=a.only), fh)
    with open(os.path.join(base, "config_used.json"), "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, indent=2, default=str)
    print(f"Campaign directory: {base}\n")

    if not cfg.get("mock") and not prepare(cfg, base):
        sys.exit(3)
    if not a.skip_preflight and not a.resume:
        if not preflight(cfg, exps, base):
            print("Preflight failed. Fix config.py (commands or parse patterns) and run again; "
                  "nothing else was started.")
            sys.exit(3)
        if a.check:
            return
    elif a.check:
        return

    state = State(os.path.join(base, "runs.jsonl"))
    t0 = time.time()
    try:
        for x in exps:
            run_experiment(cfg, x, plans[x], state, base)
    except KeyboardInterrupt:
        print(f"\nInterrupted. Continue later with:  python3 run_all.py --resume {base}")
        sys.exit(130)
    print(f"\nAll experiments finished in {fmt_dur(time.time() - t0)}. Analyzing...\n")
    import analysis
    analysis.analyze(base)


def est_seconds(est, r):
    exp = r["experiment"]
    if exp == "baseline":
        base = est.get("baseline_overhead_s", 2.0) + est.get("baseline_per_n_s", {}).get(str(r["n"]), 1.0)
        return base + (5.0 if r["scenario"] == "leader_withholding" else 0.0)
    if exp == "dkg":
        return est.get("dkg_s", {}).get(str(r["n"]), 60.0)
    if exp == "loss_margin":
        return est.get("loss_margin_run_s", 20.0)
    return est.get("custom_run_s", 60.0)


if __name__ == "__main__":
    main()
