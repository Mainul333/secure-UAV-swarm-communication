#!/usr/bin/env bash
# Run by run_all.py before the experiments, inside reviewer_experiments/protocol_go.
# Adds the two revision commands (new folders only; no existing file is changed)
# and builds the three tools the experiments use.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ ! -f go.mod ] || ! grep -q '^module uav-bft' go.mod; then
  echo "Not in the protocol_go folder (go.mod of module uav-bft not found): $(pwd)" >&2
  exit 1
fi
for cmd in revisionbaselinebench revisionprotocolbench; do
  mkdir -p "cmd/$cmd"
  if ! cmp -s "$HERE/cmd/$cmd/main.go" "cmd/$cmd/main.go"; then
    cp "$HERE/cmd/$cmd/main.go" "cmd/$cmd/main.go"
    echo "installed cmd/$cmd/main.go"
  fi
done
mkdir -p bin
go build -trimpath -o bin/ ./cmd/revisionbaselinebench ./cmd/revisionprotocolbench ./cmd/dkgdemo
echo "built: $(ls bin | tr '\n' ' ')"
go version
