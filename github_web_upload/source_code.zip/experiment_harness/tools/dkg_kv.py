#!/usr/bin/env python3
"""Runs dkgdemo once and prints its results as key=value lines for run_all.py.

Parsing reuses parse_log() from the authors' scripts/merge_dkg_results.py, so
the numbers are read exactly as for the published dkg_scaling CSV.
"""
import argparse, importlib.util, subprocess, sys

ap = argparse.ArgumentParser()
ap.add_argument("--bin", required=True)
ap.add_argument("--merge-script", required=True)
ap.add_argument("-n", type=int, required=True)
ap.add_argument("-t", type=int, required=True)
ap.add_argument("--log", required=True)
a = ap.parse_args()

with open(a.log, "w", encoding="utf-8") as fh:
    rc = subprocess.run([a.bin, "-n", str(a.n), "-t", str(a.t)], stdout=fh, stderr=subprocess.STDOUT).returncode
text = open(a.log, encoding="utf-8", errors="replace").read()
print(text)
if rc != 0:
    print(f"dkgdemo exited with code {rc}")
    sys.exit(rc)
spec = importlib.util.spec_from_file_location("merge_dkg_results", a.merge_script)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
from pathlib import Path
row = mod.parse_log(Path(a.log))
print("success=" + ("true" if row["gjkr_status"] == "passed" and row["threshold_bls_status"] == "passed" else "false"))
for k in ["qual_size", "dkg_ms", "deal_objects", "response_objects", "response_deliveries", "secret_commit_deliveries",
          "partial_sign_verify_ms", "reconstruction_ms", "final_verification_ms"]:
    print(f"{k}={row[k]}")
