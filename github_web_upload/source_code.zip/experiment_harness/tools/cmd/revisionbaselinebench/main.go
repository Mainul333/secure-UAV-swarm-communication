// Command revisionbaselinebench repeats the common-platform comparison of
// publishedbaselinebench for the revision. publishedbaselinebench is left
// unchanged so that the published numbers stay reproducible. Differences:
//
//   - -methods, -first-trial and -warmup let an external harness run one
//     method and one trial per process, in a randomized order.
//   - critical_path_ms reports the computation on the critical path when every
//     party runs on its own processor (followers in parallel, the leader or
//     coordinator sequentially), next to processing_ms, which, as before, sums
//     the computation of all parties executed in one process.
//   - -mode fair (default) applies the same standard optimizations to both
//     threshold schemes: public key shares are computed once at setup instead
//     of by polynomial evaluation inside every share verification, every
//     partial signature is verified once (tbls.Recover verified each partial a
//     second time), and FROST nonce commitments are generated in FROST's
//     preprocessing stage outside the timed interval. -mode legacy executes the
//     computation of publishedbaselinebench unchanged.
package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/binary"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"math"
	"math/big"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"go.dedis.ch/kyber/v4"
	"go.dedis.ch/kyber/v4/group/edwards25519"
	"go.dedis.ch/kyber/v4/pairing/bls12381/kilic"
	"go.dedis.ch/kyber/v4/share"
	"go.dedis.ch/kyber/v4/sign"
	"go.dedis.ch/kyber/v4/sign/bls"
	"go.dedis.ch/kyber/v4/sign/tbls"
)

const (
	methodProposed    = "proposed_threshold_bls"
	methodProposedSch = "proposed_threshold_schnorr"
	methodFHotStuff   = "wang_fhotstuff_frost_independent"
	methodPBFT        = "huo_inspired_authenticated_pbft"
	scenarioNormal    = "normal"
	scenarioLeader    = "leader_withholding"
	scenarioMalformed = "malformed_followers"
	modeFair          = "fair"
	modeLegacy        = "legacy"
)

type methodResult struct {
	Success                bool
	RejectedInvalid        int
	SetupDuration          time.Duration
	ProcessingDuration     time.Duration
	CriticalPath           time.Duration
	ApplicationMessages    uint64
	NetworkDeliveries      uint64
	NetworkBytes           uint64
	VoteOrApprovalBytes    int
	CertificateBytesActual int
	CertificateBytesPaper  int
	SignatureOperations    uint64
	VerificationOperations uint64
	DigestHex              string
	ImplementationNote     string
}

type proposedSetup struct {
	suite        *kilic.SuiteBLS12381
	priPoly      *share.PriPoly
	pubPoly      *share.PubPoly
	pubShares    []kyber.Point // public key share of member i, computed once (fair mode)
	shares       []*share.PriShare
	groupPublic  kyber.Point
	identityPub  []ed25519.PublicKey
	identityPriv []ed25519.PrivateKey
	bsPub        ed25519.PublicKey
	bsPriv       ed25519.PrivateKey
	setup        time.Duration
}

type frostSetup struct {
	suite       *edwards25519.SuiteEd25519
	priPoly     *share.PriPoly
	pubPoly     *share.PubPoly
	pubShares   []kyber.Point // public key share of member i, computed once (fair mode)
	shares      []*share.PriShare
	groupPublic kyber.Point
	setup       time.Duration
}

type pbftSetup struct {
	pub   []ed25519.PublicKey
	priv  []ed25519.PrivateKey
	setup time.Duration
}

type frostCommitment struct {
	index uint32
	d     kyber.Scalar
	e     kyber.Scalar
	D     kyber.Point
	E     kyber.Point
	rho   kyber.Scalar
	R     kyber.Point
}

// frostNonces holds the two-nonce commitments of all signers for one phase.
type frostNonces struct {
	commitments []frostCommitment
	blob        []byte
	perSigner   []time.Duration
}

func main() {
	nodesArg := flag.String("nodes", "4,10,20,50,100", "comma-separated node counts")
	trials := flag.Int("trials", 3, "number of measured repetitions per condition")
	firstTrial := flag.Int("first-trial", 1, "index of the first measured trial (selects the payload)")
	warmup := flag.Int("warmup", 0, "unrecorded runs per method, scenario and size before measuring")
	methodsArg := flag.String("methods", methodProposed+","+methodFHotStuff+","+methodPBFT, "comma-separated methods")
	mode := flag.String("mode", modeFair, "fair (same optimizations for both threshold schemes) or legacy (publishedbaselinebench)")
	payloadBytes := flag.Int("payload-bytes", 1000, "command/transaction payload size")
	batchSize := flag.Int("batch-size", 128, "transactions per consensus batch for metadata")
	timeoutMS := flag.Float64("view-timeout-ms", 5000, "configured leader-failure timeout")
	scenariosArg := flag.String("scenarios", "normal,leader_withholding,malformed_followers", "comma-separated scenarios")
	outputDir := flag.String("output-dir", "results/processed/revision_baseline_comparison", "output directory")
	flag.Parse()

	nodes, err := parsePositiveInts(*nodesArg)
	must(err)
	if *trials < 1 || *firstTrial < 1 || *warmup < 0 {
		fatalf("trials and first-trial must be positive and warmup non-negative")
	}
	if *payloadBytes < 1 || *batchSize < 1 {
		fatalf("payload-bytes and batch-size must be positive")
	}
	if *mode != modeFair && *mode != modeLegacy {
		fatalf("mode must be %q or %q", modeFair, modeLegacy)
	}
	fair := *mode == modeFair
	scenarios, err := parseScenarios(*scenariosArg)
	must(err)
	methods, err := parseMethods(*methodsArg)
	must(err)

	absOut, err := filepath.Abs(*outputDir)
	must(err)
	must(os.MkdirAll(absOut, 0o755))
	writeJSON(filepath.Join(absOut, "baseline_benchmark_config.json"), map[string]any{
		"nodes": nodes, "trials": *trials, "first_trial": *firstTrial, "warmup": *warmup,
		"methods": methods, "mode": *mode, "payload_bytes": *payloadBytes, "batch_size": *batchSize,
		"view_timeout_ms": *timeoutMS, "scenarios": scenarios, "output_dir": absOut,
		"created_at_utc": time.Now().UTC().Format(time.RFC3339Nano),
	})

	trialPath := filepath.Join(absOut, "published_baseline_trials.csv")
	file, err := os.Create(trialPath)
	must(err)
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	must(writer.Write([]string{
		"method", "scenario", "nodes", "threshold", "faulty_nodes", "trial", "success",
		"rejected_invalid", "setup_ms", "processing_ms", "critical_path_ms", "timeout_ms", "total_latency_ms",
		"application_messages", "network_deliveries", "network_bytes", "vote_or_approval_bytes",
		"certificate_bytes_actual", "certificate_bytes_paper", "signature_operations",
		"verification_operations", "payload_bytes", "batch_size", "mode", "digest_hex", "implementation_note",
	}))

	for _, n := range nodes {
		if n < 4 {
			fatalf("node count %d is below the BFT minimum 4", n)
		}
		t := thresholdFor(n)
		f := (n - 1) / 3
		fmt.Printf("Preparing n=%d threshold=%d faulty=%d mode=%s ...\n", n, t, f, *mode)

		var proposed *proposedSetup
		var frost *frostSetup
		var pbft *pbftSetup
		var schnorr *proposedSchnorrSetup
		for _, method := range methods {
			switch method {
			case methodProposed:
				proposed, err = newProposedSetup(n, t, fair)
			case methodFHotStuff:
				frost, err = newFrostSetup(n, t, fair)
			case methodPBFT:
				pbft, err = newPBFTSetup(n)
			case methodProposedSch:
				schnorr, err = newProposedSchnorrSetup(n, t)
			}
			if err != nil {
				fatalf("prepare %s n=%d: %v", method, n, err)
			}
		}
		run := func(method, scenario string, payload []byte) methodResult {
			switch method {
			case methodProposed:
				return runProposed(proposed, n, t, f, scenario, payload, fair)
			case methodFHotStuff:
				return runFHotStuff(frost, n, t, f, scenario, payload, fair)
			case methodProposedSch:
				return runProposedSchnorr(schnorr, n, t, f, scenario, payload)
			default:
				return runPBFT(pbft, n, t, f, scenario, payload)
			}
		}

		for _, scenario := range scenarios {
			for w := 0; w < *warmup; w++ {
				payload := deterministicPayload(n, 1_000_000+w, scenario, *payloadBytes)
				for _, method := range methods {
					_ = run(method, scenario, payload)
				}
			}
			for trial := *firstTrial; trial < *firstTrial+*trials; trial++ {
				payload := deterministicPayload(n, trial, scenario, *payloadBytes)
				for _, method := range methods {
					res := run(method, scenario, payload)
					timeout := 0.0
					if scenario == scenarioLeader {
						timeout = *timeoutMS
					}
					processing := durationMS(res.ProcessingDuration)
					record := []string{
						method, scenario, strconv.Itoa(n), strconv.Itoa(t), strconv.Itoa(f), strconv.Itoa(trial),
						strconv.FormatBool(res.Success), strconv.Itoa(res.RejectedInvalid),
						formatFloat(durationMS(res.SetupDuration)), formatFloat(processing),
						formatFloat(durationMS(res.CriticalPath)), formatFloat(timeout), formatFloat(processing + timeout),
						strconv.FormatUint(res.ApplicationMessages, 10), strconv.FormatUint(res.NetworkDeliveries, 10),
						strconv.FormatUint(res.NetworkBytes, 10), strconv.Itoa(res.VoteOrApprovalBytes),
						strconv.Itoa(res.CertificateBytesActual), strconv.Itoa(res.CertificateBytesPaper),
						strconv.FormatUint(res.SignatureOperations, 10), strconv.FormatUint(res.VerificationOperations, 10),
						strconv.Itoa(*payloadBytes), strconv.Itoa(*batchSize), *mode, res.DigestHex, res.ImplementationNote,
					}
					must(writer.Write(record))
					writer.Flush()
					if err := writer.Error(); err != nil {
						fatalf("write trial CSV: %v", err)
					}
					fmt.Printf("  %-34s %-20s trial=%d success=%t processing=%.3f ms critical_path=%.3f ms bytes=%d\n",
						method, scenario, trial, res.Success, processing, durationMS(res.CriticalPath), res.NetworkBytes)
				}
			}
		}
	}

	writeJSON(filepath.Join(absOut, "published_baseline_completion.json"), map[string]any{
		"status": "PASSED", "trial_csv": trialPath, "methods": methods, "mode": *mode,
		"finished_at_utc": time.Now().UTC().Format(time.RFC3339Nano),
	})
	fmt.Println("REVISION BASELINE CAMPAIGN: PASSED")
	fmt.Println("Results:", absOut)
}

func parseMethods(value string) ([]string, error) {
	allowed := map[string]bool{methodProposed: true, methodProposedSch: true, methodFHotStuff: true, methodPBFT: true}
	var out []string
	seen := map[string]bool{}
	for _, token := range strings.Split(value, ",") {
		token = strings.TrimSpace(token)
		if token == "" || seen[token] {
			continue
		}
		if !allowed[token] {
			return nil, fmt.Errorf("unsupported method %q", token)
		}
		seen[token] = true
		out = append(out, token)
	}
	if len(out) == 0 {
		return nil, errors.New("no methods supplied")
	}
	return out, nil
}

func maxDuration(values []time.Duration) time.Duration {
	var m time.Duration
	for _, v := range values {
		if v > m {
			m = v
		}
	}
	return m
}

func newProposedSetup(n, t int, fair bool) (*proposedSetup, error) {
	started := time.Now()
	suite := kilic.NewSuiteBLS12381()
	pri := share.NewPriPoly(suite, uint32(t), nil, suite.RandomStream())
	pub := pri.Commit(nil)
	shares := pri.Shares(uint32(n))
	identityPub := make([]ed25519.PublicKey, n)
	identityPriv := make([]ed25519.PrivateKey, n)
	for i := 0; i < n; i++ {
		pubKey, privKey, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
		identityPub[i], identityPriv[i] = pubKey, privKey
	}
	bsPub, bsPriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	setup := &proposedSetup{
		suite: suite, priPoly: pri, pubPoly: pub, shares: shares,
		groupPublic: pub.Commit(), identityPub: identityPub, identityPriv: identityPriv,
		bsPub: bsPub, bsPriv: bsPriv,
	}
	if fair {
		setup.pubShares = make([]kyber.Point, n)
		for i := 0; i < n; i++ {
			setup.pubShares[i] = pub.Eval(uint32(i)).V
		}
	}
	setup.setup = time.Since(started)
	return setup, nil
}

func newFrostSetup(n, t int, fair bool) (*frostSetup, error) {
	started := time.Now()
	suite := edwards25519.NewBlakeSHA256Ed25519()
	pri := share.NewPriPoly(suite, uint32(t), nil, suite.RandomStream())
	pub := pri.Commit(nil)
	setup := &frostSetup{
		suite: suite, priPoly: pri, pubPoly: pub,
		shares: pri.Shares(uint32(n)), groupPublic: pub.Commit(),
	}
	if fair {
		setup.pubShares = make([]kyber.Point, n)
		for i := 0; i < n; i++ {
			setup.pubShares[i] = pub.Eval(uint32(i)).V
		}
	}
	setup.setup = time.Since(started)
	return setup, nil
}

func newPBFTSetup(n int) (*pbftSetup, error) {
	started := time.Now()
	pub := make([]ed25519.PublicKey, n)
	priv := make([]ed25519.PrivateKey, n)
	for i := 0; i < n; i++ {
		p, s, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
		pub[i], priv[i] = p, s
	}
	return &pbftSetup{pub: pub, priv: priv, setup: time.Since(started)}, nil
}

// runProposed executes the per-command computation of the proposed framework.
// Critical path: base-station signature, leader proposal, the slowest
// follower (verify the authorization, sign the partial and its envelope), the
// leader's sequential verification of the approvals, recovery, and one
// follower's verification of the certificate.
func runProposed(setup *proposedSetup, n, t, f int, scenario string, payload []byte, fair bool) methodResult {
	message := sha256.Sum256(payload)
	scheme := tbls.NewThresholdSchemeOnG1(setup.suite)
	var blsScheme sign.Scheme = bls.NewSchemeOnG1(setup.suite)
	activeFaults := 0
	if scenario == scenarioMalformed {
		activeFaults = f
	}
	signerIDs := honestSignerIDs(n, t, activeFaults)
	follower := make([]time.Duration, len(signerIDs))
	var sequential, leaderWork time.Duration
	started := time.Now()
	result := methodResult{Success: true, SetupDuration: setup.setup, DigestHex: hex.EncodeToString(message[:])}

	verifyPartial := func(partial []byte) error {
		if !fair {
			return scheme.VerifyPartial(setup.pubPoly, message[:], partial)
		}
		sh := tbls.SigShare(partial)
		idx, err := sh.Index()
		if err != nil {
			return err
		}
		if idx < 0 || idx >= len(setup.pubShares) {
			return errors.New("share index out of range")
		}
		return blsScheme.Verify(setup.pubShares[idx], message[:], sh.Value())
	}

	mark := time.Now()
	bsSig := ed25519.Sign(setup.bsPriv, message[:])
	result.SignatureOperations++
	sequential += time.Since(mark)
	for k := range signerIDs {
		mark = time.Now()
		if !ed25519.Verify(setup.bsPub, message[:], bsSig) {
			result.Success = false
		}
		result.VerificationOperations++
		follower[k] += time.Since(mark)
	}

	mark = time.Now()
	leaderEnvelope := append([]byte("PROPOSAL"), message[:]...)
	leaderSig := ed25519.Sign(setup.identityPriv[0], leaderEnvelope)
	result.SignatureOperations++
	if !ed25519.Verify(setup.identityPub[0], leaderEnvelope, leaderSig) {
		result.Success = false
	}
	result.VerificationOperations++
	sequential += time.Since(mark)

	if scenario == scenarioMalformed && f > 0 {
		for i := 0; i < f; i++ {
			bad := make([]byte, 32)
			_, _ = rand.Read(bad)
			mark = time.Now()
			if err := verifyPartial(bad); err != nil {
				result.RejectedInvalid++
			}
			result.VerificationOperations++
			leaderWork += time.Since(mark)
		}
	}

	partials := make([][]byte, 0, t)
	for k, id := range signerIDs {
		mark = time.Now()
		partial, err := scheme.Sign(setup.shares[id], message[:])
		if err != nil {
			result.Success = false
			follower[k] += time.Since(mark)
			continue
		}
		result.SignatureOperations++
		follower[k] += time.Since(mark)

		mark = time.Now()
		if err := verifyPartial(partial); err != nil {
			result.Success = false
		}
		result.VerificationOperations++
		leaderWork += time.Since(mark)

		mark = time.Now()
		envelope := append(append([]byte("APPROVAL"), message[:]...), partial...)
		identitySig := ed25519.Sign(setup.identityPriv[id], envelope)
		result.SignatureOperations++
		follower[k] += time.Since(mark)

		mark = time.Now()
		if !ed25519.Verify(setup.identityPub[id], envelope, identitySig) {
			result.Success = false
		}
		result.VerificationOperations++
		leaderWork += time.Since(mark)
		partials = append(partials, partial)
	}

	mark = time.Now()
	var recovered []byte
	var err error
	if fair {
		recovered, err = recoverVerified(setup, partials, t, n)
	} else {
		recovered, err = scheme.Recover(setup.pubPoly, message[:], partials, uint32(t), uint32(n))
	}
	if err != nil {
		result.Success = false
	}
	leaderWork += time.Since(mark)
	if err == nil {
		mark = time.Now()
		if err := scheme.VerifyRecovered(setup.groupPublic, message[:], recovered); err != nil {
			result.Success = false
		}
		result.VerificationOperations++
		sequential += time.Since(mark)
		result.CertificateBytesActual = len(recovered) + 4*t + 56
	}
	var viewChange time.Duration
	if scenario == scenarioLeader {
		viewMessage := append([]byte("VIEW-CHANGE"), message[:]...)
		signTimes := make([]time.Duration, len(signerIDs))
		var collect time.Duration
		for k, id := range signerIDs {
			mark = time.Now()
			sig := ed25519.Sign(setup.identityPriv[id], viewMessage)
			result.SignatureOperations++
			signTimes[k] = time.Since(mark)
			mark = time.Now()
			if !ed25519.Verify(setup.identityPub[id], viewMessage, sig) {
				result.Success = false
			}
			result.VerificationOperations++
			collect += time.Since(mark)
		}
		viewChange = maxDuration(signTimes) + collect
	}
	result.ProcessingDuration = time.Since(started)
	result.CriticalPath = sequential + maxDuration(follower) + leaderWork + viewChange

	partialLen := 0
	if len(partials) > 0 {
		partialLen = len(partials[0])
	}
	approvalBytes := partialLen + ed25519.SignatureSize + 32 + 32
	proposalBytes := len(payload) + len(bsSig) + len(leaderSig) + 96
	certificateBytes := result.CertificateBytesActual
	result.VoteOrApprovalBytes = approvalBytes
	result.CertificateBytesPaper = certificateBytes
	result.ApplicationMessages = uint64(2 + t)
	result.NetworkDeliveries = uint64(2*(n-1) + t)
	result.NetworkBytes = uint64(proposalBytes*(n-1) + approvalBytes*t + certificateBytes*(n-1))
	if scenario == scenarioLeader {
		viewChangeBytes := 32 + ed25519.SignatureSize + 32
		result.ApplicationMessages += uint64(t)
		result.NetworkDeliveries += uint64(t)
		result.NetworkBytes += uint64(viewChangeBytes * t)
	}
	if scenario == scenarioMalformed {
		result.ApplicationMessages += uint64(f)
		result.NetworkDeliveries += uint64(f)
		result.NetworkBytes += uint64(approvalBytes * f)
	}
	if fair {
		result.ImplementationNote = "Threshold BLS with dealer-generated shares (GJKR excluded from per-command latency); public key shares computed once at setup; each partial verified once, then Lagrange recovery and final verification."
	} else {
		result.ImplementationNote = "Legacy computation of publishedbaselinebench: tbls.VerifyPartial evaluates the public polynomial per share and tbls.Recover verifies every partial again."
	}
	return result
}

// recoverVerified interpolates partial signatures that were already verified.
func recoverVerified(setup *proposedSetup, partials [][]byte, t, n int) ([]byte, error) {
	group := setup.suite.G1()
	pubShares := make([]*share.PubShare, 0, len(partials))
	for _, partial := range partials {
		sh := tbls.SigShare(partial)
		idx, err := sh.Index()
		if err != nil {
			continue
		}
		point := group.Point()
		if err := point.UnmarshalBinary(sh.Value()); err != nil {
			continue
		}
		pubShares = append(pubShares, &share.PubShare{I: uint32(idx), V: point})
		if len(pubShares) >= t {
			break
		}
	}
	if len(pubShares) < t {
		return nil, errors.New("not enough valid partial signatures")
	}
	commit, err := share.RecoverCommit(group, pubShares, uint32(t), uint32(n))
	if err != nil {
		return nil, err
	}
	return commit.MarshalBinary()
}

// runFHotStuff executes three chained FROST signing phases. Critical path per
// phase: the coordinator's binding factors and group commitment, the slowest
// signer's response, and the coordinator's sequential share verification and
// aggregation. In fair mode the nonce commitments are generated beforehand
// (FROST preprocessing) and excluded from both metrics.
func runFHotStuff(setup *frostSetup, n, t, f int, scenario string, payload []byte, fair bool) methodResult {
	message := sha512.Sum512(payload)
	activeFaults := 0
	if scenario == scenarioMalformed {
		activeFaults = f
	}
	signerIDs := honestSignerIDs(n, t, activeFaults)
	var pre [3]*frostNonces
	if fair {
		for phase := 0; phase < 3; phase++ {
			pre[phase] = makeFrostNonces(setup, signerIDs)
		}
	}
	started := time.Now()
	result := methodResult{Success: true, SetupDuration: setup.setup, DigestHex: hex.EncodeToString(message[:])}
	current := message[:]
	for phase := 0; phase < 3; phase++ {
		phaseMessage := sha512.Sum512(append(append([]byte{}, current...), byte(phase)))
		malformedCount := 0
		if scenario == scenarioMalformed && phase == 0 {
			malformedCount = f
		}
		nonces := pre[phase]
		if !fair {
			nonces = makeFrostNonces(setup, signerIDs)
		}
		ok, rejected, sigOps, verifyOps, actualBytes, critical := frostRound(setup, signerIDs, phaseMessage[:], malformedCount, nonces, fair)
		result.RejectedInvalid += rejected
		result.SignatureOperations += sigOps
		result.VerificationOperations += verifyOps
		result.CriticalPath += critical
		if !fair {
			result.CriticalPath += maxDuration(nonces.perSigner)
		}
		if !ok {
			result.Success = false
		}
		result.CertificateBytesActual = actualBytes
		current = phaseMessage[:]
	}
	result.ProcessingDuration = time.Since(started)

	paperVoteBytes := 33
	paperQCBytes := 32 + t
	proposalBaseBytes := len(payload) + 80
	var networkBytes uint64
	var deliveries uint64
	for phase := 0; phase < 3; phase++ {
		qcBytes := 0
		if phase > 0 {
			qcBytes = paperQCBytes
		}
		networkBytes += uint64((proposalBaseBytes + qcBytes) * (n - 1))
		networkBytes += uint64(paperVoteBytes * t)
		deliveries += uint64((n - 1) + t)
	}
	result.ApplicationMessages = uint64(3 + 3*t)
	result.NetworkDeliveries = deliveries
	result.NetworkBytes = networkBytes
	result.VoteOrApprovalBytes = paperVoteBytes
	result.CertificateBytesPaper = paperQCBytes
	if scenario == scenarioLeader {
		newViewBytes := paperQCBytes + 48
		result.ApplicationMessages += uint64(t)
		result.NetworkDeliveries += uint64(t)
		result.NetworkBytes += uint64(newViewBytes * t)
	}
	if scenario == scenarioMalformed {
		result.ApplicationMessages += uint64(f)
		result.NetworkDeliveries += uint64(f)
		result.NetworkBytes += uint64(paperVoteBytes * f)
	}
	if fair {
		result.ImplementationNote = "Independent FHotStuff/FROST implementation (not the authors' code): nonce commitments preprocessed outside the timed interval, public key shares computed once at setup, three chained proposal-vote rounds, paper-format vote and QC sizes."
	} else {
		result.ImplementationNote = "Legacy computation of publishedbaselinebench: nonce commitments generated inside the timed interval and every share verification evaluates the public polynomial."
	}
	return result
}

func makeFrostNonces(setup *frostSetup, signerIDs []int) *frostNonces {
	out := &frostNonces{
		commitments: make([]frostCommitment, 0, len(signerIDs)),
		blob:        make([]byte, 0, len(signerIDs)*68),
		perSigner:   make([]time.Duration, len(signerIDs)),
	}
	for k, id := range signerIDs {
		mark := time.Now()
		d := setup.suite.Scalar().Pick(setup.suite.RandomStream())
		e := setup.suite.Scalar().Pick(setup.suite.RandomStream())
		D := setup.suite.Point().Mul(d, nil)
		E := setup.suite.Point().Mul(e, nil)
		Db, _ := D.MarshalBinary()
		Eb, _ := E.MarshalBinary()
		var idBytes [4]byte
		binary.LittleEndian.PutUint32(idBytes[:], uint32(id))
		out.blob = append(out.blob, idBytes[:]...)
		out.blob = append(out.blob, Db...)
		out.blob = append(out.blob, Eb...)
		out.commitments = append(out.commitments, frostCommitment{index: uint32(id), d: d, e: e, D: D, E: E})
		out.perSigner[k] = time.Since(mark)
	}
	return out
}

func frostRound(setup *frostSetup, signerIDs []int, message []byte, malformedCount int, nonces *frostNonces, fair bool) (bool, int, uint64, uint64, int, time.Duration) {
	return frostRoundWith(setup, signerIDs, message, malformedCount, nonces, fair, false)
}

// frostRoundWith runs one FROST signing round. With rfc8032 set, the challenge
// is SHA-512(R || Y || m) as in RFC 8032, and the combined signature is
// checked with the standard Ed25519 verifier of the Go library.
func frostRoundWith(setup *frostSetup, signerIDs []int, message []byte, malformedCount int, nonces *frostNonces, fair, rfc8032 bool) (bool, int, uint64, uint64, int, time.Duration) {
	commitments := nonces.commitments
	commitmentBlob := nonces.blob
	var coordinator time.Duration
	signer := make([]time.Duration, len(commitments))

	mark := time.Now()
	R := setup.suite.Point().Null()
	for i := range commitments {
		commitments[i].rho = hashToScalar(setup.suite, "FROST-RHO", uint32(commitments[i].index), message, commitmentBlob)
		rhoE := setup.suite.Point().Mul(commitments[i].rho, commitments[i].E)
		commitments[i].R = setup.suite.Point().Add(commitments[i].D, rhoE)
		R = setup.suite.Point().Add(R, commitments[i].R)
	}
	Rb, _ := R.MarshalBinary()
	Yb, _ := setup.groupPublic.MarshalBinary()
	challenge := hashToScalar(setup.suite, "FROST-CHALLENGE", 0, message, Rb, Yb)
	if rfc8032 {
		challenge = rfc8032Challenge(setup.suite, Rb, Yb, message)
	}
	coordinator += time.Since(mark)

	zTotal := setup.suite.Scalar().Zero()
	ok := true
	rejected := 0
	var sigOps uint64
	var verifyOps uint64
	for i := range commitments {
		id := int(commitments[i].index)
		mark = time.Now()
		lambda := lagrangeAtZero(setup.suite, commitments[i].index, signerIDs)
		rhoE := setup.suite.Scalar().Mul(commitments[i].rho, commitments[i].e)
		lambdaShare := setup.suite.Scalar().Mul(lambda, setup.shares[id].V)
		lambdaShareChallenge := setup.suite.Scalar().Mul(lambdaShare, challenge)
		z := setup.suite.Scalar().Add(commitments[i].d, rhoE)
		z = setup.suite.Scalar().Add(z, lambdaShareChallenge)
		sigOps++
		signer[i] = time.Since(mark)

		mark = time.Now()
		left := setup.suite.Point().Mul(z, nil)
		var publicShare kyber.Point
		if fair {
			publicShare = setup.pubShares[id]
		} else {
			publicShare = setup.pubPoly.Eval(uint32(id)).V
		}
		rightTermScalar := setup.suite.Scalar().Mul(lambda, challenge)
		rightTerm := setup.suite.Point().Mul(rightTermScalar, publicShare)
		right := setup.suite.Point().Add(commitments[i].R, rightTerm)
		verifyOps++
		if !left.Equal(right) {
			ok = false
		}
		zTotal = setup.suite.Scalar().Add(zTotal, z)
		coordinator += time.Since(mark)
	}

	mark = time.Now()
	for i := 0; i < malformedCount; i++ {
		badZ := setup.suite.Scalar().Pick(setup.suite.RandomStream())
		left := setup.suite.Point().Mul(badZ, nil)
		reference := commitments[i%len(commitments)].R
		if !left.Equal(reference) {
			rejected++
		}
		verifyOps++
	}

	verifyOps++
	if rfc8032 {
		zb, _ := zTotal.MarshalBinary()
		if !ed25519.Verify(ed25519.PublicKey(Yb), message, append(append([]byte{}, Rb...), zb...)) {
			ok = false
		}
	} else {
		left := setup.suite.Point().Mul(zTotal, nil)
		right := setup.suite.Point().Add(R, setup.suite.Point().Mul(challenge, setup.groupPublic))
		if !left.Equal(right) {
			ok = false
		}
	}
	coordinator += time.Since(mark)
	actualBytes := len(Rb) + setup.suite.ScalarLen()
	return ok, rejected, sigOps, verifyOps, actualBytes, coordinator + maxDuration(signer)
}

// runPBFT executes authenticated PBFT. Critical path: the leader's
// pre-prepare signature, then for each phase the slowest replica's signing and
// its verification of the messages of all other replicas.
func runPBFT(setup *pbftSetup, n, t, f int, scenario string, payload []byte) methodResult {
	digest := sha256.Sum256(payload)
	started := time.Now()
	result := methodResult{Success: true, SetupDuration: setup.setup, DigestHex: hex.EncodeToString(digest[:])}
	var critical time.Duration

	mark := time.Now()
	preprepare := append([]byte("PREPREPARE"), digest[:]...)
	leaderSig := ed25519.Sign(setup.priv[0], preprepare)
	result.SignatureOperations++
	critical += time.Since(mark)
	perReceiver := make([]time.Duration, n)
	for receiver := 1; receiver < n; receiver++ {
		mark = time.Now()
		if !ed25519.Verify(setup.pub[0], preprepare, leaderSig) {
			result.Success = false
		}
		result.VerificationOperations++
		perReceiver[receiver] = time.Since(mark)
	}
	critical += maxDuration(perReceiver)

	phase := func(label string) ([][]byte, [][]byte) {
		messages := make([][]byte, n)
		sigs := make([][]byte, n)
		perSender := make([]time.Duration, n)
		for sender := 0; sender < n; sender++ {
			mark := time.Now()
			messages[sender] = append(append([]byte(label), byte(sender)), digest[:]...)
			sigs[sender] = ed25519.Sign(setup.priv[sender], messages[sender])
			result.SignatureOperations++
			perSender[sender] = time.Since(mark)
		}
		critical += maxDuration(perSender)
		perReceiver := make([]time.Duration, n)
		for receiver := 0; receiver < n; receiver++ {
			mark := time.Now()
			for sender := 0; sender < n; sender++ {
				if sender == receiver {
					continue
				}
				if !ed25519.Verify(setup.pub[sender], messages[sender], sigs[sender]) {
					result.Success = false
				}
				result.VerificationOperations++
			}
			perReceiver[receiver] = time.Since(mark)
		}
		critical += maxDuration(perReceiver)
		return messages, sigs
	}
	prepareMessages, _ := phase("PREPARE")
	_, _ = phase("COMMIT")

	if scenario == scenarioMalformed && f > 0 {
		wrong := sha256.Sum256(append([]byte("CONFLICT"), payload...))
		for i := 0; i < f; i++ {
			sender := n - 1 - i
			badMessage := append(append([]byte("PREPARE"), byte(sender)), wrong[:]...)
			badSig := ed25519.Sign(setup.priv[sender], badMessage)
			result.SignatureOperations++
			mark = time.Now()
			if !ed25519.Verify(setup.pub[sender], prepareMessages[sender], badSig) {
				result.RejectedInvalid++
			}
			result.VerificationOperations++
			critical += time.Since(mark)
		}
	}

	if scenario == scenarioLeader {
		viewMessage := append([]byte("VIEW-CHANGE"), digest[:]...)
		viewSigs := make([][]byte, n)
		perSender := make([]time.Duration, n)
		for sender := 0; sender < n; sender++ {
			mark = time.Now()
			viewSigs[sender] = ed25519.Sign(setup.priv[sender], viewMessage)
			result.SignatureOperations++
			perSender[sender] = time.Since(mark)
		}
		critical += maxDuration(perSender)
		mark = time.Now()
		for sender := 0; sender < n; sender++ {
			if !ed25519.Verify(setup.pub[sender], viewMessage, viewSigs[sender]) {
				result.Success = false
			}
			result.VerificationOperations++
		}
		newView := append([]byte("NEW-VIEW"), digest[:]...)
		newViewSig := ed25519.Sign(setup.priv[1%n], newView)
		result.SignatureOperations++
		critical += time.Since(mark)
		perReceiver := make([]time.Duration, n)
		for receiver := 0; receiver < n; receiver++ {
			if receiver == 1%n {
				continue
			}
			mark = time.Now()
			if !ed25519.Verify(setup.pub[1%n], newView, newViewSig) {
				result.Success = false
			}
			result.VerificationOperations++
			perReceiver[receiver] = time.Since(mark)
		}
		critical += maxDuration(perReceiver)
	}

	result.ProcessingDuration = time.Since(started)
	result.CriticalPath = critical
	preprepareBytes := len(payload) + ed25519.SignatureSize + 48
	phaseMessageBytes := 32 + ed25519.SignatureSize + 32
	result.ApplicationMessages = uint64(1 + 2*n)
	result.NetworkDeliveries = uint64((n - 1) + 2*n*(n-1))
	result.NetworkBytes = uint64(preprepareBytes*(n-1) + 2*phaseMessageBytes*n*(n-1))
	result.VoteOrApprovalBytes = phaseMessageBytes
	result.CertificateBytesActual = t * (ed25519.SignatureSize + 4)
	result.CertificateBytesPaper = result.CertificateBytesActual
	if scenario == scenarioLeader {
		viewChangeBytes := 32 + ed25519.SignatureSize + 32
		newViewBytes := viewChangeBytes + t*(ed25519.SignatureSize+4)
		result.ApplicationMessages += uint64(n + 1)
		result.NetworkDeliveries += uint64(n + (n - 1))
		result.NetworkBytes += uint64(viewChangeBytes*n + newViewBytes*(n-1))
	}
	if scenario == scenarioMalformed {
		result.ApplicationMessages += uint64(f)
		result.NetworkDeliveries += uint64(f)
		result.NetworkBytes += uint64(phaseMessageBytes * f)
	}
	result.ImplementationNote = "Standard authenticated PBFT (PRE-PREPARE, all-to-all PREPARE, all-to-all COMMIT) as a Huo-inspired baseline; computation identical in both modes."
	return result
}

func thresholdFor(n int) int {
	return (2*n)/3 + 1
}

func parsePositiveInts(value string) ([]int, error) {
	seen := map[int]struct{}{}
	var out []int
	for _, token := range strings.Split(value, ",") {
		token = strings.TrimSpace(token)
		if token == "" {
			continue
		}
		v, err := strconv.Atoi(token)
		if err != nil || v <= 0 {
			return nil, fmt.Errorf("invalid positive integer %q", token)
		}
		if _, ok := seen[v]; !ok {
			seen[v] = struct{}{}
			out = append(out, v)
		}
	}
	if len(out) == 0 {
		return nil, errors.New("no node counts supplied")
	}
	sort.Ints(out)
	return out, nil
}

func parseScenarios(value string) ([]string, error) {
	allowed := map[string]bool{
		scenarioNormal:    true,
		scenarioLeader:    true,
		scenarioMalformed: true,
	}
	seen := map[string]struct{}{}
	var out []string
	for _, token := range strings.Split(value, ",") {
		token = strings.TrimSpace(strings.ToLower(token))
		if token == "" {
			continue
		}
		if !allowed[token] {
			return nil, fmt.Errorf("unsupported scenario %q", token)
		}
		if _, ok := seen[token]; !ok {
			seen[token] = struct{}{}
			out = append(out, token)
		}
	}
	if len(out) == 0 {
		return nil, errors.New("no scenarios supplied")
	}
	return out, nil
}

func deterministicPayload(n, trial int, scenario string, size int) []byte {
	seed := sha512.Sum512([]byte(fmt.Sprintf("UAV-BASELINE|n=%d|trial=%d|scenario=%s", n, trial, scenario)))
	payload := make([]byte, size)
	for i := range payload {
		payload[i] = seed[i%len(seed)] ^ byte(i*31+trial)
	}
	return payload
}

func hashToScalar(suite *edwards25519.SuiteEd25519, domain string, id uint32, parts ...[]byte) kyber.Scalar {
	h := sha512.New()
	h.Write([]byte(domain))
	var idBytes [4]byte
	binary.LittleEndian.PutUint32(idBytes[:], id)
	h.Write(idBytes[:])
	for _, part := range parts {
		var length [8]byte
		binary.LittleEndian.PutUint64(length[:], uint64(len(part)))
		h.Write(length[:])
		h.Write(part)
	}
	return suite.Scalar().SetBytes(h.Sum(nil))
}

func lagrangeAtZero(suite *edwards25519.SuiteEd25519, signer uint32, signerIDs []int) kyber.Scalar {
	xi := suite.Scalar().SetInt64(int64(signer + 1))
	numerator := suite.Scalar().One()
	denominator := suite.Scalar().One()
	for _, id := range signerIDs {
		if uint32(id) == signer {
			continue
		}
		xj := suite.Scalar().SetInt64(int64(id + 1))
		numerator = suite.Scalar().Mul(numerator, xj)
		difference := suite.Scalar().Sub(xj, xi)
		denominator = suite.Scalar().Mul(denominator, difference)
	}
	return suite.Scalar().Div(numerator, denominator)
}

func honestSignerIDs(n, t, f int) []int {
	start := 0
	if n-f >= t {
		start = f
	}
	ids := make([]int, 0, t)
	for i := start; i < n && len(ids) < t; i++ {
		ids = append(ids, i)
	}
	if len(ids) < t {
		for i := 0; i < start && len(ids) < t; i++ {
			ids = append(ids, i)
		}
	}
	return ids
}

func durationMS(value time.Duration) float64 {
	return float64(value.Nanoseconds()) / 1e6
}

func formatFloat(value float64) string {
	if math.IsNaN(value) || math.IsInf(value, 0) {
		return ""
	}
	return strconv.FormatFloat(value, 'f', 6, 64)
}

func writeJSON(path string, value any) {
	data, err := json.MarshalIndent(value, "", "  ")
	must(err)
	data = append(data, '\n')
	must(os.WriteFile(path, data, 0o644))
}

func must(err error) {
	if err != nil {
		fatalf("%v", err)
	}
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "ERROR: "+format+"\n", args...)
	os.Exit(1)
}

var ed25519Order, _ = new(big.Int).SetString("7237005577332262213973186563042994240857116359379907606001950938285454250989", 10)

// rfc8032Challenge returns SHA-512(R || Y || m) reduced modulo the group order.
func rfc8032Challenge(suite *edwards25519.SuiteEd25519, Rb, Yb, message []byte) kyber.Scalar {
	h := sha512.New()
	h.Write(Rb)
	h.Write(Yb)
	h.Write(message)
	digest := h.Sum(nil)
	be := make([]byte, len(digest))
	for i := range digest {
		be[len(digest)-1-i] = digest[i]
	}
	v := new(big.Int).Mod(new(big.Int).SetBytes(be), ed25519Order)
	out := make([]byte, 32)
	vb := v.Bytes()
	for i := range vb {
		out[i] = vb[len(vb)-1-i]
	}
	sc := suite.Scalar()
	if err := sc.UnmarshalBinary(out); err != nil {
		panic(err)
	}
	return sc
}

type proposedSchnorrSetup struct {
	frost        *frostSetup
	identityPub  []ed25519.PublicKey
	identityPriv []ed25519.PrivateKey
	bsPub        ed25519.PublicKey
	bsPriv       ed25519.PrivateKey
	setup        time.Duration
}

func newProposedSchnorrSetup(n, t int) (*proposedSchnorrSetup, error) {
	started := time.Now()
	frost, err := newFrostSetup(n, t, true)
	if err != nil {
		return nil, err
	}
	out := &proposedSchnorrSetup{frost: frost, identityPub: make([]ed25519.PublicKey, n), identityPriv: make([]ed25519.PrivateKey, n)}
	for i := 0; i < n; i++ {
		pub, priv, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
		out.identityPub[i], out.identityPriv[i] = pub, priv
	}
	out.bsPub, out.bsPriv, err = ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	out.setup = time.Since(started)
	return out, nil
}

// runProposedSchnorr executes the per-command computation of the proposed
// framework with threshold Schnorr (FROST over Edwards25519, RFC 8032
// challenge): base-station authorization, one signing round over the command
// digest with preprocessed nonce commitments, authenticated approval
// envelopes, and certificate verification with the standard Ed25519
// verifier. A leader change requires a second signing session, because a
// Schnorr share is bound to its signer set and nonces.
func runProposedSchnorr(setup *proposedSchnorrSetup, n, t, f int, scenario string, payload []byte) methodResult {
	message := sha256.Sum256(payload)
	activeFaults := 0
	if scenario == scenarioMalformed {
		activeFaults = f
	}
	signerIDs := honestSignerIDs(n, t, activeFaults)
	first := makeFrostNonces(setup.frost, signerIDs)
	var second *frostNonces
	if scenario == scenarioLeader {
		second = makeFrostNonces(setup.frost, signerIDs)
	}
	follower := make([]time.Duration, len(signerIDs))
	var sequential, leaderWork time.Duration
	started := time.Now()
	result := methodResult{Success: true, SetupDuration: setup.setup, DigestHex: hex.EncodeToString(message[:])}

	mark := time.Now()
	bsSig := ed25519.Sign(setup.bsPriv, message[:])
	result.SignatureOperations++
	sequential += time.Since(mark)
	for k := range signerIDs {
		mark = time.Now()
		if !ed25519.Verify(setup.bsPub, message[:], bsSig) {
			result.Success = false
		}
		result.VerificationOperations++
		follower[k] += time.Since(mark)
	}
	mark = time.Now()
	leaderEnvelope := append([]byte("PROPOSAL"), message[:]...)
	leaderSig := ed25519.Sign(setup.identityPriv[0], leaderEnvelope)
	result.SignatureOperations++
	if !ed25519.Verify(setup.identityPub[0], leaderEnvelope, leaderSig) {
		result.Success = false
	}
	result.VerificationOperations++
	sequential += time.Since(mark)

	malformed := 0
	if scenario == scenarioMalformed {
		malformed = f
	}
	ok, rejected, sigOps, verifyOps, _, critical := frostRoundWith(setup.frost, signerIDs, message[:], malformed, first, true, true)
	result.RejectedInvalid += rejected
	result.SignatureOperations += sigOps
	result.VerificationOperations += verifyOps
	if !ok {
		result.Success = false
	}
	for k, id := range signerIDs {
		share := make([]byte, 32)
		mark = time.Now()
		envelope := append(append([]byte("APPROVAL"), message[:]...), share...)
		sig := ed25519.Sign(setup.identityPriv[id], envelope)
		result.SignatureOperations++
		follower[k] += time.Since(mark)
		mark = time.Now()
		if !ed25519.Verify(setup.identityPub[id], envelope, sig) {
			result.Success = false
		}
		result.VerificationOperations++
		leaderWork += time.Since(mark)
	}
	var viewChange time.Duration
	if scenario == scenarioLeader {
		viewMessage := append([]byte("VIEW-CHANGE"), message[:]...)
		signTimes := make([]time.Duration, len(signerIDs))
		var collect time.Duration
		for k, id := range signerIDs {
			mark = time.Now()
			sig := ed25519.Sign(setup.identityPriv[id], viewMessage)
			result.SignatureOperations++
			signTimes[k] = time.Since(mark)
			mark = time.Now()
			if !ed25519.Verify(setup.identityPub[id], viewMessage, sig) {
				result.Success = false
			}
			result.VerificationOperations++
			collect += time.Since(mark)
		}
		ok2, _, sigOps2, verifyOps2, _, critical2 := frostRoundWith(setup.frost, signerIDs, message[:], 0, second, true, true)
		result.SignatureOperations += sigOps2
		result.VerificationOperations += verifyOps2
		if !ok2 {
			result.Success = false
		}
		viewChange = maxDuration(signTimes) + collect + critical2
	}
	result.ProcessingDuration = time.Since(started)
	result.CriticalPath = sequential + maxDuration(follower) + critical + leaderWork + viewChange

	approvalBytes := 32 + ed25519.SignatureSize + 32 + 32
	proposalBytes := len(payload) + len(bsSig) + len(leaderSig) + 96
	result.CertificateBytesActual = 64 + 4*t + 56
	result.CertificateBytesPaper = result.CertificateBytesActual
	result.VoteOrApprovalBytes = approvalBytes
	result.ApplicationMessages = uint64(2 + t)
	result.NetworkDeliveries = uint64(2*(n-1) + t)
	result.NetworkBytes = uint64(proposalBytes*(n-1) + approvalBytes*t + result.CertificateBytesActual*(n-1))
	if scenario == scenarioLeader {
		viewChangeBytes := 32 + ed25519.SignatureSize + 32
		result.ApplicationMessages += uint64(t + 2*(t-1))
		result.NetworkDeliveries += uint64(t + 2*(t-1))
		result.NetworkBytes += uint64(viewChangeBytes*t + (32+32)*(t-1) + approvalBytes*(t-1))
	}
	if scenario == scenarioMalformed {
		result.ApplicationMessages += uint64(f)
		result.NetworkDeliveries += uint64(f)
		result.NetworkBytes += uint64(approvalBytes * f)
	}
	result.ImplementationNote = "Proposed framework with threshold Schnorr (FROST over Edwards25519, RFC 8032 challenge): one signing round with preprocessed nonce commitments, public key shares computed once, Ed25519 approval envelopes, certificate checked with the standard Ed25519 verifier."
	return result
}
