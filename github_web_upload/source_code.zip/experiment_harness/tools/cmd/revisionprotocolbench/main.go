// Command revisionprotocolbench is protocolbench with three additional
// options for the revision: -fault-bound overrides f, -loss-margin sets the
// loss margin u (threshold t = n - f - u, requiring n >= 3f + 2u + 1), and
// -seed-start selects the first seed so that an external harness can run one
// seed per process. With the defaults it behaves exactly like protocolbench.
package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"uav-bft/internal/attack"
	experimentlog "uav-bft/internal/logging"
	"uav-bft/internal/simulation"
	"uav-bft/internal/transport"
)

type report struct {
	ModelNotice string                         `json:"model_notice"`
	Parameters  map[string]any                 `json:"parameters"`
	Results     []experimentlog.ProtocolResult `json:"results"`
}

func parseIntegerList(value string) ([]int, error) {
	parts := strings.Split(value, ",")
	values := make([]int, 0, len(parts))
	seen := make(map[int]struct{})
	for _, part := range parts {
		parsed, err := strconv.Atoi(strings.TrimSpace(part))
		if err != nil || parsed <= 0 {
			return nil, fmt.Errorf("invalid positive integer %q", part)
		}
		if _, exists := seen[parsed]; exists {
			continue
		}
		seen[parsed] = struct{}{}
		values = append(values, parsed)
	}
	if len(values) == 0 {
		return nil, fmt.Errorf("list is empty")
	}
	return values, nil
}

func profilesFromNames(value string) ([]transport.Profile, error) {
	profiles := make([]transport.Profile, 0)
	for _, name := range strings.Split(value, ",") {
		switch strings.TrimSpace(name) {
		case "ideal":
			profiles = append(profiles, transport.IdealProfile())
		case "wifi_light":
			profiles = append(profiles, transport.LightWiFiProfile())
		case "wifi_stressed":
			profiles = append(profiles, transport.StressedWiFiProfile())
		default:
			return nil, fmt.Errorf("unknown network profile %q", name)
		}
	}
	return profiles, nil
}

func planForLabel(label string, nodeCount, faultBound int) (attack.Plan, error) {
	switch label {
	case "follower_silence_f", "follower_silence_f_plus_1":
		plan := attack.NewPlan(attack.FollowerSilence)
		unavailable := faultBound
		if label == "follower_silence_f_plus_1" {
			unavailable++
		}
		for offset := 0; offset < unavailable && offset < nodeCount; offset++ {
			plan.SilentNodes[uint32(nodeCount-1-offset)] = struct{}{}
		}
		return plan, nil
	default:
		scenario, err := attack.ParseScenario(label)
		if err != nil {
			return attack.Plan{}, err
		}
		return attack.NewPlan(scenario), nil
	}
}

func main() {
	var (
		sizesText = flag.String(
			"sizes",
			"4,10,20,50,100",
			"comma-separated swarm sizes",
		)
		profilesText = flag.String(
			"profiles",
			"ideal,wifi_light,wifi_stressed",
			"comma-separated deterministic network profiles",
		)
		scenariosText = flag.String(
			"scenarios",
			strings.Join([]string{
				"benign",
				"proposal_withholding",
				"selective_proposal",
				"approval_dropping",
				"certificate_withholding",
				"forged_approval",
				"signer_substitution",
				"follower_silence_f",
				"follower_silence_f_plus_1",
			}, ","),
			"comma-separated protocol scenarios",
		)
		rounds = flag.Int(
			"rounds",
			50,
			"command rounds per configuration and seed",
		)
		seedCount = flag.Int(
			"seed-count",
			10,
			"number of deterministic seeds",
		)
		payloadBytes = flag.Int(
			"payload-bytes",
			32,
			"command payload bytes",
		)
		faultOverride = flag.Int(
			"fault-bound",
			-1,
			"Byzantine bound f; -1 uses (n-1)/3",
		)
		lossMargin = flag.Int(
			"loss-margin",
			0,
			"loss margin u; threshold t = n - f - u",
		)
		signerSet = flag.Bool(
			"signer-set",
			false,
			"threshold Schnorr (FROST) semantics: fixed signer set, every member must answer",
		)
		signerRetries = flag.Int(
			"signer-retries",
			2,
			"re-requests of a missing share per signer and session (with -signer-set)",
		)
		maxSessions = flag.Int(
			"max-sessions",
			4,
			"signing sessions per view (with -signer-set)",
		)
		seedStart = flag.Int(
			"seed-start",
			1,
			"first deterministic seed",
		)
		viewTimeout = flag.Duration(
			"view-timeout",
			150*time.Millisecond,
			"protocol view timeout",
		)
		outputCSV = flag.String(
			"output",
			"results/protocol_scaling.csv",
			"CSV output path",
		)
		outputJSON = flag.String(
			"json",
			"results/protocol_scaling.json",
			"JSON output path",
		)
	)
	flag.Parse()

	if *rounds <= 0 || *seedCount <= 0 || *seedStart <= 0 || *lossMargin < 0 {
		fmt.Fprintln(os.Stderr, "rounds and seed-count must be positive")
		os.Exit(2)
	}

	sizes, err := parseIntegerList(*sizesText)
	if err != nil {
		fmt.Fprintln(os.Stderr, "sizes:", err)
		os.Exit(2)
	}
	profiles, err := profilesFromNames(*profilesText)
	if err != nil {
		fmt.Fprintln(os.Stderr, "profiles:", err)
		os.Exit(2)
	}

	scenarioLabels := make([]string, 0)
	for _, label := range strings.Split(*scenariosText, ",") {
		trimmed := strings.TrimSpace(label)
		if trimmed != "" {
			scenarioLabels = append(scenarioLabels, trimmed)
		}
	}
	if len(scenarioLabels) == 0 {
		fmt.Fprintln(os.Stderr, "scenario list is empty")
		os.Exit(2)
	}

	rows := make([]experimentlog.ProtocolResult, 0)
	fmt.Println("Application-layer protocol simulation only.")
	fmt.Println("The saved n=50 and n=100 GJKR DKG runs are not executed.")

	for _, nodeCount := range sizes {
		faultBound := (nodeCount - 1) / 3
		if *faultOverride >= 0 {
			faultBound = *faultOverride
		}
		if nodeCount < 3*faultBound+2*(*lossMargin)+1 {
			fmt.Fprintf(os.Stderr, "n=%d violates n >= 3f+2u+1 for f=%d, u=%d\n", nodeCount, faultBound, *lossMargin)
			os.Exit(2)
		}
		threshold := nodeCount - faultBound - *lossMargin
		for _, profile := range profiles {
			for _, scenarioLabel := range scenarioLabels {
				plan, err := planForLabel(
					scenarioLabel,
					nodeCount,
					faultBound,
				)
				if err != nil {
					fmt.Fprintln(os.Stderr, err)
					os.Exit(2)
				}

				for seedIndex := 0; seedIndex < *seedCount; seedIndex++ {
					seed := int64(seedIndex + *seedStart)
					config := simulation.DefaultConfig()
					config.NodeCount = nodeCount
					config.Threshold = threshold
					config.Rounds = *rounds
					config.Seed = seed
					config.Network = profile
					config.Attack = plan
					config.PayloadBytes = *payloadBytes
					config.ViewTimeout = *viewTimeout
					config.SignerSet = *signerSet
					config.SignerRetries = *signerRetries
					config.MaxSessions = *maxSessions
					config.MaxViews = faultBound + 3
					if config.MaxViews < 3 {
						config.MaxViews = 3
					}

					result, err := simulation.Run(config)
					if err != nil {
						fmt.Fprintf(
							os.Stderr,
							"n=%d profile=%s scenario=%s seed=%d: %v\n",
							nodeCount,
							profile.Name,
							scenarioLabel,
							seed,
							err,
						)
						os.Exit(1)
					}

					rows = append(rows, experimentlog.ProtocolResult{
						NodeCount:            nodeCount,
						FaultBound:           faultBound,
						Threshold:            threshold,
						Profile:              profile.Name,
						Scenario:             scenarioLabel,
						Seed:                 seed,
						Rounds:               *rounds,
						Successes:            result.Successes,
						SuccessRate:          result.SuccessRate,
						MeanLatencyMS:        float64(result.MeanLatency) / float64(time.Millisecond),
						P95LatencyMS:         float64(result.P95Latency) / float64(time.Millisecond),
						MeanViews:            result.MeanViews,
						LogicalMessages:      result.Network.SentMessages,
						ApplicationBytes:     result.Network.SentBytes,
						DroppedMessages:      result.Network.DroppedMessages,
						DuplicateMessages:    result.Network.DuplicateMessages,
						ReorderedMessages:    result.Network.ReorderedMessages,
						RejectedMessages:     result.RejectedMessages,
						TimeoutCertificates:  result.TimeoutCertificates,
						CertificateReceivers: result.CertificateReceivers,
						Model:                "deterministic-go-application-layer",
					})
				}
			}
		}
		fmt.Printf("Completed n=%d, f=%d, t=%d\n", nodeCount, faultBound, threshold)
	}

	if err := experimentlog.WriteProtocolCSV(*outputCSV, rows); err != nil {
		fmt.Fprintln(os.Stderr, "write CSV:", err)
		os.Exit(1)
	}

	reportValue := report{
		ModelNotice: "Deterministic application-layer protocol model; not ns-3, MAC, fading, routing, mobility, or PX4 flight data.",
		Parameters: map[string]any{
			"sizes":         sizes,
			"profiles":      strings.Split(*profilesText, ","),
			"scenarios":     scenarioLabels,
			"rounds":        *rounds,
			"seed_count":    *seedCount,
			"payload_bytes": *payloadBytes,
			"view_timeout":  viewTimeout.String(),
			"fault_bound":   *faultOverride,
			"loss_margin":   *lossMargin,
			"seed_start":    *seedStart,
			"signer_set":    *signerSet,
		},
		Results: rows,
	}
	if err := experimentlog.WriteJSON(*outputJSON, reportValue); err != nil {
		fmt.Fprintln(os.Stderr, "write JSON:", err)
		os.Exit(1)
	}

	absoluteCSV, _ := filepath.Abs(*outputCSV)
	absoluteJSON, _ := filepath.Abs(*outputJSON)
	fmt.Println("Saved CSV:", absoluteCSV)
	fmt.Println("Saved JSON:", absoluteJSON)
	fmt.Println("Rows:", len(rows))
}
