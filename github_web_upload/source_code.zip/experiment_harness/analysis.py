"""Analysis of a campaign directory produced by run_all.py.

Writes <campaign>/analysis/: summary CSVs (in the schemas of the published
results), LaTeX table bodies, figures with 95% confidence intervals,
failures.csv, and REPORT.md with the main numbers.
"""
import json, os
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import StrMethodFormatter

NAMES = {"proposed_threshold_bls": "Proposed",
         "wang_fhotstuff_frost_independent": "FHotStuff+FROST [Wang et al.]",
         "huo_inspired_authenticated_pbft": "Authenticated PBFT [Huo et al.]"}
STYLE = {"proposed_threshold_bls": dict(color="#1f5fd6", ls="-", marker="o"),
         "wang_fhotstuff_frost_independent": dict(color="#e8383d", ls="--", marker="s"),
         "huo_inspired_authenticated_pbft": dict(color="#16a37f", ls="-.", marker="D")}
FORMULA = {"proposed_threshold_bls": ("2(n-1)+t", lambda n, t: 2 * (n - 1) + t),
           "wang_fhotstuff_frost_independent": ("3(n-1)+3t", lambda n, t: 3 * (n - 1) + 3 * t),
           "huo_inspired_authenticated_pbft": ("(n-1)(2n+1)", lambda n, t: (n - 1) * (2 * n + 1))}
MOCK_MARK = "MOCK DATA - NOT FOR PUBLICATION"


# ----------------------------------------------------------------------------- helpers
def load(base):
    recs = {}
    path = os.path.join(base, "runs.jsonl")
    if not os.path.exists(path):
        return pd.DataFrame()
    with open(path, encoding="utf-8") as fh:
        for ln in fh:
            try:
                r = json.loads(ln)
            except json.JSONDecodeError:
                continue
            prev = recs.get(r["key"])
            if prev is None or prev["status"] == "exec_error" or r["status"] != "exec_error":
                recs[r["key"]] = r
    rows = []
    for r in recs.values():
        row = {k: v for k, v in r.items() if k != "metrics"}
        for k, v in r.get("metrics", {}).items():
            row["m_" + k] = v
        rows.append(row)
    return pd.DataFrame(rows)


def ci95(x):
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    if len(x) < 2:
        return np.nan
    return stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))


def num(df, col):
    return pd.to_numeric(df[col], errors="coerce") if col in df else pd.Series(np.nan, index=df.index)


def mean_sd(x):
    x = pd.to_numeric(x, errors="coerce").dropna()
    return (x.mean(), x.std(ddof=1) if len(x) > 1 else np.nan, ci95(x), len(x))


def watermark(fig, mock):
    if mock:
        fig.text(0.5, 0.5, MOCK_MARK, rotation=25, alpha=0.25, fontsize=26, color="red",
                 ha="center", va="center", weight="bold")


def tex_header(mock):
    return ("% " + MOCK_MARK + "\n") if mock else ""


def boot_reduction(p, b, B=10000, seed=7):
    """95% percentile bootstrap CI of 1 - mean(p)/mean(b), resampling trials."""
    p, b = np.asarray(p, float), np.asarray(b, float)
    if len(p) < 2 or len(b) < 2:
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    mp = rng.choice(p, (B, len(p))).mean(1)
    mb = rng.choice(b, (B, len(b))).mean(1)
    r = 1 - mp / mb
    return tuple(np.percentile(r, [2.5, 97.5]))


# ----------------------------------------------------------------------------- baseline
def analyze_baseline(df, out, mock, rep):
    d = df[df.experiment == "baseline"].copy()
    if d.empty:
        return
    d["ok"] = d.status == "ok"
    for c in ["processing_ms", "total_latency_ms", "critical_path_ms", "network_bytes",
              "network_deliveries", "application_messages", "certificate_bytes", "rejected_invalid",
              "signature_operations", "verification_operations"]:
        d[c] = num(d, "m_" + c)
    d.sort_values(["method", "scenario", "n", "trial"]).drop(columns=[c for c in d if c.startswith("m_")]) \
        .to_csv(os.path.join(out, "baseline_trials.csv"), index=False)

    rows = []
    for (m, sc, n), g in d.groupby(["method", "scenario", "n"]):
        ok = g[g.ok]
        pm, ps, pc, _ = mean_sd(ok.processing_ms)
        cm, cs, cc, cnt = mean_sd(ok.critical_path_ms)
        tm, ts, _, _ = mean_sd(ok.total_latency_ms)
        bm, bs, _, _ = mean_sd(ok.network_bytes)
        rows.append(dict(
            method=m, scenario=sc, nodes=n, threshold=int(g.t.iloc[0]), faulty_nodes=int(g.f.iloc[0]),
            trials=len(g), validated=len(ok), success_rate_pct=100.0 * len(ok) / len(g),
            mean_processing_ms=pm, std_processing_ms=ps,
            mean_total_latency_ms=tm, std_total_latency_ms=ts,
            mean_network_bytes=bm, std_network_bytes=bs,
            mean_network_deliveries=ok.network_deliveries.mean(),
            mean_application_messages=ok.application_messages.mean(),
            mean_certificate_bytes_actual=ok.certificate_bytes.mean(),
            mean_rejected_invalid=ok.rejected_invalid.mean(),
            mean_signature_operations=ok.signature_operations.mean(),
            mean_verification_operations=ok.verification_operations.mean(),
            ci95_processing_ms=pc, median_processing_ms=ok.processing_ms.median(),
            p95_processing_ms=ok.processing_ms.quantile(0.95) if len(ok) else np.nan,
            mean_critical_path_ms=cm, std_critical_path_ms=cs, ci95_critical_path_ms=cc,
            protocol_failures=int((g.status == "protocol_failure").sum()),
            exec_errors=int((g.status == "exec_error").sum())))
    s = pd.DataFrame(rows)
    s.to_csv(os.path.join(out, "baseline_summary.csv"), index=False)

    methods = [m for m in NAMES if m in set(s.method)] + sorted(set(s.method) - set(NAMES))
    nm = s[s.scenario == "normal"]
    if nm.empty:
        return
    trials_per = int(nm.validated.min())

    def table(metric, fname):
        lines = []
        for n in sorted(nm.nodes.unique()):
            cells = [str(int(n))]
            for m in methods:
                r = nm[(nm.method == m) & (nm.nodes == n)]
                if r.empty or np.isnan(r["mean_" + metric].iloc[0]):
                    cells += ["--", "--"]
                    continue
                r = r.iloc[0]
                mu, sd, c = r["mean_" + metric], r["std_" + metric], r["ci95_" + metric]
                cells.append(f"{mu:.2f} $\\pm$ {sd:.2f}")
                cells.append(f"[{mu - c:.2f}, {mu + c:.2f}]")
            lines.append(" & ".join(cells) + r"\\")
        with open(os.path.join(out, fname), "w", encoding="utf-8") as fh:
            fh.write(tex_header(mock) + "\n".join(lines) + "\n")

    table("processing_ms", "table_baseline_ci.tex")
    has_cp = nm.mean_critical_path_ms.notna().any()
    if has_cp:
        table("critical_path_ms", "table_baseline_critical_path_ci.tex")

    def figs(metric, label, f13, f14):
        fig, ax = plt.subplots(1, 3, figsize=(15, 3.9))
        for m in methods:
            g = nm[nm.method == m].sort_values("nodes")
            st = STYLE.get(m, {})
            ax[0].errorbar(g.nodes, g["mean_" + metric], yerr=g["ci95_" + metric], capsize=4, lw=1.6,
                           ms=5, label=NAMES.get(m, m), **st)
            ax[1].plot(g.nodes, g.mean_network_bytes, lw=1.6, ms=5, **st)
            ax[2].plot(g.nodes, g.mean_network_deliveries, lw=1.6, ms=5, **st)
        for a, yl, tag in zip(ax, [label, "Network traffic (bytes)", "Message deliveries"], "abc"):
            a.set_xlabel("Node count, n"); a.set_ylabel(yl); a.grid(alpha=.3, ls="--")
            a.text(-0.12, -0.2, f"({tag})", transform=a.transAxes, fontweight="bold", fontsize=12)
        ax[1].yaxis.set_major_formatter(StrMethodFormatter("{x:,.0f}"))
        ax[2].yaxis.set_major_formatter(StrMethodFormatter("{x:,.0f}"))
        fig.legend(*ax[0].get_legend_handles_labels(), loc="upper center", ncol=3, bbox_to_anchor=(0.5, 1.02))
        fig.tight_layout(rect=(0, 0, 1, 0.93)); watermark(fig, mock)
        fig.savefig(os.path.join(out, f13), dpi=200); plt.close(fig)

        nmax = nm.nodes.max()
        g = nm[nm.nodes == nmax].set_index("method").reindex(methods)
        fig, a = plt.subplots(figsize=(6.2, 4.2))
        bars = a.bar([NAMES.get(m, m).replace(" [", "\n[") for m in methods], g["mean_" + metric],
                     yerr=g["ci95_" + metric], capsize=8, edgecolor="black", hatch="//", alpha=.85,
                     color=[STYLE.get(m, {}).get("color", "gray") for m in methods])
        top = (g["mean_" + metric] + g["ci95_" + metric]).max()
        for b_, mu, c in zip(bars, g["mean_" + metric], g["ci95_" + metric]):
            a.text(b_.get_x() + b_.get_width() / 2, mu + c + top * 0.02,
                   f"{mu:.1f}\n[{mu - c:.1f}, {mu + c:.1f}]", ha="center", va="bottom", fontsize=8.5)
        a.set_ylabel(f"{label.split(' (')[0]} at n = {nmax} (ms)"); a.set_ylim(0, top * 1.25)
        a.grid(axis="y", alpha=.3, ls="--")
        a.set_title(f"Mean of {trials_per}+ trials; error bars: 95% confidence interval", fontsize=9)
        fig.tight_layout(); watermark(fig, mock)
        fig.savefig(os.path.join(out, f14), dpi=200); plt.close(fig)

    figs("processing_ms", "Processing latency (ms)", "fig_11_published_baseline_scaling_ci.png",
         "fig_12_published_baseline_latency_n100_ci.png")
    if has_cp:
        figs("critical_path_ms", "Critical-path latency (ms)", "fig_11b_baseline_critical_path_ci.png",
             "fig_12b_baseline_critical_path_n100_ci.png")

    # reductions at the largest swarm
    nmax = int(nm.nodes.max())
    prop = "proposed_threshold_bls"
    ok = d[(d.scenario == "normal") & (d.n == nmax) & d.ok]
    rep.append(f"## Baseline comparison (normal operation, n = {nmax})\n")
    rep.append(f"Trials per condition (validated, minimum): **{trials_per}**. "
               "\n")
    rep.append("| Method | Processing latency (ms), mean ± SD | 95% CI |" + (" Critical path (ms), mean ± SD | 95% CI |" if has_cp else ""))
    rep.append("|---|---|---|" + ("---|---|" if has_cp else ""))
    for m in methods:
        r = nm[(nm.method == m) & (nm.nodes == nmax)].iloc[0]
        line = (f"| {NAMES.get(m, m)} | {r.mean_processing_ms:.2f} ± {r.std_processing_ms:.2f} | "
                f"[{r.mean_processing_ms - r.ci95_processing_ms:.2f}, {r.mean_processing_ms + r.ci95_processing_ms:.2f}] |")
        if has_cp:
            line += (f" {r.mean_critical_path_ms:.2f} ± {r.std_critical_path_ms:.2f} | "
                     f"[{r.mean_critical_path_ms - r.ci95_critical_path_ms:.2f}, {r.mean_critical_path_ms + r.ci95_critical_path_ms:.2f}] |")
        rep.append(line)
    rep.append("")
    if prop in methods:
        p_row = nm[(nm.method == prop) & (nm.nodes == nmax)].iloc[0]
        for m in methods:
            if m == prop:
                continue
            b_row = nm[(nm.method == m) & (nm.nodes == nmax)].iloc[0]
            for metric, lab in [("processing_ms", "processing latency")] + ([("critical_path_ms", "critical-path latency")] if has_cp else []):
                pm, bm = p_row["mean_" + metric], b_row["mean_" + metric]
                pc, bc = p_row["ci95_" + metric], b_row["ci95_" + metric]
                lo, hi = boot_reduction(ok[ok.method == prop][metric].dropna(), ok[ok.method == m][metric].dropna())
                rep.append(f"- {lab} reduction vs {NAMES.get(m, m)}: **{100 * (1 - pm / bm):.2f}%** "
                           f"(bootstrap 95% CI {100 * lo:.1f}-{100 * hi:.1f}%; conservative endpoint range "
                           f"{100 * (1 - (pm + pc) / (bm - bc)):.1f}-{100 * (1 - (pm - pc) / (bm + bc)):.1f}%)")
            rep.append(f"- traffic reduction vs {NAMES.get(m, m)}: **{100 * (1 - p_row.mean_network_bytes / b_row.mean_network_bytes):.2f}%**; "
                       f"delivery reduction: **{100 * (1 - p_row.mean_network_deliveries / b_row.mean_network_deliveries):.2f}%**")

    # delivery-count check of the per-message model
    conf = []
    for m, (txt, fn) in FORMULA.items():
        g = nm[nm.method == m]
        for _, r in g.iterrows():
            conf.append((m, int(r.nodes), r.mean_network_deliveries, fn(r.nodes, r.threshold), txt))
    if conf:
        bad = [c for c in conf if not np.isclose(c[2], c[3])]
        rep.append("Delivery-count check (the benchmark computes deliveries from its per-message model, so this "
                   "checks the model against the protocol formulas; it is not an independent measurement): "
                   + ("**all match**." if not bad else "**mismatches:** " +
                      "; ".join(f"{NAMES.get(m, m)} n={n}: measured {a:.0f}, formula {txt} = {b:.0f}" for m, n, a, b, txt in bad)) + "\n")

    # success per scenario
    rep.append("Success per scenario (validated/attempted, all sizes): " + "; ".join(
        f"{NAMES.get(m, m)} {sc}: {int(g.validated.sum())}/{int(g.trials.sum())}"
        for (m, sc), g in s.groupby(["method", "scenario"])) + "\n")


# ----------------------------------------------------------------------------- dkg
def analyze_dkg(df, out, mock, rep):
    d = df[df.experiment == "dkg"].copy()
    if d.empty:
        return
    cols = ["qual_size", "dkg_ms", "deal_objects", "response_objects", "response_deliveries",
            "secret_commit_deliveries", "partial_sign_verify_ms", "reconstruction_ms", "final_verification_ms"]
    for c in cols:
        d[c] = num(d, "m_" + c)
    d["gjkr_status"] = np.where(d.status == "ok", "passed", d.status)
    d.sort_values(["n", "run"])[["n", "f", "t", "run", "gjkr_status"] + cols + ["wall_s", "loadavg_1m"]] \
        .to_csv(os.path.join(out, "dkg_runs.csv"), index=False)
    ok = d[d.status == "ok"]
    rows = []
    for n, g in ok.groupby("n"):
        row = dict(n=n, runs=len(g))
        for c in ["dkg_ms", "partial_sign_verify_ms", "reconstruction_ms", "final_verification_ms"]:
            mu, sd, c95, _ = mean_sd(g[c])
            row.update({f"mean_{c}": mu, f"std_{c}": sd, f"ci95_{c}": c95})
        for c in ["deal_objects", "response_deliveries", "secret_commit_deliveries"]:
            row[f"mean_{c}"] = g[c].mean()
        rows.append(row)
    s = pd.DataFrame(rows).sort_values("n")
    s.to_csv(os.path.join(out, "dkg_summary.csv"), index=False)

    lines = []
    for _, r in s.iterrows():
        mu, sd, c = r.mean_dkg_ms / 1000, r.std_dkg_ms / 1000, r.ci95_dkg_ms / 1000
        cv = 100 * r.std_dkg_ms / r.mean_dkg_ms if r.mean_dkg_ms else np.nan
        lines.append(f"{int(r.n)} & {int(r.runs)} & {mu:.2f} $\\pm$ {sd:.2f} & [{mu - c:.2f}, {mu + c:.2f}] & {cv:.1f}\\%\\\\")
    with open(os.path.join(out, "table_dkg.tex"), "w", encoding="utf-8") as fh:
        fh.write(tex_header(mock) + "% columns: n & runs & mean +- SD (s) & 95% CI (s) & coefficient of variation\n"
                 + "\n".join(lines) + "\n")

    fig, ax = plt.subplots(1, 3, figsize=(15, 3.9))
    ax[0].errorbar(s.n, s.mean_dkg_ms, yerr=s.ci95_dkg_ms, color="#1f5fd6", marker="o", capsize=4)
    ax[0].set_yscale("log"); ax[0].set_ylabel("DKG time (ms)")
    for c, lab, st in [("deal_objects", "Deal messages", dict(color="#16a37f", marker="o")),
                       ("response_deliveries", "Response deliveries", dict(color="#1f5fd6", marker="s", ls="--")),
                       ("secret_commit_deliveries", "Commit deliveries", dict(color="#e8383d", marker="D", ls="-."))]:
        ax[1].plot(s.n, s["mean_" + c], label=lab, **st)
    ax[1].set_ylabel("Messages / deliveries"); ax[1].legend(); ax[1].yaxis.set_major_formatter(StrMethodFormatter("{x:,.0f}"))
    for c, lab, st in [("partial_sign_verify_ms", "Partial sign + verify", dict(color="#16a37f", marker="o")),
                       ("reconstruction_ms", "Signature recovery", dict(color="#e8383d", marker="s", ls="--")),
                       ("final_verification_ms", "Final verification", dict(color="#1f5fd6", marker="D"))]:
        ax[2].errorbar(s.n, s["mean_" + c], yerr=s["ci95_" + c], capsize=3, label=lab, **st)
    ax[2].set_ylabel("Latency (ms)"); ax[2].legend()
    for a, tag in zip(ax, "abc"):
        a.set_xlabel("Node count, n"); a.grid(alpha=.3, ls="--")
        a.text(-0.12, -0.2, f"({tag})", transform=a.transAxes, fontweight="bold", fontsize=12)
    fig.tight_layout(); watermark(fig, mock)
    fig.savefig(os.path.join(out, "fig_01_crypto_scaling_ci.png"), dpi=200); plt.close(fig)

    rep.append("## Key generation\n")
    for _, r in s.iterrows():
        rep.append(f"- n = {int(r.n)}: {r.mean_dkg_ms / 1000:.2f} ± {r.std_dkg_ms / 1000:.2f} s over {int(r.runs)} runs "
                   f"(95% CI {(r.mean_dkg_ms - r.ci95_dkg_ms) / 1000:.2f}-{(r.mean_dkg_ms + r.ci95_dkg_ms) / 1000:.2f} s)")
    rep.append("")


# ----------------------------------------------------------------------------- loss margin
def analyze_loss_margin(df, out, mock, rep):
    d = df[df.experiment == "loss_margin"].copy()
    if d.empty:
        return
    for c in ["rounds", "successes", "mean_views", "logical_messages", "dropped_messages", "mean_latency_ms"]:
        d[c] = num(d, "m_" + c)
    d = d[d.status != "exec_error"]
    d["success_rate"] = d.successes / d.rounds
    d.drop(columns=[c for c in d if c.startswith("m_")]).to_csv(os.path.join(out, "loss_margin_runs.csv"), index=False)
    ben = d[d.scenario == "benign"]
    loss = {}
    if ben.dropped_messages.notna().any():
        for p, g in ben.groupby("profile"):
            loss[p] = (g.dropped_messages / (g.dropped_messages + g.logical_messages)).mean()
    rows = []
    sil = d[d.scenario == "follower_silence_f"]
    for (f, u, t, p), g in sil.groupby(["f", "u", "t", "profile"]):
        n = int(g.n.iloc[0])
        mu, sd, c, k = mean_sd(g.success_rate)
        pred = np.nan
        if p in loss:
            # one view succeeds if at least t-1 of the n-f-1 correct followers both receive
            # the proposal and return an approval (q_a = (1-l)^2), and the certificate reaches
            # at least t-1 of them (q_c = 1-l); silent members count for neither (see the
            # emulator: DeliverApproval / DeliverCertificate exclude silent nodes)
            m = n - int(f) - 1
            pred = stats.binom.sf(int(t) - 2, m, (1 - loss[p]) ** 2) * stats.binom.sf(int(t) - 2, m, 1 - loss[p])
        rows.append(dict(n=n, f=int(f), u=int(u), t=int(t), profile=p, seeds=k, measured_success=mu,
                         std_success=sd, ci95_success=c, mean_views=g.mean_views.mean(),
                         measured_loss=loss.get(p, np.nan), predicted_single_view=pred))
    s = pd.DataFrame(rows).sort_values(["f", "profile"], ascending=[False, True])
    s.to_csv(os.path.join(out, "loss_margin_summary.csv"), index=False)
    lines = [f"{r.f} & {r.u} & {r.t} & {r.profile.replace('_', '-')} & {r.measured_success:.3f} $\\pm$ {r.std_success:.3f} & "
             f"{r.predicted_single_view:.3f} & {r.mean_views:.2f}\\\\" for r in s.itertuples()]
    with open(os.path.join(out, "table_loss_margin_measured.tex"), "w", encoding="utf-8") as fh:
        fh.write(tex_header(mock) + "% columns: f & u & t & profile & measured success (mean +- SD over seeds) & predicted single-view & mean views\n"
                 + "\n".join(lines) + "\n")

    profiles = list(dict.fromkeys(s.profile))
    confs = list(dict.fromkeys(zip(s.f, s.u)))
    fig, a = plt.subplots(figsize=(8, 4))
    w = 0.8 / len(confs)
    for i, (f, u) in enumerate(confs):
        g = s[(s.f == f) & (s.u == u)].set_index("profile").reindex(profiles)
        x = np.arange(len(profiles)) + i * w
        a.bar(x, g.measured_success, w * 0.9, yerr=g.ci95_success, capsize=3, label=f"measured f={f}, u={u}")
        a.scatter(x + w * 0.28, g.predicted_single_view, marker="D", s=38, facecolor="white",
                  edgecolor="black", zorder=4, label="predicted (single view)" if i == 0 else None)
    a.set_xticks(np.arange(len(profiles)) + w * (len(confs) - 1) / 2); a.set_xticklabels(profiles)
    a.set_ylabel("Certification success"); a.set_ylim(0, 1.1); a.legend(fontsize=8); a.grid(axis="y", alpha=.3, ls="--")
    fig.tight_layout(); watermark(fig, mock)
    fig.savefig(os.path.join(out, "fig_loss_margin_measured.png"), dpi=200); plt.close(fig)

    rep.append("## Loss margin with f silent Byzantine UAVs\n")
    rep.append("| f | u | t | profile | measured success (mean ± SD) | predicted single view | mean views |")
    rep.append("|---|---|---|---|---|---|---|")
    for r in s.itertuples():
        rep.append(f"| {r.f} | {r.u} | {r.t} | {r.profile} | {r.measured_success:.3f} ± {r.std_success:.3f} | "
                   f"{r.predicted_single_view:.3f} | {r.mean_views:.2f} |")
    if loss:
        rep.append("\nMeasured per-message loss (benign runs): " + ", ".join(f"{p} {100 * v:.2f}%" for p, v in loss.items()))
    rep.append("")


# ----------------------------------------------------------------------------- custom
def analyze_custom(df, out, mock, rep):
    d = df[df.experiment == "custom"].copy()
    if d.empty:
        return
    mcols = [c for c in d if c.startswith("m_")]
    rows = []
    for item, g in d[d.status == "ok"].groupby("item"):
        for c in [c for c in mcols if c.endswith("_ms")]:
            x = pd.to_numeric(g[c], errors="coerce").dropna()
            if len(x):
                mu, sd, c95, k = mean_sd(x)
                rows.append(dict(item=item, metric=c[2:], runs=k, mean=mu, std=sd, ci95=c95))
    s = pd.DataFrame(rows)
    s.to_csv(os.path.join(out, "custom_summary.csv"), index=False)
    rep.append("## Custom experiments\n")
    for r in s.itertuples():
        rep.append(f"- {r.item} / {r.metric}: {r.mean:.3f} ± {r.std:.3f} (n = {r.runs})")
    rep.append("")


# ----------------------------------------------------------------------------- entry
def analyze(base):
    out = os.path.join(base, "analysis")
    os.makedirs(out, exist_ok=True)
    env = {}
    if os.path.exists(os.path.join(base, "environment.json")):
        with open(os.path.join(base, "environment.json"), encoding="utf-8") as fh:
            env = json.load(fh)
    mock = bool(env.get("mock"))
    df = load(base)
    rep = []
    if mock:
        rep += [f"# {MOCK_MARK}", "", "These results come from the stand-in tools in mock_tools.py. They only show that "
                "the pipeline works. Never report any number from it.", ""]
    rep += ["# Experiments: results report", "",
            f"Campaign: `{os.path.abspath(base)}`  ", f"Host: {env.get('host', '?')}, {env.get('cpu_model', '?')}, "
            f"{env.get('cpu_count', '?')} cores; {env.get('go_version', '')}  ",
            f"Code: `{env.get('repo_dir', '?')}` at commit `{env.get('repo_commit', '') or 'unknown'}`"
            + (" (uncommitted changes)" if env.get("repo_dirty") else ""), ""]
    if df.empty:
        rep.append("No runs recorded.")
    else:
        rep.append("| Experiment | runs | ok | protocol failures | execution errors |")
        rep.append("|---|---|---|---|---|")
        for x, g in df.groupby("experiment"):
            rep.append(f"| {x} | {len(g)} | {(g.status == 'ok').sum()} | {(g.status == 'protocol_failure').sum()} | "
                       f"{(g.status == 'exec_error').sum()} |")
        rep.append("")
        cores = env.get("cpu_count") or 1
        busy = df[(df.experiment.isin(["baseline", "dkg"])) & (pd.to_numeric(df.loadavg_1m, errors="coerce") > 0.5 * cores)]
        if len(busy):
            rep.append(f"Warning: {len(busy)} timing runs started while the 1-minute load average exceeded half the cores; "
                       "close other programs and consider rerunning those conditions.\n")
        analyze_baseline(df, out, mock, rep)
        analyze_dkg(df, out, mock, rep)
        analyze_loss_margin(df, out, mock, rep)
        analyze_custom(df, out, mock, rep)
        fail = df[df.status != "ok"]
        cols = [c for c in ["experiment", "method", "item", "scenario", "profile", "n", "f", "u", "t", "trial", "run",
                            "seed", "status", "failure_reason", "exit_code", "timed_out", "attempts", "command"] if c in fail]
        fail[cols].to_csv(os.path.join(out, "failures.csv"), index=False)
        rep.append("## Failure accounting\n")
        if fail.empty:
            rep.append("No failed runs.")
        else:
            rep.append(f"{len(fail)} runs did not succeed; see failures.csv. By cause:")
            for (st, rs), g in fail.groupby(["status", "failure_reason"]):
                rep.append(f"- {st}: {rs} ({len(g)})")
            rep.append("\nProtocol failures are results (no certificate) and belong in the paper's failure accounting; "
                       "execution errors are harness or tool problems and should be fixed and rerun with --resume.")
    with open(os.path.join(out, "REPORT.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(str(x) for x in rep) + "\n")
    try:
        print("\n".join(str(x) for x in rep[:60]))
    except UnicodeEncodeError:
        print("\n".join(str(x) for x in rep[:60]).encode("ascii", "replace").decode())
    print(f"\nFull report: {os.path.join(out, 'REPORT.md')}")
