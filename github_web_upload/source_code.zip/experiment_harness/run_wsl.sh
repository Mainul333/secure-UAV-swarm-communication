#!/usr/bin/env bash
# Called by run_in_wsl.bat. Runs run_all.py in a private Python environment
# (~/.venvs/uav_revision), so Ubuntu's own Python packages, ~/.local, and
# ROS 2 are never touched.
cd "$(dirname "$0")" || exit 1
VENV="$HOME/.venvs/uav_revision"
if ! "$VENV/bin/python" -m pip --version >/dev/null 2>&1; then
  echo "Creating a private Python environment in $VENV (one time, about a minute)..."
  rm -rf "$VENV"
  mkdir -p "$HOME/.venvs"
  if ! python3 -m venv "$VENV"; then
    rm -rf "$VENV"
    echo
    echo "python3-venv is missing. Install it once in Ubuntu with:"
    echo "    sudo apt install -y python3-venv"
    exit 1
  fi
  "$VENV/bin/python" -m pip install --quiet --disable-pip-version-check --upgrade pip
fi
"$VENV/bin/python" -m pip install --quiet --disable-pip-version-check -r requirements.txt || {
  echo "Installing the Python packages failed (is the internet reachable from WSL?)."; exit 1; }
exec "$VENV/bin/python" run_all.py "$@"
