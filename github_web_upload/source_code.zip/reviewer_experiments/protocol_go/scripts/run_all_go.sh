#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEFAULT_RESULT_ROOT="$(cd "$PROJECT_ROOT/.." && pwd)/results/processed/go_completion"
RESULT_ROOT="${1:-$DEFAULT_RESULT_ROOT}"
LOG_ROOT="$RESULT_ROOT/logs"
BENCH_ROUNDS="${GO_BENCH_ROUNDS:-50}"
BENCH_SEEDS="${GO_BENCH_SEEDS:-10}"
RUN_RACE="${GO_RUN_RACE:-1}"

mkdir -p "$RESULT_ROOT" "$LOG_ROOT"
cd "$PROJECT_ROOT"

SUMMARY="$RESULT_ROOT/completion_summary.txt"
: > "$SUMMARY"

run_step() {
    local name="$1"
    shift
    echo
    echo "========== $name ==========" | tee -a "$SUMMARY"
    "$@" 2>&1 | tee "$LOG_ROOT/${name// /_}.log"
    echo "$name: PASSED" | tee -a "$SUMMARY"
}

printf 'Project: %s\n' "$PROJECT_ROOT" | tee -a "$SUMMARY"
printf 'Results: %s\n' "$RESULT_ROOT" | tee -a "$SUMMARY"
printf 'Go version: ' | tee -a "$SUMMARY"
go version | tee -a "$SUMMARY"
printf 'Protocol benchmark rounds: %s\n' "$BENCH_ROUNDS" | tee -a "$SUMMARY"
printf 'Protocol benchmark seeds: %s\n' "$BENCH_SEEDS" | tee -a "$SUMMARY"

echo "Checking Go formatting..."
UNFORMATTED="$(gofmt -l .)"
if [[ -n "$UNFORMATTED" ]]; then
    echo "The following files are not gofmt-formatted:" >&2
    echo "$UNFORMATTED" >&2
    exit 1
fi
echo "Go formatting: PASSED" | tee -a "$SUMMARY"

run_step "module_dependencies" go mod download
run_step "unit_tests" go test ./... -count=1

if [[ "$RUN_RACE" == "1" ]]; then
    run_step "race_detector" go test ./... -race -count=1
else
    echo "race_detector: SKIPPED (GO_RUN_RACE=$RUN_RACE)" | tee -a "$SUMMARY"
fi

run_step "approval_auth_demo" go run ./cmd/approvalauthdemo
run_step "view_change_demo" go run ./cmd/viewchangedemo
run_step "attack_demo" go run ./cmd/attackdemo
run_step "udp_smoke" go run ./cmd/udpsmoke

run_step "protocol_benchmark" \
    go run ./cmd/protocolbench \
    -sizes 4,10,20,50,100 \
    -rounds "$BENCH_ROUNDS" \
    -seed-count "$BENCH_SEEDS" \
    -output "$RESULT_ROOT/protocol_scaling.csv" \
    -json "$RESULT_ROOT/protocol_scaling.json"

run_step "trust_sensitivity" \
    go run ./cmd/trustbench \
    -sizes 4,10,20,50,100 \
    -seed-count "$BENCH_SEEDS" \
    -observations 100 \
    -output "$RESULT_ROOT/trust_sensitivity.csv"

PARENT_ROOT="$(cd "$PROJECT_ROOT/.." && pwd)"
DKG_HASH_FILE="$PARENT_ROOT/results/processed/dkg_raw_sha256.txt"
if [[ -f "$DKG_HASH_FILE" ]]; then
    echo
    echo "========== saved_DKG_checksums ==========" | tee -a "$SUMMARY"
    if (cd "$PARENT_ROOT" && sha256sum -c results/processed/dkg_raw_sha256.txt) \
        2>&1 | tee "$LOG_ROOT/saved_DKG_checksums.log"; then
        echo "saved_DKG_checksums: PASSED" | tee -a "$SUMMARY"
    else
        echo "saved_DKG_checksums: FAILED" | tee -a "$SUMMARY"
        exit 1
    fi
else
    echo "saved_DKG_checksums: NOT FOUND; no large DKG run was started" | tee -a "$SUMMARY"
fi

cat <<'TEXT' | tee -a "$SUMMARY"

GO STAGE STATUS
Canonical CBOR and domain separation: PASSED
Base-station Ed25519 authorization: PASSED
Leader proposal authentication: PASSED
Persistent one-vote enforcement: PASSED
Honest GJKR and threshold BLS correctness: PASSED
Authenticated approval envelopes: PASSED
Authenticated timeout certificates: PASSED
Leader replacement and persistent-share reuse: PASSED
Protocol attack checks: PASSED
Deterministic delay/loss/duplication/reordering model: PASSED
UDP frame and loopback transport: PASSED
Trust sensitivity output: SAVED
Application-layer scaling output: SAVED

IMPORTANT SCOPE
The scaling CSV is a deterministic Go application-layer model. It is not
ns-3 fading/routing/MAC data and is not PX4/Gazebo flight data. The expensive
n=50 and n=100 GJKR runs were not repeated.
TEXT

echo
printf 'All Go-stage commands completed. Summary: %s\n' "$SUMMARY"
printf 'Protocol CSV: %s\n' "$RESULT_ROOT/protocol_scaling.csv"
printf 'Trust CSV: %s\n' "$RESULT_ROOT/trust_sensitivity.csv"
