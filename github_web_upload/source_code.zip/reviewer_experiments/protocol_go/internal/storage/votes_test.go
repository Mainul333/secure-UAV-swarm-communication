package storage_test

import (
	"bytes"
	"context"
	"crypto/sha256"
	"errors"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"uav-bft/internal/storage"
)

func digest(text string) []byte {
	value := sha256.Sum256([]byte(text))
	return value[:]
}

func openTestStore(t *testing.T) *storage.VoteStore {
	t.Helper()

	path := filepath.Join(t.TempDir(), "votes.db")

	store, err := storage.OpenVoteStore(path)
	if err != nil {
		t.Fatalf("open vote store: %v", err)
	}

	t.Cleanup(func() {
		if err := store.Close(); err != nil {
			t.Errorf("close vote store: %v", err)
		}
	})

	return store
}

func TestCreateAndReuseSameVote(t *testing.T) {
	store := openTestStore(t)
	ctx := context.Background()

	commandDigest := digest("command-A")
	calls := 0

	first, err := store.GetOrCreateVote(
		ctx,
		1,
		7,
		commandDigest,
		func() ([]byte, error) {
			calls++
			return []byte("partial-signature-A"), nil
		},
	)
	if err != nil {
		t.Fatalf("create first vote: %v", err)
	}

	if !first.Created {
		t.Fatal("first vote was not marked as created")
	}

	second, err := store.GetOrCreateVote(
		ctx,
		1,
		7,
		commandDigest,
		func() ([]byte, error) {
			calls++
			return []byte("must-not-be-created"), nil
		},
	)
	if err != nil {
		t.Fatalf("reuse vote: %v", err)
	}

	if second.Created {
		t.Fatal("reused vote was incorrectly marked as new")
	}

	if calls != 1 {
		t.Fatalf("signing callback called %d times; expected 1", calls)
	}

	if !bytes.Equal(
		first.Vote.PartialSignature,
		second.Vote.PartialSignature,
	) {
		t.Fatal("reused partial signature differs from stored signature")
	}
}

func TestConflictingDigestRejectedBeforeSigning(t *testing.T) {
	store := openTestStore(t)
	ctx := context.Background()

	_, err := store.GetOrCreateVote(
		ctx,
		2,
		4,
		digest("command-A"),
		func() ([]byte, error) {
			return []byte("partial-A"), nil
		},
	)
	if err != nil {
		t.Fatalf("create first vote: %v", err)
	}

	conflictingSignerCalled := false

	_, err = store.GetOrCreateVote(
		ctx,
		2,
		4,
		digest("command-B"),
		func() ([]byte, error) {
			conflictingSignerCalled = true
			return []byte("partial-B"), nil
		},
	)

	if !errors.Is(err, storage.ErrConflictingVote) {
		t.Fatalf("expected conflicting-vote error, got %v", err)
	}

	if conflictingSignerCalled {
		t.Fatal("conflicting command reached signing callback")
	}
}

func TestVotePersistsAfterRestart(t *testing.T) {
	path := filepath.Join(t.TempDir(), "persistent-votes.db")
	ctx := context.Background()
	commandDigest := digest("persistent-command")

	firstStore, err := storage.OpenVoteStore(path)
	if err != nil {
		t.Fatalf("open first store: %v", err)
	}

	_, err = firstStore.GetOrCreateVote(
		ctx,
		5,
		9,
		commandDigest,
		func() ([]byte, error) {
			return []byte("persistent-partial"), nil
		},
	)
	if err != nil {
		t.Fatalf("create persistent vote: %v", err)
	}

	if err := firstStore.Close(); err != nil {
		t.Fatalf("close first store: %v", err)
	}

	secondStore, err := storage.OpenVoteStore(path)
	if err != nil {
		t.Fatalf("reopen vote store: %v", err)
	}
	defer secondStore.Close()

	signerCalled := false

	result, err := secondStore.GetOrCreateVote(
		ctx,
		5,
		9,
		commandDigest,
		func() ([]byte, error) {
			signerCalled = true
			return []byte("new-partial"), nil
		},
	)
	if err != nil {
		t.Fatalf("reuse persisted vote: %v", err)
	}

	if result.Created {
		t.Fatal("persisted vote was incorrectly recreated")
	}

	if signerCalled {
		t.Fatal("signing callback ran after restart")
	}

	if string(result.Vote.PartialSignature) != "persistent-partial" {
		t.Fatal("persisted partial signature was not recovered")
	}
}

func TestSignerFailureDoesNotCreateVote(t *testing.T) {
	store := openTestStore(t)
	ctx := context.Background()

	expected := errors.New("simulated threshold signer failure")

	_, err := store.GetOrCreateVote(
		ctx,
		8,
		3,
		digest("failed-command"),
		func() ([]byte, error) {
			return nil, expected
		},
	)

	if !errors.Is(err, expected) {
		t.Fatalf("expected signer failure, got %v", err)
	}

	_, err = store.GetVote(ctx, 8, 3)

	if !errors.Is(err, storage.ErrVoteNotFound) {
		t.Fatalf("failed signature created persistent vote: %v", err)
	}
}

func TestConcurrentConflictingRequestsSignOnlyOnce(t *testing.T) {
	store := openTestStore(t)
	ctx := context.Background()

	var signerCalls atomic.Int32
	start := make(chan struct{})

	type outcome struct {
		err error
	}

	outcomes := make(chan outcome, 2)
	var workers sync.WaitGroup

	run := func(commandDigest []byte, signature string) {
		defer workers.Done()
		<-start

		_, err := store.GetOrCreateVote(
			ctx,
			11,
			12,
			commandDigest,
			func() ([]byte, error) {
				signerCalls.Add(1)

				// Make any unsafe overlapping signing behavior easier
				// for the test to expose.
				time.Sleep(20 * time.Millisecond)

				return []byte(signature), nil
			},
		)

		outcomes <- outcome{err: err}
	}

	workers.Add(2)

	go run(digest("concurrent-A"), "partial-A")
	go run(digest("concurrent-B"), "partial-B")

	close(start)
	workers.Wait()
	close(outcomes)

	successes := 0
	conflicts := 0

	for result := range outcomes {
		switch {
		case result.err == nil:
			successes++

		case errors.Is(result.err, storage.ErrConflictingVote):
			conflicts++

		default:
			t.Fatalf("unexpected concurrent result: %v", result.err)
		}
	}

	if successes != 1 {
		t.Fatalf("successful votes=%d; expected 1", successes)
	}

	if conflicts != 1 {
		t.Fatalf("conflicting votes=%d; expected 1", conflicts)
	}

	if signerCalls.Load() != 1 {
		t.Fatalf(
			"signing callbacks=%d; expected exactly 1",
			signerCalls.Load(),
		)
	}
}
