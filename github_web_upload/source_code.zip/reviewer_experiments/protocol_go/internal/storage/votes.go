package storage

import (
	"bytes"
	"context"
	"database/sql"
	"errors"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"time"

	_ "modernc.org/sqlite"
)

var (
	ErrVoteNotFound    = errors.New("vote not found")
	ErrConflictingVote = errors.New("conflicting vote for epoch and round")
	ErrInvalidDigest   = errors.New("digest must contain exactly 32 bytes")
	ErrEmptyPartial    = errors.New("partial signature is empty")
	ErrInvalidIndex    = errors.New("epoch or round exceeds SQLite integer range")
	ErrNilSigner       = errors.New("partial-signature function is nil")
)

// Vote is the persistent signing decision for one epoch and round.
//
// The primary key intentionally excludes the view number. An honest follower
// may resend the same stored partial signature to a replacement leader, but it
// must never sign a different digest in a later view of the same round.
type Vote struct {
	Epoch            uint64
	Round            uint64
	Digest           []byte
	PartialSignature []byte
	CreatedAtUnixNs  int64
}

// VoteResult reports whether a new vote was created or an existing vote
// for the same digest was reused.
type VoteResult struct {
	Vote    Vote
	Created bool
}

// ConflictingVoteError provides evidence about an attempted equivocation.
type ConflictingVoteError struct {
	Epoch           uint64
	Round           uint64
	ExistingDigest  []byte
	RequestedDigest []byte
}

func (e *ConflictingVoteError) Error() string {
	return fmt.Sprintf(
		"%v: epoch=%d round=%d existing=%x requested=%x",
		ErrConflictingVote,
		e.Epoch,
		e.Round,
		e.ExistingDigest,
		e.RequestedDigest,
	)
}

func (e *ConflictingVoteError) Unwrap() error {
	return ErrConflictingVote
}

// VoteStore stores the follower's one-vote decisions.
type VoteStore struct {
	db   *sql.DB
	path string
}

// OpenVoteStore creates or opens a persistent vote database.
func OpenVoteStore(path string) (*VoteStore, error) {
	if path == "" {
		return nil, errors.New("vote database path is empty")
	}

	if path != ":memory:" {
		parent := filepath.Dir(path)

		if err := os.MkdirAll(parent, 0o700); err != nil {
			return nil, fmt.Errorf("create vote database directory: %w", err)
		}
	}

	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, fmt.Errorf("open vote database: %w", err)
	}

	// One SQLite connection per follower makes write ordering explicit.
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)

	store := &VoteStore{
		db:   db,
		path: path,
	}

	if err := store.initialize(); err != nil {
		_ = db.Close()
		return nil, err
	}

	if path != ":memory:" {
		// The database contains security-critical signing state.
		if err := os.Chmod(path, 0o600); err != nil {
			_ = db.Close()
			return nil, fmt.Errorf("secure vote database permissions: %w", err)
		}
	}

	return store, nil
}

func (s *VoteStore) initialize() error {
	if err := s.db.Ping(); err != nil {
		return fmt.Errorf("ping vote database: %w", err)
	}

	var journalMode string

	if err := s.db.QueryRow(
		"PRAGMA journal_mode = WAL",
	).Scan(&journalMode); err != nil {
		return fmt.Errorf("enable WAL journal mode: %w", err)
	}

	pragmas := []string{
		"PRAGMA synchronous = FULL",
		"PRAGMA busy_timeout = 5000",
		"PRAGMA foreign_keys = ON",
	}

	for _, statement := range pragmas {
		if _, err := s.db.Exec(statement); err != nil {
			return fmt.Errorf("apply %q: %w", statement, err)
		}
	}

	const schema = `
CREATE TABLE IF NOT EXISTS votes (
	epoch INTEGER NOT NULL CHECK(epoch >= 0),
	round_no INTEGER NOT NULL CHECK(round_no >= 0),
	digest BLOB NOT NULL CHECK(length(digest) = 32),
	partial_signature BLOB NOT NULL
		CHECK(length(partial_signature) > 0),
	created_at_ns INTEGER NOT NULL,
	PRIMARY KEY (epoch, round_no)
) WITHOUT ROWID;
`

	if _, err := s.db.Exec(schema); err != nil {
		return fmt.Errorf("create vote schema: %w", err)
	}

	return nil
}

// Close closes the persistent vote database.
func (s *VoteStore) Close() error {
	if s == nil || s.db == nil {
		return nil
	}

	return s.db.Close()
}

// Path returns the database location.
func (s *VoteStore) Path() string {
	return s.path
}

func validateCoordinates(epoch, round uint64) error {
	if epoch > math.MaxInt64 || round > math.MaxInt64 {
		return ErrInvalidIndex
	}

	return nil
}

func validateDigest(digest []byte) error {
	if len(digest) != 32 {
		return ErrInvalidDigest
	}

	return nil
}

func cloneBytes(value []byte) []byte {
	if value == nil {
		return nil
	}

	return append([]byte(nil), value...)
}

// GetVote reads an existing vote without creating a new one.
func (s *VoteStore) GetVote(
	ctx context.Context,
	epoch uint64,
	round uint64,
) (Vote, error) {
	if err := validateCoordinates(epoch, round); err != nil {
		return Vote{}, err
	}

	const query = `
SELECT digest, partial_signature, created_at_ns
FROM votes
WHERE epoch = ? AND round_no = ?
`

	var (
		digest    []byte
		partial   []byte
		createdAt int64
	)

	err := s.db.QueryRowContext(
		ctx,
		query,
		int64(epoch),
		int64(round),
	).Scan(
		&digest,
		&partial,
		&createdAt,
	)

	if errors.Is(err, sql.ErrNoRows) {
		return Vote{}, ErrVoteNotFound
	}

	if err != nil {
		return Vote{}, fmt.Errorf("read vote: %w", err)
	}

	return Vote{
		Epoch:            epoch,
		Round:            round,
		Digest:           cloneBytes(digest),
		PartialSignature: cloneBytes(partial),
		CreatedAtUnixNs:  createdAt,
	}, nil
}

// GetOrCreateVote atomically enforces one digest per epoch and round.
//
// The createPartial callback is invoked only when no vote exists. It executes
// while an IMMEDIATE SQLite transaction holds the write reservation. Therefore,
// two concurrent conflicting proposals cannot both enter the signing callback.
func (s *VoteStore) GetOrCreateVote(
	ctx context.Context,
	epoch uint64,
	round uint64,
	digest []byte,
	createPartial func() ([]byte, error),
) (VoteResult, error) {
	if err := validateCoordinates(epoch, round); err != nil {
		return VoteResult{}, err
	}

	if err := validateDigest(digest); err != nil {
		return VoteResult{}, err
	}

	if createPartial == nil {
		return VoteResult{}, ErrNilSigner
	}

	conn, err := s.db.Conn(ctx)
	if err != nil {
		return VoteResult{}, fmt.Errorf("acquire database connection: %w", err)
	}
	defer conn.Close()

	if _, err := conn.ExecContext(ctx, "BEGIN IMMEDIATE"); err != nil {
		return VoteResult{}, fmt.Errorf(
			"begin immediate vote transaction: %w",
			err,
		)
	}

	committed := false

	defer func() {
		if !committed {
			_, _ = conn.ExecContext(
				context.Background(),
				"ROLLBACK",
			)
		}
	}()

	const selectQuery = `
SELECT digest, partial_signature, created_at_ns
FROM votes
WHERE epoch = ? AND round_no = ?
`

	var (
		existingDigest  []byte
		existingPartial []byte
		existingCreated int64
	)

	err = conn.QueryRowContext(
		ctx,
		selectQuery,
		int64(epoch),
		int64(round),
	).Scan(
		&existingDigest,
		&existingPartial,
		&existingCreated,
	)

	switch {
	case err == nil:
		if !bytes.Equal(existingDigest, digest) {
			return VoteResult{}, &ConflictingVoteError{
				Epoch:           epoch,
				Round:           round,
				ExistingDigest:  cloneBytes(existingDigest),
				RequestedDigest: cloneBytes(digest),
			}
		}

		if _, err := conn.ExecContext(ctx, "COMMIT"); err != nil {
			return VoteResult{}, fmt.Errorf(
				"commit reused vote: %w",
				err,
			)
		}

		committed = true

		return VoteResult{
			Vote: Vote{
				Epoch:            epoch,
				Round:            round,
				Digest:           cloneBytes(existingDigest),
				PartialSignature: cloneBytes(existingPartial),
				CreatedAtUnixNs:  existingCreated,
			},
			Created: false,
		}, nil

	case !errors.Is(err, sql.ErrNoRows):
		return VoteResult{}, fmt.Errorf("query existing vote: %w", err)
	}

	// No prior vote exists. Generate the real threshold partial signature
	// while the transaction prevents a concurrent conflicting signer.
	partial, err := createPartial()
	if err != nil {
		return VoteResult{}, fmt.Errorf(
			"create threshold partial signature: %w",
			err,
		)
	}

	if len(partial) == 0 {
		return VoteResult{}, ErrEmptyPartial
	}

	createdAt := time.Now().UnixNano()

	const insertQuery = `
INSERT INTO votes (
	epoch,
	round_no,
	digest,
	partial_signature,
	created_at_ns
)
VALUES (?, ?, ?, ?, ?)
`

	if _, err := conn.ExecContext(
		ctx,
		insertQuery,
		int64(epoch),
		int64(round),
		cloneBytes(digest),
		cloneBytes(partial),
		createdAt,
	); err != nil {
		return VoteResult{}, fmt.Errorf("insert vote: %w", err)
	}

	if _, err := conn.ExecContext(ctx, "COMMIT"); err != nil {
		return VoteResult{}, fmt.Errorf("commit new vote: %w", err)
	}

	committed = true

	return VoteResult{
		Vote: Vote{
			Epoch:            epoch,
			Round:            round,
			Digest:           cloneBytes(digest),
			PartialSignature: cloneBytes(partial),
			CreatedAtUnixNs:  createdAt,
		},
		Created: true,
	}, nil
}
