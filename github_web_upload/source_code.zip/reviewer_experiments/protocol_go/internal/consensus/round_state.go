package consensus

import (
	"errors"
	"fmt"
	"slices"
	"time"

	"uav-bft/internal/wire"
)

var (
	ErrEmptyMembership = errors.New(
		"membership cannot be empty",
	)
	ErrDuplicateMember = errors.New(
		"membership contains duplicate node ID",
	)
	ErrInvalidThreshold = errors.New(
		"invalid consensus threshold",
	)
	ErrInvalidTimeout = errors.New(
		"view timeout must be positive",
	)
	ErrNotCurrentLeader = errors.New(
		"proposal sender is not the current leader",
	)
	ErrEpochMismatch = errors.New(
		"message epoch does not match active epoch",
	)
	ErrRoundMismatch = errors.New(
		"message round does not match active round",
	)
	ErrViewMismatch = errors.New(
		"message view does not match active view",
	)
	ErrUnknownSigner = errors.New(
		"approval signer is not in the active membership",
	)
	ErrDuplicateApproval = errors.New(
		"duplicate approval from the same signer",
	)
	ErrProposalMissing = errors.New(
		"current leader proposal has not been accepted",
	)
	ErrInsufficientApprovals = errors.New(
		"insufficient approvals for certification",
	)
	ErrTimeoutNotExpired = errors.New(
		"view timeout has not expired",
	)
	ErrAlreadyCertified = errors.New(
		"round is already certified",
	)
	ErrCertificateMismatch = errors.New(
		"certificate does not match active round state",
	)
	ErrDuplicateCertificateSigner = errors.New(
		"certificate contains a duplicate signer",
	)
)

type Phase uint8

const (
	PhaseWaitingForProposal Phase = iota
	PhaseCollectingApprovals
	PhaseCertified
)

func (phase Phase) String() string {
	switch phase {
	case PhaseWaitingForProposal:
		return "waiting-for-proposal"
	case PhaseCollectingApprovals:
		return "collecting-approvals"
	case PhaseCertified:
		return "certified"
	default:
		return "unknown"
	}
}

// RoundState tracks one epoch and round through one or more views.
//
// All honest participants must use the same authenticated membership.
// Membership is sorted so that every honest participant derives the same
// leader rotation even if configuration entries were supplied in a
// different order.
type RoundState struct {
	Epoch     uint64
	Round     uint64
	View      uint64
	Threshold int

	membership []uint32
	members    map[uint32]struct{}

	viewTimeout time.Duration
	deadline    time.Time
	phase       Phase

	proposalAccepted bool
	approvals        map[uint32]wire.Approval
	certificate      *wire.Certificate
}

func NewRoundState(
	epoch uint64,
	round uint64,
	membership []uint32,
	threshold int,
	viewTimeout time.Duration,
	startTime time.Time,
) (*RoundState, error) {
	if len(membership) == 0 {
		return nil, ErrEmptyMembership
	}

	if threshold <= 0 || threshold > len(membership) {
		return nil, fmt.Errorf(
			"%w: threshold=%d membership=%d",
			ErrInvalidThreshold,
			threshold,
			len(membership),
		)
	}

	if viewTimeout <= 0 {
		return nil, ErrInvalidTimeout
	}

	canonicalMembership := append(
		[]uint32(nil),
		membership...,
	)
	slices.Sort(canonicalMembership)

	memberSet := make(
		map[uint32]struct{},
		len(canonicalMembership),
	)

	for _, nodeID := range canonicalMembership {
		if _, exists := memberSet[nodeID]; exists {
			return nil, fmt.Errorf(
				"%w: node=%d",
				ErrDuplicateMember,
				nodeID,
			)
		}

		memberSet[nodeID] = struct{}{}
	}

	return &RoundState{
		Epoch:       epoch,
		Round:       round,
		View:        0,
		Threshold:   threshold,
		membership:  canonicalMembership,
		members:     memberSet,
		viewTimeout: viewTimeout,
		deadline:    startTime.Add(viewTimeout),
		phase:       PhaseWaitingForProposal,
		approvals:   make(map[uint32]wire.Approval),
	}, nil
}

// Membership returns a defensive copy of the canonical membership.
func (state *RoundState) Membership() []uint32 {
	return append([]uint32(nil), state.membership...)
}

// Leader returns the deterministic leader for the current view.
func (state *RoundState) Leader() uint32 {
	memberCount := uint64(len(state.membership))

	index := (state.Round + state.View) % memberCount

	return state.membership[index]
}

func (state *RoundState) Deadline() time.Time {
	return state.deadline
}

func (state *RoundState) Phase() Phase {
	return state.phase
}

func (state *RoundState) ApprovalCount() int {
	return len(state.approvals)
}

func (state *RoundState) ReadyToCertify() bool {
	return state.proposalAccepted &&
		len(state.approvals) >= state.Threshold &&
		state.phase != PhaseCertified
}

// AcceptProposal accepts a proposal only from the deterministic leader
// of the current epoch, round, and view.
func (state *RoundState) AcceptProposal(
	senderID uint32,
	epoch uint64,
	round uint64,
	view uint64,
) error {
	if state.phase == PhaseCertified {
		return ErrAlreadyCertified
	}

	if epoch != state.Epoch {
		return fmt.Errorf(
			"%w: received=%d expected=%d",
			ErrEpochMismatch,
			epoch,
			state.Epoch,
		)
	}

	if round != state.Round {
		return fmt.Errorf(
			"%w: received=%d expected=%d",
			ErrRoundMismatch,
			round,
			state.Round,
		)
	}

	if view != state.View {
		return fmt.Errorf(
			"%w: received=%d expected=%d",
			ErrViewMismatch,
			view,
			state.View,
		)
	}

	expectedLeader := state.Leader()

	if senderID != expectedLeader {
		return fmt.Errorf(
			"%w: sender=%d expected=%d",
			ErrNotCurrentLeader,
			senderID,
			expectedLeader,
		)
	}

	state.proposalAccepted = true
	state.phase = PhaseCollectingApprovals

	return nil
}

// RecordApproval records only current-view approvals from registered
// members. Cryptographic verification is performed by the authenticated
// threshold layer before this method is called.
func (state *RoundState) RecordApproval(
	approval wire.Approval,
) error {
	if state.phase == PhaseCertified {
		return ErrAlreadyCertified
	}

	if !state.proposalAccepted {
		return ErrProposalMissing
	}

	if approval.Epoch != state.Epoch {
		return fmt.Errorf(
			"%w: received=%d expected=%d",
			ErrEpochMismatch,
			approval.Epoch,
			state.Epoch,
		)
	}

	if approval.Round != state.Round {
		return fmt.Errorf(
			"%w: received=%d expected=%d",
			ErrRoundMismatch,
			approval.Round,
			state.Round,
		)
	}

	if approval.View != state.View {
		return fmt.Errorf(
			"%w: received=%d expected=%d",
			ErrViewMismatch,
			approval.View,
			state.View,
		)
	}

	if _, exists := state.members[approval.SignerID]; !exists {
		return fmt.Errorf(
			"%w: signer=%d",
			ErrUnknownSigner,
			approval.SignerID,
		)
	}

	if _, exists := state.approvals[approval.SignerID]; exists {
		return fmt.Errorf(
			"%w: signer=%d",
			ErrDuplicateApproval,
			approval.SignerID,
		)
	}

	state.approvals[approval.SignerID] = approval

	return nil
}

// CurrentApprovals returns approvals in canonical signer-ID order.
func (state *RoundState) CurrentApprovals() []wire.Approval {
	signerIDs := make(
		[]uint32,
		0,
		len(state.approvals),
	)

	for signerID := range state.approvals {
		signerIDs = append(signerIDs, signerID)
	}

	slices.Sort(signerIDs)

	approvals := make(
		[]wire.Approval,
		0,
		len(signerIDs),
	)

	for _, signerID := range signerIDs {
		approvals = append(
			approvals,
			state.approvals[signerID],
		)
	}

	return approvals
}

// MarkCertified records a verified threshold certificate.
func (state *RoundState) MarkCertified(
	certificate wire.Certificate,
) error {
	if state.phase == PhaseCertified {
		return ErrAlreadyCertified
	}

	if !state.ReadyToCertify() {
		return fmt.Errorf(
			"%w: received=%d required=%d",
			ErrInsufficientApprovals,
			len(state.approvals),
			state.Threshold,
		)
	}

	if certificate.Epoch != state.Epoch ||
		certificate.Round != state.Round ||
		certificate.View != state.View {
		return fmt.Errorf(
			"%w: certificate=(%d,%d,%d) state=(%d,%d,%d)",
			ErrCertificateMismatch,
			certificate.Epoch,
			certificate.Round,
			certificate.View,
			state.Epoch,
			state.Round,
			state.View,
		)
	}

	if len(certificate.SignerIDs) < state.Threshold {
		return fmt.Errorf(
			"%w: certificate signers=%d required=%d",
			ErrInsufficientApprovals,
			len(certificate.SignerIDs),
			state.Threshold,
		)
	}

	seen := make(map[uint32]struct{})

	for _, signerID := range certificate.SignerIDs {
		if _, exists := state.members[signerID]; !exists {
			return fmt.Errorf(
				"%w: signer=%d",
				ErrUnknownSigner,
				signerID,
			)
		}

		if _, exists := seen[signerID]; exists {
			return fmt.Errorf(
				"%w: signer=%d",
				ErrDuplicateCertificateSigner,
				signerID,
			)
		}

		seen[signerID] = struct{}{}
	}

	certificateCopy := certificate
	certificateCopy.CommandDigest = append(
		[]byte(nil),
		certificate.CommandDigest...,
	)
	certificateCopy.SignerIDs = append(
		[]uint32(nil),
		certificate.SignerIDs...,
	)
	certificateCopy.ThresholdBLSSig = append(
		[]byte(nil),
		certificate.ThresholdBLSSig...,
	)

	state.certificate = &certificateCopy
	state.phase = PhaseCertified

	return nil
}

// OnTimeout replaces the leader by moving to the next view.
//
// Previously collected identity envelopes are cleared because they bind
// the previous view. Followers may reuse their persistent BLS partials,
// but they must create new Ed25519 envelopes for the new view.
func (state *RoundState) OnTimeout(
	now time.Time,
) (uint32, error) {
	if state.phase == PhaseCertified {
		return 0, ErrAlreadyCertified
	}

	if now.Before(state.deadline) {
		return 0, fmt.Errorf(
			"%w: now=%s deadline=%s",
			ErrTimeoutNotExpired,
			now.UTC().Format(time.RFC3339Nano),
			state.deadline.UTC().Format(time.RFC3339Nano),
		)
	}

	state.View++
	state.deadline = now.Add(state.viewTimeout)
	state.phase = PhaseWaitingForProposal
	state.proposalAccepted = false
	state.approvals = make(map[uint32]wire.Approval)

	return state.Leader(), nil
}
