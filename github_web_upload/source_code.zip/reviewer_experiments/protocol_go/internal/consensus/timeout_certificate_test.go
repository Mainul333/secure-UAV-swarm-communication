package consensus_test

import (
	"bytes"
	"crypto/ed25519"
	"errors"
	"testing"

	"uav-bft/internal/consensus"
	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

func timeoutFixture(
	t *testing.T,
) (
	map[uint32]ed25519.PublicKey,
	map[uint32]ed25519.PrivateKey,
	[]byte,
) {
	t.Helper()

	registry := make(map[uint32]ed25519.PublicKey)
	privateKeys := make(map[uint32]ed25519.PrivateKey)

	for index := uint32(0); index < 4; index++ {
		publicKey, privateKey, err := identity.GenerateKeyPair()
		if err != nil {
			t.Fatalf("node %d generate identity: %v", index, err)
		}
		registry[index] = publicKey
		privateKeys[index] = privateKey
	}

	return registry, privateKeys, bytes.Repeat([]byte{0x7a}, 32)
}

func signedTimeoutChange(
	t *testing.T,
	privateKey ed25519.PrivateKey,
	digest []byte,
	senderID uint32,
) wire.ViewChange {
	t.Helper()

	change, err := identity.SignViewChange(
		privateKey,
		wire.ViewChange{
			Epoch:         1,
			Round:         8,
			NewView:       1,
			CommandDigest: append([]byte(nil), digest...),
			SenderID:      senderID,
		},
	)
	if err != nil {
		t.Fatalf("sign timeout change: %v", err)
	}

	return change
}

func TestTimeoutCertificateThresholdAndVerification(t *testing.T) {
	registry, privateKeys, digest := timeoutFixture(t)

	collector, err := consensus.NewTimeoutCollector(
		1,
		8,
		1,
		digest,
		3,
		registry,
	)
	if err != nil {
		t.Fatalf("create collector: %v", err)
	}

	for _, senderID := range []uint32{2, 0, 1} {
		change := signedTimeoutChange(
			t,
			privateKeys[senderID],
			digest,
			senderID,
		)
		if err := collector.Add(change); err != nil {
			t.Fatalf("add sender %d: %v", senderID, err)
		}
	}

	certificate, err := collector.Build()
	if err != nil {
		t.Fatalf("build timeout certificate: %v", err)
	}

	if len(certificate.Changes) != 3 {
		t.Fatalf("change count=%d; expected 3", len(certificate.Changes))
	}

	if certificate.Changes[0].SenderID != 0 ||
		certificate.Changes[1].SenderID != 1 ||
		certificate.Changes[2].SenderID != 2 {
		t.Fatalf("noncanonical sender order: %+v", certificate.Changes)
	}

	if err := consensus.VerifyTimeoutCertificate(
		certificate,
		3,
		registry,
	); err != nil {
		t.Fatalf("verify timeout certificate: %v", err)
	}
}

func TestTimeoutCertificateRejectsDuplicateAndForgery(t *testing.T) {
	registry, privateKeys, digest := timeoutFixture(t)

	collector, err := consensus.NewTimeoutCollector(
		1,
		8,
		1,
		digest,
		3,
		registry,
	)
	if err != nil {
		t.Fatalf("create collector: %v", err)
	}

	first := signedTimeoutChange(t, privateKeys[0], digest, 0)
	if err := collector.Add(first); err != nil {
		t.Fatalf("add first: %v", err)
	}

	if err := collector.Add(first); !errors.Is(
		err,
		consensus.ErrDuplicateViewChange,
	) {
		t.Fatalf("expected duplicate rejection, got %v", err)
	}

	forged := signedTimeoutChange(t, privateKeys[1], digest, 1)
	forged.NewView = 2

	if err := collector.Add(forged); !errors.Is(
		err,
		consensus.ErrTimeoutChangeMismatch,
	) {
		t.Fatalf("expected mismatch rejection, got %v", err)
	}
}

func TestTimeoutCertificateRequiresThreshold(t *testing.T) {
	registry, privateKeys, digest := timeoutFixture(t)

	collector, err := consensus.NewTimeoutCollector(
		1,
		8,
		1,
		digest,
		3,
		registry,
	)
	if err != nil {
		t.Fatalf("create collector: %v", err)
	}

	for _, senderID := range []uint32{0, 1} {
		if err := collector.Add(signedTimeoutChange(
			t,
			privateKeys[senderID],
			digest,
			senderID,
		)); err != nil {
			t.Fatalf("add sender %d: %v", senderID, err)
		}
	}

	_, err = collector.Build()
	if !errors.Is(err, consensus.ErrTimeoutCertificateIncomplete) {
		t.Fatalf("expected incomplete certificate, got %v", err)
	}
}
