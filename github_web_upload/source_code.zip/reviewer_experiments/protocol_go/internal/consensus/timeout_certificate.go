package consensus

import (
	"bytes"
	"crypto/ed25519"
	"errors"
	"fmt"
	"slices"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

var (
	ErrInvalidTimeoutCollector = errors.New(
		"invalid timeout-certificate collector configuration",
	)
	ErrTimeoutChangeMismatch = errors.New(
		"view change does not match timeout-certificate coordinates",
	)
	ErrDuplicateViewChange = errors.New(
		"duplicate view change from the same sender",
	)
	ErrTimeoutIdentityMissing = errors.New(
		"missing identity key for timeout sender",
	)
	ErrTimeoutIdentityInvalid = errors.New(
		"invalid authenticated view change",
	)
	ErrTimeoutCertificateIncomplete = errors.New(
		"insufficient authenticated view changes",
	)
)

// TimeoutCollector gathers a threshold of authenticated view-change requests
// for one exact (epoch, round, new-view, command-digest) tuple.
type TimeoutCollector struct {
	epoch         uint64
	round         uint64
	newView       uint64
	commandDigest []byte
	threshold     int
	registry      map[uint32]ed25519.PublicKey
	changes       map[uint32]wire.ViewChange
}

func NewTimeoutCollector(
	epoch uint64,
	round uint64,
	newView uint64,
	commandDigest []byte,
	threshold int,
	registry map[uint32]ed25519.PublicKey,
) (*TimeoutCollector, error) {
	if len(commandDigest) != 32 ||
		threshold <= 0 ||
		len(registry) == 0 ||
		threshold > len(registry) {
		return nil, ErrInvalidTimeoutCollector
	}

	registryCopy := make(
		map[uint32]ed25519.PublicKey,
		len(registry),
	)

	for signerID, publicKey := range registry {
		if len(publicKey) != ed25519.PublicKeySize {
			return nil, fmt.Errorf(
				"%w: signer=%d",
				ErrInvalidTimeoutCollector,
				signerID,
			)
		}

		registryCopy[signerID] = append(
			ed25519.PublicKey(nil),
			publicKey...,
		)
	}

	return &TimeoutCollector{
		epoch:         epoch,
		round:         round,
		newView:       newView,
		commandDigest: append([]byte(nil), commandDigest...),
		threshold:     threshold,
		registry:      registryCopy,
		changes:       make(map[uint32]wire.ViewChange),
	}, nil
}

func (collector *TimeoutCollector) Add(
	change wire.ViewChange,
) error {
	if change.Epoch != collector.epoch ||
		change.Round != collector.round ||
		change.NewView != collector.newView ||
		!bytes.Equal(change.CommandDigest, collector.commandDigest) {
		return fmt.Errorf(
			"%w: sender=%d",
			ErrTimeoutChangeMismatch,
			change.SenderID,
		)
	}

	publicKey, exists := collector.registry[change.SenderID]
	if !exists {
		return fmt.Errorf(
			"%w: sender=%d",
			ErrTimeoutIdentityMissing,
			change.SenderID,
		)
	}

	if _, exists := collector.changes[change.SenderID]; exists {
		return fmt.Errorf(
			"%w: sender=%d",
			ErrDuplicateViewChange,
			change.SenderID,
		)
	}

	if err := identity.VerifyViewChange(publicKey, change); err != nil {
		return fmt.Errorf(
			"%w: sender=%d: %v",
			ErrTimeoutIdentityInvalid,
			change.SenderID,
			err,
		)
	}

	change.CommandDigest = append(
		[]byte(nil),
		change.CommandDigest...,
	)
	change.IdentitySig = append(
		[]byte(nil),
		change.IdentitySig...,
	)
	collector.changes[change.SenderID] = change

	return nil
}

func (collector *TimeoutCollector) Count() int {
	return len(collector.changes)
}

func (collector *TimeoutCollector) Ready() bool {
	return collector.Count() >= collector.threshold
}

// Build selects the threshold lowest sender IDs so every honest collector
// produces the same compact timeout certificate from the same evidence set.
func (collector *TimeoutCollector) Build() (
	wire.TimeoutCertificate,
	error,
) {
	if !collector.Ready() {
		return wire.TimeoutCertificate{}, fmt.Errorf(
			"%w: received=%d required=%d",
			ErrTimeoutCertificateIncomplete,
			collector.Count(),
			collector.threshold,
		)
	}

	senderIDs := make([]uint32, 0, len(collector.changes))
	for senderID := range collector.changes {
		senderIDs = append(senderIDs, senderID)
	}
	slices.Sort(senderIDs)
	senderIDs = senderIDs[:collector.threshold]

	changes := make([]wire.ViewChange, 0, collector.threshold)
	for _, senderID := range senderIDs {
		change := collector.changes[senderID]
		change.CommandDigest = append(
			[]byte(nil),
			change.CommandDigest...,
		)
		change.IdentitySig = append(
			[]byte(nil),
			change.IdentitySig...,
		)
		changes = append(changes, change)
	}

	return wire.TimeoutCertificate{
		Epoch:   collector.epoch,
		Round:   collector.round,
		NewView: collector.newView,
		CommandDigest: append(
			[]byte(nil),
			collector.commandDigest...,
		),
		Changes: changes,
	}, nil
}

// VerifyTimeoutCertificate checks threshold, membership, uniqueness,
// coordinates, and every Ed25519 view-change signature.
func VerifyTimeoutCertificate(
	certificate wire.TimeoutCertificate,
	threshold int,
	registry map[uint32]ed25519.PublicKey,
) error {
	if threshold <= 0 ||
		threshold > len(registry) ||
		len(certificate.CommandDigest) != 32 {
		return ErrInvalidTimeoutCollector
	}

	if len(certificate.Changes) < threshold {
		return fmt.Errorf(
			"%w: received=%d required=%d",
			ErrTimeoutCertificateIncomplete,
			len(certificate.Changes),
			threshold,
		)
	}

	seen := make(map[uint32]struct{}, len(certificate.Changes))

	for _, change := range certificate.Changes {
		if change.Epoch != certificate.Epoch ||
			change.Round != certificate.Round ||
			change.NewView != certificate.NewView ||
			!bytes.Equal(
				change.CommandDigest,
				certificate.CommandDigest,
			) {
			return fmt.Errorf(
				"%w: sender=%d",
				ErrTimeoutChangeMismatch,
				change.SenderID,
			)
		}

		if _, exists := seen[change.SenderID]; exists {
			return fmt.Errorf(
				"%w: sender=%d",
				ErrDuplicateViewChange,
				change.SenderID,
			)
		}
		seen[change.SenderID] = struct{}{}

		publicKey, exists := registry[change.SenderID]
		if !exists {
			return fmt.Errorf(
				"%w: sender=%d",
				ErrTimeoutIdentityMissing,
				change.SenderID,
			)
		}

		if err := identity.VerifyViewChange(publicKey, change); err != nil {
			return fmt.Errorf(
				"%w: sender=%d: %v",
				ErrTimeoutIdentityInvalid,
				change.SenderID,
				err,
			)
		}
	}

	return nil
}
