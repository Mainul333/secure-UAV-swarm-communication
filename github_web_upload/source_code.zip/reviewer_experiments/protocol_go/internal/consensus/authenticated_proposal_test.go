package consensus_test

import (
	"bytes"
	"testing"
	"time"

	"uav-bft/internal/consensus"
	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

func TestAuthenticatedProposalAcceptedAndTamperRejected(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()
	state, err := consensus.NewRoundState(
		1,
		8,
		[]uint32{0, 1, 2, 3},
		3,
		time.Second,
		now,
	)
	if err != nil {
		t.Fatal(err)
	}

	basePublic, basePrivate, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatal(err)
	}
	leaderPublic, leaderPrivate, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatal(err)
	}

	authorized, err := identity.AuthorizeCommand(
		basePrivate,
		1,
		wire.Command{
			ProtocolVersion: wire.CurrentProtocolVersion,
			Epoch:           1,
			Round:           8,
			IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
			ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
			CommandType:     1,
			Payload:         []byte("MOVE"),
			Nonce:           bytes.Repeat([]byte{1}, 16),
		},
		now,
	)
	if err != nil {
		t.Fatal(err)
	}
	proposal, err := identity.SignProposal(
		leaderPrivate,
		wire.Proposal{
			Authorized: authorized,
			View:       0,
			LeaderID:   0,
		},
	)
	if err != nil {
		t.Fatal(err)
	}

	tampered := proposal
	tampered.View = 1
	if err := state.AcceptAuthenticatedProposal(
		tampered,
		leaderPublic,
		basePublic,
		now,
	); err == nil {
		t.Fatal("tampered proposal accepted")
	}
	if state.Phase() != consensus.PhaseWaitingForProposal {
		t.Fatal("failed proposal mutated state")
	}

	if err := state.AcceptAuthenticatedProposal(
		proposal,
		leaderPublic,
		basePublic,
		now,
	); err != nil {
		t.Fatalf("valid proposal rejected: %v", err)
	}
}
