package consensus_test

import (
	"bytes"
	"errors"
	"testing"
	"time"

	"uav-bft/internal/consensus"
	"uav-bft/internal/wire"
)

func testApproval(
	epoch uint64,
	round uint64,
	view uint64,
	signerID uint32,
) wire.Approval {
	return wire.Approval{
		Epoch:         epoch,
		Round:         round,
		View:          view,
		CommandDigest: bytes.Repeat([]byte{0x11}, 32),
		SignerID:      signerID,
		PartialBLSSig: bytes.Repeat([]byte{0x22}, 50),
		IdentitySig:   bytes.Repeat([]byte{0x33}, 64),
	}
}

func newState(t *testing.T) (*consensus.RoundState, time.Time) {
	t.Helper()

	start := time.Unix(1_700_000_000, 0).UTC()

	state, err := consensus.NewRoundState(
		1,
		8,
		[]uint32{3, 1, 0, 2},
		3,
		500*time.Millisecond,
		start,
	)
	if err != nil {
		t.Fatalf("create round state: %v", err)
	}

	return state, start
}

func TestCanonicalMembershipAndLeaderRotation(t *testing.T) {
	state, start := newState(t)

	expectedMembership := []uint32{0, 1, 2, 3}

	if !bytes.Equal(
		uint32SliceToBytes(state.Membership()),
		uint32SliceToBytes(expectedMembership),
	) {
		t.Fatalf(
			"membership=%v; expected %v",
			state.Membership(),
			expectedMembership,
		)
	}

	// Round 8 modulo 4 selects node 0.
	if state.Leader() != 0 {
		t.Fatalf(
			"view 0 leader=%d; expected 0",
			state.Leader(),
		)
	}

	nextLeader, err := state.OnTimeout(
		start.Add(500 * time.Millisecond),
	)
	if err != nil {
		t.Fatalf("view 0 timeout: %v", err)
	}

	if nextLeader != 1 {
		t.Fatalf(
			"view 1 leader=%d; expected 1",
			nextLeader,
		)
	}

	nextLeader, err = state.OnTimeout(
		start.Add(time.Second),
	)
	if err != nil {
		t.Fatalf("view 1 timeout: %v", err)
	}

	if nextLeader != 2 {
		t.Fatalf(
			"view 2 leader=%d; expected 2",
			nextLeader,
		)
	}
}

func TestNonLeaderProposalRejected(t *testing.T) {
	state, _ := newState(t)

	err := state.AcceptProposal(
		2,
		state.Epoch,
		state.Round,
		state.View,
	)

	if !errors.Is(err, consensus.ErrNotCurrentLeader) {
		t.Fatalf(
			"expected nonleader rejection, got %v",
			err,
		)
	}
}

func TestOldViewApprovalRejectedAfterTimeout(t *testing.T) {
	state, start := newState(t)

	if err := state.AcceptProposal(
		state.Leader(),
		state.Epoch,
		state.Round,
		0,
	); err != nil {
		t.Fatalf("accept view-zero proposal: %v", err)
	}

	if err := state.RecordApproval(
		testApproval(1, 8, 0, 0),
	); err != nil {
		t.Fatalf("record view-zero approval: %v", err)
	}

	nextLeader, err := state.OnTimeout(
		start.Add(500 * time.Millisecond),
	)
	if err != nil {
		t.Fatalf("advance to view one: %v", err)
	}

	if nextLeader != 1 {
		t.Fatalf(
			"replacement leader=%d; expected 1",
			nextLeader,
		)
	}

	if state.ApprovalCount() != 0 {
		t.Fatal("old-view approvals were not cleared")
	}

	if err := state.AcceptProposal(
		nextLeader,
		1,
		8,
		1,
	); err != nil {
		t.Fatalf("accept replacement proposal: %v", err)
	}

	err = state.RecordApproval(
		testApproval(1, 8, 0, 1),
	)

	if !errors.Is(err, consensus.ErrViewMismatch) {
		t.Fatalf(
			"expected old-view approval rejection, got %v",
			err,
		)
	}
}

func TestMaliciousLeaderTimeoutAndRecovery(t *testing.T) {
	state, start := newState(t)

	// View-zero leader accepts a proposal but withholds the certificate.
	if err := state.AcceptProposal(
		state.Leader(),
		1,
		8,
		0,
	); err != nil {
		t.Fatalf("accept malicious-leader proposal: %v", err)
	}

	for _, signerID := range []uint32{0, 2} {
		if err := state.RecordApproval(
			testApproval(1, 8, 0, signerID),
		); err != nil {
			t.Fatalf(
				"record view-zero approval from %d: %v",
				signerID,
				err,
			)
		}
	}

	if state.ReadyToCertify() {
		t.Fatal("state became ready below threshold")
	}

	replacementLeader, err := state.OnTimeout(
		start.Add(500 * time.Millisecond),
	)
	if err != nil {
		t.Fatalf("replace malicious leader: %v", err)
	}

	if replacementLeader != 1 {
		t.Fatalf(
			"replacement leader=%d; expected 1",
			replacementLeader,
		)
	}

	if state.View != 1 {
		t.Fatalf(
			"view=%d; expected 1",
			state.View,
		)
	}

	if err := state.AcceptProposal(
		replacementLeader,
		1,
		8,
		1,
	); err != nil {
		t.Fatalf("accept replacement proposal: %v", err)
	}

	for _, signerID := range []uint32{0, 1, 2} {
		if err := state.RecordApproval(
			testApproval(1, 8, 1, signerID),
		); err != nil {
			t.Fatalf(
				"record view-one approval from %d: %v",
				signerID,
				err,
			)
		}
	}

	if !state.ReadyToCertify() {
		t.Fatal("replacement leader did not reach threshold")
	}

	certificate := wire.Certificate{
		Epoch:           1,
		Round:           8,
		View:            1,
		CommandDigest:   bytes.Repeat([]byte{0x11}, 32),
		SignerIDs:       []uint32{0, 1, 2},
		ThresholdBLSSig: bytes.Repeat([]byte{0x44}, 48),
	}

	if err := state.MarkCertified(certificate); err != nil {
		t.Fatalf("mark replacement view certified: %v", err)
	}

	if state.Phase() != consensus.PhaseCertified {
		t.Fatalf(
			"phase=%s; expected certified",
			state.Phase(),
		)
	}

	_, err = state.OnTimeout(start.Add(time.Second))

	if !errors.Is(err, consensus.ErrAlreadyCertified) {
		t.Fatalf(
			"certified round changed view: %v",
			err,
		)
	}
}

func TestDuplicateApprovalRejected(t *testing.T) {
	state, _ := newState(t)

	if err := state.AcceptProposal(
		state.Leader(),
		1,
		8,
		0,
	); err != nil {
		t.Fatalf("accept proposal: %v", err)
	}

	approval := testApproval(1, 8, 0, 0)

	if err := state.RecordApproval(approval); err != nil {
		t.Fatalf("record first approval: %v", err)
	}

	err := state.RecordApproval(approval)

	if !errors.Is(err, consensus.ErrDuplicateApproval) {
		t.Fatalf(
			"expected duplicate rejection, got %v",
			err,
		)
	}
}

func TestTimeoutBeforeDeadlineRejected(t *testing.T) {
	state, start := newState(t)

	_, err := state.OnTimeout(
		start.Add(499 * time.Millisecond),
	)

	if !errors.Is(err, consensus.ErrTimeoutNotExpired) {
		t.Fatalf(
			"expected early-timeout rejection, got %v",
			err,
		)
	}
}

func uint32SliceToBytes(values []uint32) []byte {
	output := make([]byte, 0, len(values)*4)

	for _, value := range values {
		output = append(
			output,
			byte(value>>24),
			byte(value>>16),
			byte(value>>8),
			byte(value),
		)
	}

	return output
}
