package consensus_test

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"errors"
	"fmt"
	"path/filepath"
	"testing"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/consensus"
	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

func TestRealCertificateRecoveryAfterLeaderReplacement(
	t *testing.T,
) {
	const (
		nodeCount      = 4
		thresholdValue = 3
	)

	ctx := context.Background()
	start := time.Unix(1_700_000_000, 0).UTC()
	viewTimeout := 500 * time.Millisecond

	dkgResult, err := dkg.RunHonest(
		nodeCount,
		thresholdValue,
	)
	if err != nil {
		t.Fatalf("run GJKR DKG: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(
		dkgResult.Suite,
	)

	baseStationPublicKey, baseStationPrivateKey, err :=
		identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate base-station identity: %v", err)
	}

	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           8,
		IssuedAtUnixNs:  start.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: start.Add(5 * time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte("MOVE:X=5,Y=5,Z=-5"),
		Nonce:           []byte("0123456789ABCDEF"),
	}

	authorized, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		command,
		start,
	)
	if err != nil {
		t.Fatalf("authorize command: %v", err)
	}

	signers := make(
		[]*thresholdprotocol.AuthenticatedFollowerSigner,
		thresholdValue,
	)

	identityRegistry := make(
		map[uint32]ed25519.PublicKey,
		thresholdValue,
	)

	for index := 0; index < thresholdValue; index++ {
		storePath := filepath.Join(
			t.TempDir(),
			fmt.Sprintf("node%d.db", index),
		)

		store, err := storage.OpenVoteStore(storePath)
		if err != nil {
			t.Fatalf(
				"node %d open vote store: %v",
				index,
				err,
			)
		}

		currentStore := store
		t.Cleanup(func() {
			_ = currentStore.Close()
		})

		follower, err :=
			thresholdprotocol.NewFollowerSigner(
				scheme,
				dkgResult.Shares[index].PriShare(),
				dkgResult.PublicPoly,
				store,
				baseStationPublicKey,
			)
		if err != nil {
			t.Fatalf(
				"node %d create follower: %v",
				index,
				err,
			)
		}

		uavPublicKey, uavPrivateKey, err :=
			identity.GenerateKeyPair()
		if err != nil {
			t.Fatalf(
				"node %d generate identity: %v",
				index,
				err,
			)
		}

		authenticatedSigner, err :=
			thresholdprotocol.NewAuthenticatedFollowerSigner(
				follower,
				uavPrivateKey,
			)
		if err != nil {
			t.Fatalf(
				"node %d create authenticated signer: %v",
				index,
				err,
			)
		}

		signerID := authenticatedSigner.SignerID()

		signers[index] = authenticatedSigner
		identityRegistry[signerID] = uavPublicKey
	}

	state, err := consensus.NewRoundState(
		1,
		8,
		[]uint32{0, 1, 2, 3},
		thresholdValue,
		viewTimeout,
		start,
	)
	if err != nil {
		t.Fatalf("create round state: %v", err)
	}

	if state.Leader() != 0 {
		t.Fatalf(
			"view-zero leader=%d; expected 0",
			state.Leader(),
		)
	}

	if err := state.AcceptProposal(
		state.Leader(),
		1,
		8,
		0,
	); err != nil {
		t.Fatalf("accept view-zero proposal: %v", err)
	}

	viewZeroApprovals := make(
		[]wire.Approval,
		0,
		thresholdValue,
	)

	for index, signer := range signers {
		result, err := signer.Approve(
			ctx,
			authorized,
			0,
			start,
		)
		if err != nil {
			t.Fatalf(
				"node %d create view-zero approval: %v",
				index,
				err,
			)
		}

		if !result.Created {
			t.Fatalf(
				"node %d did not create its first partial",
				index,
			)
		}

		if err := state.RecordApproval(
			result.Approval,
		); err != nil {
			t.Fatalf(
				"record node %d view-zero approval: %v",
				index,
				err,
			)
		}

		viewZeroApprovals = append(
			viewZeroApprovals,
			result.Approval,
		)
	}

	if !state.ReadyToCertify() {
		t.Fatal("view-zero leader did not receive threshold approvals")
	}

	// The malicious leader has enough shares but withholds the
	// reconstructed certificate. Honest nodes therefore time out.
	replacementLeader, err := state.OnTimeout(
		start.Add(viewTimeout),
	)
	if err != nil {
		t.Fatalf("trigger leader replacement: %v", err)
	}

	if replacementLeader != 1 {
		t.Fatalf(
			"replacement leader=%d; expected 1",
			replacementLeader,
		)
	}

	if state.View != 1 {
		t.Fatalf(
			"new view=%d; expected 1",
			state.View,
		)
	}

	if state.ApprovalCount() != 0 {
		t.Fatal("old-view approval envelopes were not cleared")
	}

	if err := state.AcceptProposal(
		replacementLeader,
		1,
		8,
		1,
	); err != nil {
		t.Fatalf("accept replacement proposal: %v", err)
	}

	// An approval envelope from the failed view must not be accepted.
	err = state.RecordApproval(viewZeroApprovals[0])

	if !errors.Is(err, consensus.ErrViewMismatch) {
		t.Fatalf(
			"expected old-view rejection, got %v",
			err,
		)
	}

	viewOneApprovals := make(
		[]wire.Approval,
		0,
		thresholdValue,
	)

	for index, signer := range signers {
		result, err := signer.Approve(
			ctx,
			authorized,
			1,
			start,
		)
		if err != nil {
			t.Fatalf(
				"node %d create view-one approval: %v",
				index,
				err,
			)
		}

		if result.Created {
			t.Fatalf(
				"node %d created a second BLS partial",
				index,
			)
		}

		if !bytes.Equal(
			viewZeroApprovals[index].PartialBLSSig,
			result.Approval.PartialBLSSig,
		) {
			t.Fatalf(
				"node %d changed its persistent BLS partial",
				index,
			)
		}

		if bytes.Equal(
			viewZeroApprovals[index].IdentitySig,
			result.Approval.IdentitySig,
		) {
			t.Fatalf(
				"node %d reused an old-view identity envelope",
				index,
			)
		}

		if err := state.RecordApproval(
			result.Approval,
		); err != nil {
			t.Fatalf(
				"record node %d view-one approval: %v",
				index,
				err,
			)
		}

		viewOneApprovals = append(
			viewOneApprovals,
			result.Approval,
		)
	}

	if !state.ReadyToCertify() {
		t.Fatal("replacement leader did not receive threshold approvals")
	}

	certificate, err :=
		thresholdprotocol.RecoverAuthenticatedCertificate(
			scheme,
			dkgResult.PublicPoly,
			dkgResult.PublicKey,
			authorized,
			1,
			viewOneApprovals,
			identityRegistry,
			uint32(thresholdValue),
			uint32(nodeCount),
		)
	if err != nil {
		t.Fatalf(
			"replacement leader recover certificate: %v",
			err,
		)
	}

	if len(certificate.ThresholdBLSSig) != 48 {
		t.Fatalf(
			"certificate size=%d; expected 48",
			len(certificate.ThresholdBLSSig),
		)
	}

	if err := state.MarkCertified(certificate); err != nil {
		t.Fatalf("mark round certified: %v", err)
	}

	if state.Phase() != consensus.PhaseCertified {
		t.Fatalf(
			"final phase=%s; expected certified",
			state.Phase(),
		)
	}
}
