package consensus

import (
	"crypto/ed25519"
	"fmt"
	"time"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

// AcceptAuthenticatedProposal verifies base-station authorization and leader
// identity before mutating the round state.
func (state *RoundState) AcceptAuthenticatedProposal(
	proposal wire.Proposal,
	leaderPublicKey ed25519.PublicKey,
	baseStationPublicKey ed25519.PublicKey,
	now time.Time,
) error {
	if proposal.LeaderID != state.Leader() {
		return fmt.Errorf(
			"%w: sender=%d expected=%d",
			ErrNotCurrentLeader,
			proposal.LeaderID,
			state.Leader(),
		)
	}

	if err := identity.VerifyAuthorizedCommand(
		baseStationPublicKey,
		proposal.Authorized,
		now,
	); err != nil {
		return fmt.Errorf("verify base-station authorization: %w", err)
	}

	if err := identity.VerifyProposal(
		leaderPublicKey,
		proposal,
	); err != nil {
		return fmt.Errorf("verify leader proposal identity: %w", err)
	}

	return state.AcceptProposal(
		proposal.LeaderID,
		proposal.Authorized.Command.Epoch,
		proposal.Authorized.Command.Round,
		proposal.View,
	)
}
