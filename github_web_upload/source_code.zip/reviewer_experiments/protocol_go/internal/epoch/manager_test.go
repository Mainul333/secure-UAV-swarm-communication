package epoch_test

import (
	"bytes"
	"errors"
	"testing"

	"uav-bft/internal/epoch"
)

func configuration(number, activation uint64, fingerprint byte) epoch.Configuration {
	return epoch.Configuration{
		Number:               number,
		Membership:           []uint32{3, 1, 0, 2},
		Threshold:            3,
		PublicKeyFingerprint: bytes.Repeat([]byte{fingerprint}, 32),
		ActivateAtRound:      activation,
	}
}

func TestEpochStageActivateAndGrace(t *testing.T) {
	manager, err := epoch.NewManager(configuration(1, 1, 0x11), 2)
	if err != nil {
		t.Fatalf("create manager: %v", err)
	}
	if err := manager.Stage(configuration(2, 100, 0x22)); err != nil {
		t.Fatalf("stage epoch: %v", err)
	}
	if err := manager.Activate(99); !errors.Is(err, epoch.ErrActivationTooEarly) {
		t.Fatalf("expected early activation rejection, got %v", err)
	}
	if err := manager.Activate(100); err != nil {
		t.Fatalf("activate epoch: %v", err)
	}
	if manager.Current().Number != 2 {
		t.Fatal("epoch 2 did not activate")
	}
	if !manager.Accepts(1, 102) {
		t.Fatal("previous epoch rejected inside grace")
	}
	if manager.Accepts(1, 103) {
		t.Fatal("previous epoch accepted after grace")
	}
}

func TestEpochRejectsReusedKey(t *testing.T) {
	manager, err := epoch.NewManager(configuration(1, 1, 0x11), 2)
	if err != nil {
		t.Fatalf("create manager: %v", err)
	}
	err = manager.Stage(configuration(2, 100, 0x11))
	if !errors.Is(err, epoch.ErrReusedKeyFingerprint) {
		t.Fatalf("expected key reuse rejection, got %v", err)
	}
}
