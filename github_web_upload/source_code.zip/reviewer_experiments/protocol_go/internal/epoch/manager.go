package epoch

import (
	"bytes"
	"errors"
	"fmt"
	"slices"
)

var (
	ErrInvalidConfiguration = errors.New("invalid epoch configuration")
	ErrInvalidEpochNumber   = errors.New("next epoch number is not consecutive")
	ErrReusedKeyFingerprint = errors.New("new epoch reused the previous key fingerprint")
	ErrNoPendingEpoch       = errors.New("no pending epoch configuration")
	ErrActivationTooEarly   = errors.New("pending epoch activation round has not arrived")
)

type Configuration struct {
	Number               uint64   `json:"number"`
	Membership           []uint32 `json:"membership"`
	Threshold            int      `json:"threshold"`
	PublicKeyFingerprint []byte   `json:"public_key_fingerprint"`
	ActivateAtRound      uint64   `json:"activate_at_round"`
}

func (configuration Configuration) Validate() error {
	if len(configuration.Membership) < 2 ||
		configuration.Threshold < 2 ||
		configuration.Threshold > len(configuration.Membership) ||
		len(configuration.PublicKeyFingerprint) != 32 {
		return ErrInvalidConfiguration
	}

	members := append([]uint32(nil), configuration.Membership...)
	slices.Sort(members)
	for index := 1; index < len(members); index++ {
		if members[index] == members[index-1] {
			return fmt.Errorf(
				"%w: duplicate member=%d",
				ErrInvalidConfiguration,
				members[index],
			)
		}
	}
	return nil
}

func canonical(configuration Configuration) Configuration {
	configuration.Membership = append(
		[]uint32(nil),
		configuration.Membership...,
	)
	slices.Sort(configuration.Membership)
	configuration.PublicKeyFingerprint = append(
		[]byte(nil),
		configuration.PublicKeyFingerprint...,
	)
	return configuration
}

type Manager struct {
	current       Configuration
	previous      *Configuration
	pending       *Configuration
	previousGrace uint64
}

func NewManager(
	initial Configuration,
	previousGraceRounds uint64,
) (*Manager, error) {
	if err := initial.Validate(); err != nil {
		return nil, err
	}
	return &Manager{
		current:       canonical(initial),
		previousGrace: previousGraceRounds,
	}, nil
}

func (manager *Manager) Current() Configuration {
	return canonical(manager.current)
}

func (manager *Manager) Stage(next Configuration) error {
	if err := next.Validate(); err != nil {
		return err
	}
	if next.Number != manager.current.Number+1 {
		return fmt.Errorf(
			"%w: current=%d next=%d",
			ErrInvalidEpochNumber,
			manager.current.Number,
			next.Number,
		)
	}
	if bytes.Equal(
		next.PublicKeyFingerprint,
		manager.current.PublicKeyFingerprint,
	) {
		return ErrReusedKeyFingerprint
	}
	if next.ActivateAtRound == 0 {
		return ErrInvalidConfiguration
	}

	canonicalNext := canonical(next)
	manager.pending = &canonicalNext
	return nil
}

func (manager *Manager) Activate(round uint64) error {
	if manager.pending == nil {
		return ErrNoPendingEpoch
	}
	if round < manager.pending.ActivateAtRound {
		return fmt.Errorf(
			"%w: round=%d activation=%d",
			ErrActivationTooEarly,
			round,
			manager.pending.ActivateAtRound,
		)
	}

	old := canonical(manager.current)
	manager.previous = &old
	manager.current = canonical(*manager.pending)
	manager.pending = nil
	return nil
}

// Accepts reports whether a certificate epoch is acceptable at the supplied
// round. The previous epoch is allowed only for a bounded transition grace.
func (manager *Manager) Accepts(epochNumber, round uint64) bool {
	if epochNumber == manager.current.Number {
		return true
	}
	if manager.previous == nil || epochNumber != manager.previous.Number {
		return false
	}
	return round <= manager.current.ActivateAtRound+manager.previousGrace
}
