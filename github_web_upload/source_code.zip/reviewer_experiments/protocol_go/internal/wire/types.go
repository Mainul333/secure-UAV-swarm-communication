package wire

const (
	MessageTypeCommand uint16 = iota + 1
	MessageTypeProposal
	MessageTypeApproval
	MessageTypeCertificate
	MessageTypeViewChange
	MessageTypeTimeoutCertificate
	MessageTypeAcknowledgement
)
