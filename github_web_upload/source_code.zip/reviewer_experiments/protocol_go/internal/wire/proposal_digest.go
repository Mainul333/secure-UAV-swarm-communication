package wire

const proposalIdentityDomain = "UAV-BFT-PROPOSAL-IDENTITY-V1"

type proposalIdentityPayload struct {
	Authorized AuthorizedCommand `cbor:"1,keyasint"`
	View       uint64            `cbor:"2,keyasint"`
	LeaderID   uint32            `cbor:"3,keyasint"`
}

// ProposalIdentityDigest binds the leader identity to the complete
// base-station-authorized command and the current view.
func ProposalIdentityDigest(proposal Proposal) ([32]byte, error) {
	return domainSeparatedDigest(
		proposalIdentityDomain,
		proposalIdentityPayload{
			Authorized: proposal.Authorized,
			View:       proposal.View,
			LeaderID:   proposal.LeaderID,
		},
	)
}
