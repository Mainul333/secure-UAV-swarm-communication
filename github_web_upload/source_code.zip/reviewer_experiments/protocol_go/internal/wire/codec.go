package wire

import (
	"crypto/sha256"
	"errors"
	"time"

	"github.com/fxamacker/cbor/v2"
)

const (
	commandDomain       = "UAV-BFT-COMMAND-V1"
	authorizationDomain = "UAV-BFT-AUTHORIZATION-V1"
	certificateDomain   = "UAV-BFT-CERTIFICATE-V1"
)

var (
	canonicalMode       cbor.EncMode
	canonicalDecodeMode cbor.DecMode
)

var (
	ErrUnsupportedProtocol = errors.New("unsupported protocol version")
	ErrInvalidTimeWindow   = errors.New("invalid command time window")
	ErrCommandNotYetValid  = errors.New("command is not yet valid")
	ErrCommandExpired      = errors.New("command has expired")
	ErrInvalidNonce        = errors.New("command nonce must contain at least 16 bytes")
	ErrEmptyPayload        = errors.New("command payload is empty")
)

type authorizationPayload struct {
	BaseStationID uint32  `cbor:"1,keyasint"`
	Command       Command `cbor:"2,keyasint"`
}

type certificatePayload struct {
	Command        Command `cbor:"1,keyasint"`
	BaseStationID  uint32  `cbor:"2,keyasint"`
	BaseStationSig []byte  `cbor:"3,keyasint"`
}

func init() {
	options := cbor.CanonicalEncOptions()

	mode, err := options.EncMode()
	if err != nil {
		panic(err)
	}

	canonicalMode = mode

	decodeMode, err := (cbor.DecOptions{}).DecMode()
	if err != nil {
		panic(err)
	}

	canonicalDecodeMode = decodeMode
}

// CanonicalBytes serializes a protocol object deterministically.
func CanonicalBytes(value any) ([]byte, error) {
	return canonicalMode.Marshal(value)
}

// DecodeCanonical decodes one canonical-CBOR protocol object. Callers still
// perform semantic and cryptographic validation after decoding.
func DecodeCanonical(encoded []byte, destination any) error {
	if len(encoded) == 0 {
		return errors.New("canonical CBOR payload is empty")
	}

	if destination == nil {
		return errors.New("canonical CBOR destination is nil")
	}

	return canonicalDecodeMode.Unmarshal(encoded, destination)
}

func domainSeparatedDigest(domain string, value any) ([32]byte, error) {
	encoded, err := CanonicalBytes(value)
	if err != nil {
		return [32]byte{}, err
	}

	hasher := sha256.New()

	if _, err := hasher.Write([]byte(domain)); err != nil {
		return [32]byte{}, err
	}

	if _, err := hasher.Write([]byte{0}); err != nil {
		return [32]byte{}, err
	}

	if _, err := hasher.Write(encoded); err != nil {
		return [32]byte{}, err
	}

	var digest [32]byte
	copy(digest[:], hasher.Sum(nil))

	return digest, nil
}

// CommandDigest identifies the command independently of its signatures.
func CommandDigest(command Command) ([32]byte, error) {
	return domainSeparatedDigest(commandDomain, command)
}

// AuthorizationDigest is signed by the base station. It binds the
// base-station identity and the complete command.
func AuthorizationDigest(
	command Command,
	baseStationID uint32,
) ([32]byte, error) {
	payload := authorizationPayload{
		BaseStationID: baseStationID,
		Command:       command,
	}

	return domainSeparatedDigest(authorizationDomain, payload)
}

// CertificateDigest is the digest that UAV threshold shares will certify.
// It binds the command to the exact base-station authorization token.
func CertificateDigest(
	authorized AuthorizedCommand,
) ([32]byte, error) {
	payload := certificatePayload{
		Command:        authorized.Command,
		BaseStationID:  authorized.BaseStationID,
		BaseStationSig: authorized.BaseStationSig,
	}

	return domainSeparatedDigest(certificateDomain, payload)
}

// ValidateCommand checks replay-sensitive and time-sensitive command fields.
func ValidateCommand(command Command, now time.Time) error {
	if command.ProtocolVersion != CurrentProtocolVersion {
		return ErrUnsupportedProtocol
	}

	if command.ExpiresAtUnixNs <= command.IssuedAtUnixNs {
		return ErrInvalidTimeWindow
	}

	nowUnixNs := now.UnixNano()

	if nowUnixNs < command.IssuedAtUnixNs {
		return ErrCommandNotYetValid
	}

	if nowUnixNs > command.ExpiresAtUnixNs {
		return ErrCommandExpired
	}

	if len(command.Nonce) < 16 {
		return ErrInvalidNonce
	}

	if len(command.Payload) == 0 {
		return ErrEmptyPayload
	}

	return nil
}
