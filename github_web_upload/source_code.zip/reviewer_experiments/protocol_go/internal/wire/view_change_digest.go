package wire

import (
	"crypto/sha256"
	"errors"
)

const viewChangeIdentityDomain = "UAV-BFT-VIEW-CHANGE-IDENTITY-V1"

var ErrInvalidViewChangeDigest = errors.New(
	"view-change command digest must contain exactly 32 bytes",
)

type viewChangeIdentityPayload struct {
	Epoch         uint64 `cbor:"1,keyasint"`
	Round         uint64 `cbor:"2,keyasint"`
	NewView       uint64 `cbor:"3,keyasint"`
	CommandDigest []byte `cbor:"4,keyasint"`
	SenderID      uint32 `cbor:"5,keyasint"`
}

// ViewChangeIdentityDigest returns the digest signed by a UAV identity key.
// IdentitySig is deliberately excluded from its own signed payload.
func ViewChangeIdentityDigest(change ViewChange) ([32]byte, error) {
	if len(change.CommandDigest) != sha256.Size {
		return [32]byte{}, ErrInvalidViewChangeDigest
	}

	payload := viewChangeIdentityPayload{
		Epoch:         change.Epoch,
		Round:         change.Round,
		NewView:       change.NewView,
		CommandDigest: append([]byte(nil), change.CommandDigest...),
		SenderID:      change.SenderID,
	}

	return domainSeparatedDigest(viewChangeIdentityDomain, payload)
}
