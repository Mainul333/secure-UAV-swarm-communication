package wire_test

import (
	"bytes"
	"testing"
	"time"

	"uav-bft/internal/wire"
)

func testCommand(now time.Time) wire.Command {
	return wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           7,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte("TAKEOFF:5M"),
		Nonce:           []byte("1234567890ABCDEF"),
	}
}

func TestCanonicalEncodingIsDeterministic(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()
	command := testCommand(now)

	first, err := wire.CanonicalBytes(command)
	if err != nil {
		t.Fatalf("first encoding failed: %v", err)
	}

	second, err := wire.CanonicalBytes(command)
	if err != nil {
		t.Fatalf("second encoding failed: %v", err)
	}

	if !bytes.Equal(first, second) {
		t.Fatal("canonical encodings differ")
	}
}

func TestCommandDigestChangesAfterModification(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()

	firstCommand := testCommand(now)
	secondCommand := testCommand(now)
	secondCommand.Payload = []byte("LAND")

	firstDigest, err := wire.CommandDigest(firstCommand)
	if err != nil {
		t.Fatalf("first digest failed: %v", err)
	}

	secondDigest, err := wire.CommandDigest(secondCommand)
	if err != nil {
		t.Fatalf("second digest failed: %v", err)
	}

	if bytes.Equal(firstDigest[:], secondDigest[:]) {
		t.Fatal("modified command produced the same digest")
	}
}

func TestExpiredCommandRejected(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()
	command := testCommand(now)

	command.IssuedAtUnixNs = now.Add(-2 * time.Minute).UnixNano()
	command.ExpiresAtUnixNs = now.Add(-time.Minute).UnixNano()

	if err := wire.ValidateCommand(command, now); err == nil {
		t.Fatal("expired command was accepted")
	}
}
