package wire_test

import (
	"bytes"
	"testing"

	"uav-bft/internal/wire"
)

func sampleApproval() wire.Approval {
	return wire.Approval{
		Epoch:         1,
		Round:         5,
		View:          0,
		CommandDigest: bytes.Repeat([]byte{0x11}, 32),
		SignerID:      2,
		PartialBLSSig: bytes.Repeat([]byte{0x22}, 50),
		IdentitySig:   bytes.Repeat([]byte{0x33}, 64),
	}
}

func TestApprovalIdentityDigestIsDeterministic(t *testing.T) {
	approval := sampleApproval()

	first, err := wire.ApprovalIdentityDigest(approval)
	if err != nil {
		t.Fatalf("first approval digest: %v", err)
	}

	second, err := wire.ApprovalIdentityDigest(approval)
	if err != nil {
		t.Fatalf("second approval digest: %v", err)
	}

	if !bytes.Equal(first[:], second[:]) {
		t.Fatal("approval identity digests differ")
	}
}

func TestApprovalIdentityDigestIgnoresIdentitySignature(
	t *testing.T,
) {
	firstApproval := sampleApproval()
	secondApproval := sampleApproval()

	secondApproval.IdentitySig = bytes.Repeat(
		[]byte{0x99},
		64,
	)

	first, err := wire.ApprovalIdentityDigest(firstApproval)
	if err != nil {
		t.Fatalf("first digest: %v", err)
	}

	second, err := wire.ApprovalIdentityDigest(secondApproval)
	if err != nil {
		t.Fatalf("second digest: %v", err)
	}

	if !bytes.Equal(first[:], second[:]) {
		t.Fatal("identity signature changed its own signed digest")
	}
}

func TestApprovalIdentityDigestBindsView(t *testing.T) {
	firstApproval := sampleApproval()
	secondApproval := sampleApproval()
	secondApproval.View++

	first, err := wire.ApprovalIdentityDigest(firstApproval)
	if err != nil {
		t.Fatalf("first digest: %v", err)
	}

	second, err := wire.ApprovalIdentityDigest(secondApproval)
	if err != nil {
		t.Fatalf("second digest: %v", err)
	}

	if bytes.Equal(first[:], second[:]) {
		t.Fatal("different views produced the same identity digest")
	}
}

func TestApprovalIdentityDigestBindsPartialSignature(
	t *testing.T,
) {
	firstApproval := sampleApproval()
	secondApproval := sampleApproval()
	secondApproval.PartialBLSSig[10] ^= 0x01

	first, err := wire.ApprovalIdentityDigest(firstApproval)
	if err != nil {
		t.Fatalf("first digest: %v", err)
	}

	second, err := wire.ApprovalIdentityDigest(secondApproval)
	if err != nil {
		t.Fatalf("second digest: %v", err)
	}

	if bytes.Equal(first[:], second[:]) {
		t.Fatal("modified partial produced the same identity digest")
	}
}
