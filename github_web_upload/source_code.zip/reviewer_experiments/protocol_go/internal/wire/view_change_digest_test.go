package wire_test

import (
	"bytes"
	"testing"

	"uav-bft/internal/wire"
)

func TestViewChangeIdentityDigestBindsViewAndSender(t *testing.T) {
	base := wire.ViewChange{
		Epoch:         2,
		Round:         9,
		NewView:       3,
		CommandDigest: bytes.Repeat([]byte{0x44}, 32),
		SenderID:      7,
	}

	first, err := wire.ViewChangeIdentityDigest(base)
	if err != nil {
		t.Fatalf("first digest: %v", err)
	}

	modifiedView := base
	modifiedView.NewView++
	second, err := wire.ViewChangeIdentityDigest(modifiedView)
	if err != nil {
		t.Fatalf("modified-view digest: %v", err)
	}

	if bytes.Equal(first[:], second[:]) {
		t.Fatal("new view did not change the digest")
	}

	modifiedSender := base
	modifiedSender.SenderID++
	third, err := wire.ViewChangeIdentityDigest(modifiedSender)
	if err != nil {
		t.Fatalf("modified-sender digest: %v", err)
	}

	if bytes.Equal(first[:], third[:]) {
		t.Fatal("sender ID did not change the digest")
	}
}

func TestCanonicalDecodeRoundTrip(t *testing.T) {
	original := wire.NetworkEnvelope{
		Type:       4,
		SenderID:   1,
		ReceiverID: 2,
		Sequence:   99,
		Payload:    []byte("payload"),
	}

	encoded, err := wire.CanonicalBytes(original)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}

	var decoded wire.NetworkEnvelope
	if err := wire.DecodeCanonical(encoded, &decoded); err != nil {
		t.Fatalf("decode: %v", err)
	}

	if decoded.Type != original.Type ||
		decoded.SenderID != original.SenderID ||
		decoded.ReceiverID != original.ReceiverID ||
		decoded.Sequence != original.Sequence ||
		!bytes.Equal(decoded.Payload, original.Payload) {
		t.Fatalf("round trip mismatch: %#v", decoded)
	}
}
