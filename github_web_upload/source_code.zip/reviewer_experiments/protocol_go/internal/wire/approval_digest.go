package wire

import (
	"crypto/sha256"
	"errors"
)

const approvalIdentityDomain = "UAV-BFT-APPROVAL-IDENTITY-V1"

var (
	ErrInvalidApprovalCommandDigest = errors.New(
		"approval command digest must contain exactly 32 bytes",
	)
	ErrEmptyApprovalPartial = errors.New(
		"approval threshold partial signature is empty",
	)
)

// approvalIdentityPayload deliberately excludes IdentitySig.
//
// The Ed25519 identity signature binds:
//   - epoch and round,
//   - current view,
//   - command digest,
//   - claimed signer ID,
//   - exact threshold-BLS partial signature.
type approvalIdentityPayload struct {
	Epoch         uint64 `cbor:"1,keyasint"`
	Round         uint64 `cbor:"2,keyasint"`
	View          uint64 `cbor:"3,keyasint"`
	CommandDigest []byte `cbor:"4,keyasint"`
	SignerID      uint32 `cbor:"5,keyasint"`
	PartialBLSSig []byte `cbor:"6,keyasint"`
}

// ApprovalIdentityDigest returns the digest signed by the UAV's
// long-term Ed25519 identity key.
func ApprovalIdentityDigest(
	approval Approval,
) ([32]byte, error) {
	if len(approval.CommandDigest) != sha256.Size {
		return [32]byte{}, ErrInvalidApprovalCommandDigest
	}

	if len(approval.PartialBLSSig) == 0 {
		return [32]byte{}, ErrEmptyApprovalPartial
	}

	payload := approvalIdentityPayload{
		Epoch: approval.Epoch,
		Round: approval.Round,
		View:  approval.View,
		CommandDigest: append(
			[]byte(nil),
			approval.CommandDigest...,
		),
		SignerID: approval.SignerID,
		PartialBLSSig: append(
			[]byte(nil),
			approval.PartialBLSSig...,
		),
	}

	return domainSeparatedDigest(
		approvalIdentityDomain,
		payload,
	)
}
