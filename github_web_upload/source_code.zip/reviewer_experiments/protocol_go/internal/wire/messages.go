package wire

const CurrentProtocolVersion uint16 = 1

// Command is the base-station command that will eventually be certified
// by the UAV swarm.
type Command struct {
	ProtocolVersion uint16 `cbor:"1,keyasint"`
	Epoch           uint64 `cbor:"2,keyasint"`
	Round           uint64 `cbor:"3,keyasint"`
	IssuedAtUnixNs  int64  `cbor:"4,keyasint"`
	ExpiresAtUnixNs int64  `cbor:"5,keyasint"`
	CommandType     uint16 `cbor:"6,keyasint"`
	Payload         []byte `cbor:"7,keyasint"`
	Nonce           []byte `cbor:"8,keyasint"`
}

// AuthorizedCommand contains the command and its end-to-end
// base-station authorization.
type AuthorizedCommand struct {
	Command        Command `cbor:"1,keyasint"`
	BaseStationID  uint32  `cbor:"2,keyasint"`
	BaseStationSig []byte  `cbor:"3,keyasint"`
}

// Proposal is sent by the current leader after verifying the
// base-station authorization.
type Proposal struct {
	Authorized        AuthorizedCommand `cbor:"1,keyasint"`
	View              uint64            `cbor:"2,keyasint"`
	LeaderID          uint32            `cbor:"3,keyasint"`
	LeaderIdentitySig []byte            `cbor:"4,keyasint"`
}

// Approval contains one follower's threshold-BLS partial signature.
type Approval struct {
	Epoch         uint64 `cbor:"1,keyasint"`
	Round         uint64 `cbor:"2,keyasint"`
	View          uint64 `cbor:"3,keyasint"`
	CommandDigest []byte `cbor:"4,keyasint"`
	SignerID      uint32 `cbor:"5,keyasint"`
	PartialBLSSig []byte `cbor:"6,keyasint"`
	IdentitySig   []byte `cbor:"7,keyasint"`
}

// Certificate contains the reconstructed threshold signature.
type Certificate struct {
	Epoch           uint64   `cbor:"1,keyasint"`
	Round           uint64   `cbor:"2,keyasint"`
	View            uint64   `cbor:"3,keyasint"`
	CommandDigest   []byte   `cbor:"4,keyasint"`
	SignerIDs       []uint32 `cbor:"5,keyasint"`
	ThresholdBLSSig []byte   `cbor:"6,keyasint"`
}

// ViewChange requests movement to a replacement leader.
type ViewChange struct {
	Epoch         uint64 `cbor:"1,keyasint"`
	Round         uint64 `cbor:"2,keyasint"`
	NewView       uint64 `cbor:"3,keyasint"`
	CommandDigest []byte `cbor:"4,keyasint"`
	SenderID      uint32 `cbor:"5,keyasint"`
	IdentitySig   []byte `cbor:"6,keyasint"`
}

// TimeoutCertificate proves that a threshold of authenticated members
// requested the same replacement view for one command digest.
type TimeoutCertificate struct {
	Epoch         uint64       `cbor:"1,keyasint"`
	Round         uint64       `cbor:"2,keyasint"`
	NewView       uint64       `cbor:"3,keyasint"`
	CommandDigest []byte       `cbor:"4,keyasint"`
	Changes       []ViewChange `cbor:"5,keyasint"`
}

// NetworkEnvelope is the application-level wrapper used by UDP endpoints.
// The payload contains canonical CBOR for the message selected by Type.
type NetworkEnvelope struct {
	Type       uint16 `cbor:"1,keyasint"`
	SenderID   uint32 `cbor:"2,keyasint"`
	ReceiverID uint32 `cbor:"3,keyasint"`
	Sequence   uint64 `cbor:"4,keyasint"`
	Payload    []byte `cbor:"5,keyasint"`
}
