package transport_test

import (
	"bytes"
	"context"
	"errors"
	"testing"
	"time"

	"uav-bft/internal/transport"
)

func TestFrameRoundTripAndChecksum(t *testing.T) {
	original := transport.Frame{
		Type:       2,
		SenderID:   3,
		ReceiverID: 4,
		Sequence:   99,
		Payload:    []byte("authenticated protocol payload"),
	}

	encoded, err := transport.EncodeFrame(original)
	if err != nil {
		t.Fatalf("encode frame: %v", err)
	}

	decoded, err := transport.DecodeFrame(encoded)
	if err != nil {
		t.Fatalf("decode frame: %v", err)
	}

	if decoded.Type != original.Type ||
		decoded.SenderID != original.SenderID ||
		decoded.ReceiverID != original.ReceiverID ||
		decoded.Sequence != original.Sequence ||
		!bytes.Equal(decoded.Payload, original.Payload) {
		t.Fatalf("frame mismatch: %#v", decoded)
	}

	encoded[len(encoded)-1] ^= 0x01
	_, err = transport.DecodeFrame(encoded)
	if !errors.Is(err, transport.ErrFrameChecksum) {
		t.Fatalf("expected checksum error, got %v", err)
	}
}

func TestUDPLoopback(t *testing.T) {
	sender, err := transport.ListenUDP("127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen sender: %v", err)
	}
	defer sender.Close()

	receiver, err := transport.ListenUDP("127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen receiver: %v", err)
	}
	defer receiver.Close()

	ctx, cancel := context.WithTimeout(
		context.Background(),
		2*time.Second,
	)
	defer cancel()

	expected := transport.Frame{
		Type:       7,
		SenderID:   1,
		ReceiverID: 2,
		Sequence:   8,
		Payload:    []byte("loopback"),
	}

	if err := sender.Send(ctx, receiver.LocalAddr(), expected); err != nil {
		t.Fatalf("send loopback: %v", err)
	}

	received, _, err := receiver.Receive(ctx)
	if err != nil {
		t.Fatalf("receive loopback: %v", err)
	}

	if received.Sequence != expected.Sequence ||
		!bytes.Equal(received.Payload, expected.Payload) {
		t.Fatalf("received mismatch: %#v", received)
	}
}
