package transport

import (
	"context"
	"errors"
	"fmt"
	"net"
	"time"
)

const maxDatagramSize = frameHeaderSize + MaxPayloadSize

type Endpoint struct {
	connection *net.UDPConn
}

func ListenUDP(address string) (*Endpoint, error) {
	resolved, err := net.ResolveUDPAddr("udp", address)
	if err != nil {
		return nil, fmt.Errorf("resolve UDP listen address: %w", err)
	}

	connection, err := net.ListenUDP("udp", resolved)
	if err != nil {
		return nil, fmt.Errorf("listen UDP: %w", err)
	}

	return &Endpoint{connection: connection}, nil
}

func (endpoint *Endpoint) Close() error {
	if endpoint == nil || endpoint.connection == nil {
		return nil
	}
	return endpoint.connection.Close()
}

func (endpoint *Endpoint) LocalAddr() *net.UDPAddr {
	if endpoint == nil || endpoint.connection == nil {
		return nil
	}
	address, _ := endpoint.connection.LocalAddr().(*net.UDPAddr)
	return address
}

func deadlineFromContext(ctx context.Context) time.Time {
	if deadline, exists := ctx.Deadline(); exists {
		return deadline
	}
	return time.Now().Add(30 * time.Second)
}

func (endpoint *Endpoint) Send(
	ctx context.Context,
	target *net.UDPAddr,
	frame Frame,
) error {
	if endpoint == nil || endpoint.connection == nil {
		return errors.New("UDP endpoint is closed")
	}
	if target == nil {
		return errors.New("UDP target address is nil")
	}

	encoded, err := EncodeFrame(frame)
	if err != nil {
		return err
	}

	if err := endpoint.connection.SetWriteDeadline(
		deadlineFromContext(ctx),
	); err != nil {
		return fmt.Errorf("set UDP write deadline: %w", err)
	}

	written, err := endpoint.connection.WriteToUDP(encoded, target)
	if err != nil {
		return fmt.Errorf("write UDP frame: %w", err)
	}
	if written != len(encoded) {
		return fmt.Errorf(
			"short UDP write: wrote=%d expected=%d",
			written,
			len(encoded),
		)
	}
	return nil
}

func (endpoint *Endpoint) Receive(
	ctx context.Context,
) (Frame, *net.UDPAddr, error) {
	if endpoint == nil || endpoint.connection == nil {
		return Frame{}, nil, errors.New("UDP endpoint is closed")
	}

	if err := endpoint.connection.SetReadDeadline(
		deadlineFromContext(ctx),
	); err != nil {
		return Frame{}, nil, fmt.Errorf(
			"set UDP read deadline: %w",
			err,
		)
	}

	buffer := make([]byte, maxDatagramSize)
	read, remote, err := endpoint.connection.ReadFromUDP(buffer)
	if err != nil {
		return Frame{}, nil, fmt.Errorf("read UDP frame: %w", err)
	}

	frame, err := DecodeFrame(buffer[:read])
	if err != nil {
		return Frame{}, remote, err
	}
	return frame, remote, nil
}
