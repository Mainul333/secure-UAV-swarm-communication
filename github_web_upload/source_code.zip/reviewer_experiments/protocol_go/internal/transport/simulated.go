package transport

import (
	"errors"
	"fmt"
	"math/rand"
	"sync"
	"time"
)

var (
	ErrInvalidNetworkRate = errors.New(
		"network probabilities must be within [0,1]",
	)
	ErrInvalidMessageSize = errors.New(
		"message size cannot be negative",
	)
)

type Link struct {
	From uint32
	To   uint32
}

// Profile is an application-layer network-fault profile. It is intentionally
// separate from ns-3: this model makes protocol tests reproducible, while
// fading, routing, MAC retries, and mobility are measured later in ns-3.
type Profile struct {
	Name          string
	BaseDelay     time.Duration
	Jitter        time.Duration
	LossRate      float64
	DuplicateRate float64
	ReorderRate   float64
	Partitions    map[Link]struct{}
}

func (profile Profile) Validate() error {
	for name, value := range map[string]float64{
		"loss":      profile.LossRate,
		"duplicate": profile.DuplicateRate,
		"reorder":   profile.ReorderRate,
	} {
		if value < 0 || value > 1 {
			return fmt.Errorf(
				"%w: %s=%f",
				ErrInvalidNetworkRate,
				name,
				value,
			)
		}
	}

	if profile.BaseDelay < 0 || profile.Jitter < 0 {
		return errors.New("network delay and jitter cannot be negative")
	}

	return nil
}

type Message struct {
	Sequence  uint64
	Kind      string
	From      uint32
	To        uint32
	SizeBytes int
}

type Delivery struct {
	Message Message
	Delay   time.Duration
}

type Statistics struct {
	SentMessages      uint64
	DeliveredMessages uint64
	DroppedMessages   uint64
	DuplicateMessages uint64
	ReorderedMessages uint64
	SentBytes         uint64
	DeliveredBytes    uint64
}

// Simulator applies deterministic seeded network behavior.
type Simulator struct {
	mu      sync.Mutex
	profile Profile
	random  *rand.Rand
	stats   Statistics
}

func NewSimulator(profile Profile, seed int64) (*Simulator, error) {
	if err := profile.Validate(); err != nil {
		return nil, err
	}

	partitions := make(map[Link]struct{}, len(profile.Partitions))
	for link := range profile.Partitions {
		partitions[link] = struct{}{}
	}
	profile.Partitions = partitions

	return &Simulator{
		profile: profile,
		random:  rand.New(rand.NewSource(seed)),
	}, nil
}

func (simulator *Simulator) Profile() Profile {
	simulator.mu.Lock()
	defer simulator.mu.Unlock()

	copyProfile := simulator.profile
	copyProfile.Partitions = make(
		map[Link]struct{},
		len(simulator.profile.Partitions),
	)
	for link := range simulator.profile.Partitions {
		copyProfile.Partitions[link] = struct{}{}
	}
	return copyProfile
}

func (simulator *Simulator) randomDelay() time.Duration {
	delay := simulator.profile.BaseDelay
	if simulator.profile.Jitter > 0 {
		span := int64(simulator.profile.Jitter)*2 + 1
		offset := simulator.random.Int63n(span) -
			int64(simulator.profile.Jitter)
		delay += time.Duration(offset)
	}
	if delay < 0 {
		return 0
	}
	return delay
}

func (simulator *Simulator) Send(
	message Message,
) ([]Delivery, error) {
	if message.SizeBytes < 0 {
		return nil, ErrInvalidMessageSize
	}

	simulator.mu.Lock()
	defer simulator.mu.Unlock()

	simulator.stats.SentMessages++
	simulator.stats.SentBytes += uint64(message.SizeBytes)

	if _, partitioned := simulator.profile.Partitions[Link{
		From: message.From,
		To:   message.To,
	}]; partitioned {
		simulator.stats.DroppedMessages++
		return nil, nil
	}

	if simulator.random.Float64() < simulator.profile.LossRate {
		simulator.stats.DroppedMessages++
		return nil, nil
	}

	delay := simulator.randomDelay()
	if simulator.random.Float64() < simulator.profile.ReorderRate {
		// A deterministic extra delay moves this delivery behind later traffic.
		delay += simulator.profile.BaseDelay + simulator.profile.Jitter
		simulator.stats.ReorderedMessages++
	}

	deliveries := []Delivery{{Message: message, Delay: delay}}
	simulator.stats.DeliveredMessages++
	simulator.stats.DeliveredBytes += uint64(message.SizeBytes)

	if simulator.random.Float64() < simulator.profile.DuplicateRate {
		duplicateDelay := delay + simulator.randomDelay() + time.Microsecond
		deliveries = append(deliveries, Delivery{
			Message: message,
			Delay:   duplicateDelay,
		})
		simulator.stats.DeliveredMessages++
		simulator.stats.DuplicateMessages++
		simulator.stats.DeliveredBytes += uint64(message.SizeBytes)
	}

	return deliveries, nil
}

func (simulator *Simulator) Statistics() Statistics {
	simulator.mu.Lock()
	defer simulator.mu.Unlock()
	return simulator.stats
}

func IdealProfile() Profile {
	return Profile{Name: "ideal", BaseDelay: time.Millisecond}
}

func LightWiFiProfile() Profile {
	return Profile{
		Name:          "wifi_light",
		BaseDelay:     4 * time.Millisecond,
		Jitter:        2 * time.Millisecond,
		LossRate:      0.01,
		DuplicateRate: 0.001,
		ReorderRate:   0.002,
	}
}

func StressedWiFiProfile() Profile {
	return Profile{
		Name:          "wifi_stressed",
		BaseDelay:     18 * time.Millisecond,
		Jitter:        15 * time.Millisecond,
		LossRate:      0.10,
		DuplicateRate: 0.01,
		ReorderRate:   0.04,
	}
}
