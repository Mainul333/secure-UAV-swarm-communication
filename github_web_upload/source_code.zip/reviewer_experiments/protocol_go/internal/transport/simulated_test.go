package transport_test

import (
	"reflect"
	"testing"
	"time"

	"uav-bft/internal/transport"
)

func TestSimulatorIsDeterministic(t *testing.T) {
	profile := transport.Profile{
		Name:          "test",
		BaseDelay:     10 * time.Millisecond,
		Jitter:        5 * time.Millisecond,
		LossRate:      0.2,
		DuplicateRate: 0.2,
		ReorderRate:   0.2,
	}

	first, err := transport.NewSimulator(profile, 99)
	if err != nil {
		t.Fatalf("first simulator: %v", err)
	}
	second, err := transport.NewSimulator(profile, 99)
	if err != nil {
		t.Fatalf("second simulator: %v", err)
	}

	for sequence := uint64(0); sequence < 50; sequence++ {
		message := transport.Message{
			Sequence:  sequence,
			Kind:      "approval",
			From:      uint32(sequence % 4),
			To:        0,
			SizeBytes: 160,
		}

		firstDelivery, err := first.Send(message)
		if err != nil {
			t.Fatalf("first send: %v", err)
		}
		secondDelivery, err := second.Send(message)
		if err != nil {
			t.Fatalf("second send: %v", err)
		}

		if !reflect.DeepEqual(firstDelivery, secondDelivery) {
			t.Fatalf(
				"sequence %d differs: first=%v second=%v",
				sequence,
				firstDelivery,
				secondDelivery,
			)
		}
	}
}

func TestForcedLossAndPartition(t *testing.T) {
	profile := transport.Profile{
		Name:     "loss",
		LossRate: 1,
	}
	simulator, err := transport.NewSimulator(profile, 1)
	if err != nil {
		t.Fatalf("create simulator: %v", err)
	}

	deliveries, err := simulator.Send(transport.Message{SizeBytes: 10})
	if err != nil {
		t.Fatalf("send: %v", err)
	}
	if len(deliveries) != 0 {
		t.Fatal("100% loss delivered a message")
	}

	partitioned, err := transport.NewSimulator(
		transport.Profile{
			Name: "partition",
			Partitions: map[transport.Link]struct{}{
				{From: 2, To: 0}: {},
			},
		},
		1,
	)
	if err != nil {
		t.Fatalf("partition simulator: %v", err)
	}

	deliveries, err = partitioned.Send(transport.Message{
		From:      2,
		To:        0,
		SizeBytes: 10,
	})
	if err != nil {
		t.Fatalf("partition send: %v", err)
	}
	if len(deliveries) != 0 {
		t.Fatal("partitioned link delivered a message")
	}
}
