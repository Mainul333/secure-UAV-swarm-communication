package transport

import (
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
)

const (
	frameMagic      uint32 = 0x55425631 // "UBV1"
	frameVersion    uint8  = 1
	frameHeaderSize        = 32
	MaxPayloadSize         = 1 << 20
)

var (
	ErrFrameTooShort     = errors.New("network frame is too short")
	ErrFrameMagic        = errors.New("invalid network frame magic")
	ErrFrameVersion      = errors.New("unsupported network frame version")
	ErrFrameLength       = errors.New("network frame length mismatch")
	ErrFramePayloadLarge = errors.New("network frame payload is too large")
	ErrFrameChecksum     = errors.New("network frame checksum mismatch")
)

type Frame struct {
	Type       uint16
	SenderID   uint32
	ReceiverID uint32
	Sequence   uint64
	Payload    []byte
}

func EncodeFrame(frame Frame) ([]byte, error) {
	if len(frame.Payload) > MaxPayloadSize {
		return nil, ErrFramePayloadLarge
	}

	encoded := make([]byte, frameHeaderSize+len(frame.Payload))
	binary.BigEndian.PutUint32(encoded[0:4], frameMagic)
	encoded[4] = frameVersion
	encoded[5] = 0
	binary.BigEndian.PutUint16(encoded[6:8], frame.Type)
	binary.BigEndian.PutUint32(encoded[8:12], frame.SenderID)
	binary.BigEndian.PutUint32(encoded[12:16], frame.ReceiverID)
	binary.BigEndian.PutUint64(encoded[16:24], frame.Sequence)
	binary.BigEndian.PutUint32(encoded[24:28], uint32(len(frame.Payload)))
	copy(encoded[frameHeaderSize:], frame.Payload)

	checksum := crc32.ChecksumIEEE(encoded[frameHeaderSize:])
	binary.BigEndian.PutUint32(encoded[28:32], checksum)

	return encoded, nil
}

func DecodeFrame(encoded []byte) (Frame, error) {
	if len(encoded) < frameHeaderSize {
		return Frame{}, ErrFrameTooShort
	}

	if binary.BigEndian.Uint32(encoded[0:4]) != frameMagic {
		return Frame{}, ErrFrameMagic
	}

	if encoded[4] != frameVersion {
		return Frame{}, fmt.Errorf(
			"%w: received=%d expected=%d",
			ErrFrameVersion,
			encoded[4],
			frameVersion,
		)
	}

	payloadLength := int(binary.BigEndian.Uint32(encoded[24:28]))
	if payloadLength > MaxPayloadSize {
		return Frame{}, ErrFramePayloadLarge
	}
	if len(encoded) != frameHeaderSize+payloadLength {
		return Frame{}, fmt.Errorf(
			"%w: encoded=%d expected=%d",
			ErrFrameLength,
			len(encoded),
			frameHeaderSize+payloadLength,
		)
	}

	payload := encoded[frameHeaderSize:]
	expectedChecksum := binary.BigEndian.Uint32(encoded[28:32])
	if crc32.ChecksumIEEE(payload) != expectedChecksum {
		return Frame{}, ErrFrameChecksum
	}

	return Frame{
		Type:       binary.BigEndian.Uint16(encoded[6:8]),
		SenderID:   binary.BigEndian.Uint32(encoded[8:12]),
		ReceiverID: binary.BigEndian.Uint32(encoded[12:16]),
		Sequence:   binary.BigEndian.Uint64(encoded[16:24]),
		Payload:    append([]byte(nil), payload...),
	}, nil
}
