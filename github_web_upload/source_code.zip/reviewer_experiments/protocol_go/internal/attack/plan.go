package attack

import (
	"errors"
	"fmt"
	"slices"

	"uav-bft/internal/wire"
)

// Scenario names are written directly to experiment CSV files.
type Scenario string

const (
	Benign                 Scenario = "benign"
	LeaderCrash            Scenario = "leader_crash"
	ProposalWithholding    Scenario = "proposal_withholding"
	SelectiveProposal      Scenario = "selective_proposal"
	ApprovalDropping       Scenario = "approval_dropping"
	CertificateWithholding Scenario = "certificate_withholding"
	ForgedApproval         Scenario = "forged_approval"
	SignerSubstitution     Scenario = "signer_substitution"
	FollowerSilence        Scenario = "follower_silence"
)

var ErrUnknownScenario = errors.New("unknown attack scenario")

var knownScenarios = []Scenario{
	Benign,
	LeaderCrash,
	ProposalWithholding,
	SelectiveProposal,
	ApprovalDropping,
	CertificateWithholding,
	ForgedApproval,
	SignerSubstitution,
	FollowerSilence,
}

func ParseScenario(value string) (Scenario, error) {
	scenario := Scenario(value)
	if slices.Contains(knownScenarios, scenario) {
		return scenario, nil
	}
	return "", fmt.Errorf("%w: %s", ErrUnknownScenario, value)
}

func Scenarios() []Scenario {
	return append([]Scenario(nil), knownScenarios...)
}

// Plan describes deterministic adversarial behavior. A scenario applies only
// to the listed view, which lets experiments model one or more consecutive
// malicious leaders without making later honest views faulty automatically.
type Plan struct {
	Name          Scenario
	ViewScenarios map[uint64]Scenario
	SilentNodes   map[uint32]struct{}
}

func NewPlan(scenario Scenario) Plan {
	return Plan{
		Name: scenario,
		ViewScenarios: map[uint64]Scenario{
			0: scenario,
		},
		SilentNodes: make(map[uint32]struct{}),
	}
}

func BenignPlan() Plan {
	return NewPlan(Benign)
}

func (plan Plan) ScenarioAt(view uint64) Scenario {
	if scenario, exists := plan.ViewScenarios[view]; exists {
		return scenario
	}
	return Benign
}

func (plan Plan) NodeSilent(nodeID uint32) bool {
	_, exists := plan.SilentNodes[nodeID]
	return exists
}

// DeliverProposal reports whether a proposal reaches one recipient. ordinal
// is the recipient's deterministic position among candidate recipients.
func (plan Plan) DeliverProposal(
	view uint64,
	recipientID uint32,
	ordinal int,
	threshold int,
) bool {
	if plan.NodeSilent(recipientID) {
		return false
	}

	switch plan.ScenarioAt(view) {
	case LeaderCrash, ProposalWithholding:
		return false
	case SelectiveProposal:
		// Deliver to strictly fewer than t nodes so certification cannot occur.
		return ordinal < threshold-1
	default:
		return true
	}
}

// DeliverApproval reports whether an approval is forwarded to the leader.
// acceptedSoFar is the number already delivered in the current view.
func (plan Plan) DeliverApproval(
	view uint64,
	signerID uint32,
	acceptedSoFar int,
	threshold int,
) bool {
	if plan.NodeSilent(signerID) {
		return false
	}

	if plan.ScenarioAt(view) == ApprovalDropping {
		return acceptedSoFar < threshold-1
	}

	return true
}

func (plan Plan) DeliverCertificate(
	view uint64,
	recipientID uint32,
) bool {
	if plan.NodeSilent(recipientID) {
		return false
	}

	return plan.ScenarioAt(view) != CertificateWithholding
}

// MutateApproval applies attacks that should be rejected by the authenticated
// threshold layer. It never mutates the caller's byte slices in place.
func (plan Plan) MutateApproval(
	view uint64,
	approval wire.Approval,
) wire.Approval {
	approval.CommandDigest = append(
		[]byte(nil),
		approval.CommandDigest...,
	)
	approval.PartialBLSSig = append(
		[]byte(nil),
		approval.PartialBLSSig...,
	)
	approval.IdentitySig = append(
		[]byte(nil),
		approval.IdentitySig...,
	)

	switch plan.ScenarioAt(view) {
	case ForgedApproval:
		if len(approval.PartialBLSSig) > 0 {
			approval.PartialBLSSig[0] ^= 0x80
		}
	case SignerSubstitution:
		approval.SignerID++
	}

	return approval
}
