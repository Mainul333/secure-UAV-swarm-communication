package attack_test

import (
	"bytes"
	"testing"

	"uav-bft/internal/attack"
	"uav-bft/internal/wire"
)

func TestSelectiveProposalStaysBelowThreshold(t *testing.T) {
	plan := attack.NewPlan(attack.SelectiveProposal)

	delivered := 0
	for ordinal := 0; ordinal < 7; ordinal++ {
		if plan.DeliverProposal(0, uint32(ordinal), ordinal, 5) {
			delivered++
		}
	}

	if delivered != 4 {
		t.Fatalf("delivered=%d; expected 4", delivered)
	}

	if !plan.DeliverProposal(1, 6, 6, 5) {
		t.Fatal("honest replacement view remained selective")
	}
}

func TestApprovalDroppingStaysBelowThreshold(t *testing.T) {
	plan := attack.NewPlan(attack.ApprovalDropping)

	accepted := 0
	for signerID := uint32(0); signerID < 7; signerID++ {
		if plan.DeliverApproval(0, signerID, accepted, 5) {
			accepted++
		}
	}

	if accepted != 4 {
		t.Fatalf("accepted=%d; expected 4", accepted)
	}
}

func TestMutationDoesNotModifyOriginal(t *testing.T) {
	plan := attack.NewPlan(attack.ForgedApproval)
	original := wire.Approval{
		CommandDigest: bytes.Repeat([]byte{0x11}, 32),
		PartialBLSSig: bytes.Repeat([]byte{0x22}, 50),
		IdentitySig:   bytes.Repeat([]byte{0x33}, 64),
	}

	mutated := plan.MutateApproval(0, original)
	if bytes.Equal(mutated.PartialBLSSig, original.PartialBLSSig) {
		t.Fatal("forged scenario did not mutate the copy")
	}

	if original.PartialBLSSig[0] != 0x22 {
		t.Fatal("original approval was modified")
	}
}

func TestSilentNodeNeverSends(t *testing.T) {
	plan := attack.BenignPlan()
	plan.SilentNodes[2] = struct{}{}

	if plan.DeliverProposal(0, 2, 2, 3) {
		t.Fatal("silent node received proposal")
	}
	if plan.DeliverApproval(0, 2, 0, 3) {
		t.Fatal("silent node sent approval")
	}
}
