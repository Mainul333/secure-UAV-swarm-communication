package simulation

import (
	"bytes"
	"errors"
	"fmt"
	"sort"
	"time"

	"uav-bft/internal/attack"
	"uav-bft/internal/transport"
	"uav-bft/internal/wire"
)

var ErrInvalidSimulationConfig = errors.New(
	"invalid protocol simulation configuration",
)

type Config struct {
	NodeCount        int
	Threshold        int
	Rounds           int
	MaxViews         int
	TimeoutRetries   int
	ViewTimeout      time.Duration
	Seed             int64
	Network          transport.Profile
	Attack           attack.Plan
	PayloadBytes     int
	ReconstructDelay time.Duration
	VerifyDelay      time.Duration
}

func DefaultConfig() Config {
	return Config{
		NodeCount:        4,
		Threshold:        3,
		Rounds:           100,
		MaxViews:         5,
		TimeoutRetries:   3,
		ViewTimeout:      150 * time.Millisecond,
		Seed:             1,
		Network:          transport.IdealProfile(),
		Attack:           attack.BenignPlan(),
		PayloadBytes:     32,
		ReconstructDelay: 0,
		VerifyDelay:      0,
	}
}

func (config Config) Validate() error {
	if config.NodeCount < 2 ||
		config.Threshold < 2 ||
		config.Threshold > config.NodeCount ||
		config.Rounds <= 0 ||
		config.MaxViews <= 0 ||
		config.TimeoutRetries <= 0 ||
		config.ViewTimeout <= 0 ||
		config.PayloadBytes <= 0 ||
		config.ReconstructDelay < 0 ||
		config.VerifyDelay < 0 {
		return ErrInvalidSimulationConfig
	}
	if err := config.Network.Validate(); err != nil {
		return fmt.Errorf("%w: %v", ErrInvalidSimulationConfig, err)
	}
	return nil
}

type MessageSizes struct {
	Proposal           int
	Approval           int
	Certificate        int
	ViewChange         int
	TimeoutCertificate int
}

func encodedSize(value any) (int, error) {
	encoded, err := wire.CanonicalBytes(value)
	if err != nil {
		return 0, err
	}
	return len(encoded), nil
}

// CalculateMessageSizes records canonical application bytes only. UDP/IP,
// MAC headers, retries, and airtime are measured separately in later stages.
func CalculateMessageSizes(
	payloadBytes int,
	threshold int,
) (MessageSizes, error) {
	if payloadBytes <= 0 || threshold <= 0 {
		return MessageSizes{}, ErrInvalidSimulationConfig
	}

	digest := bytes.Repeat([]byte{0x11}, 32)
	authorized := wire.AuthorizedCommand{
		Command: wire.Command{
			ProtocolVersion: wire.CurrentProtocolVersion,
			Epoch:           1,
			Round:           1,
			IssuedAtUnixNs:  1,
			ExpiresAtUnixNs: 2,
			CommandType:     1,
			Payload:         bytes.Repeat([]byte{0x22}, payloadBytes),
			Nonce:           bytes.Repeat([]byte{0x33}, 16),
		},
		BaseStationID:  1,
		BaseStationSig: bytes.Repeat([]byte{0x44}, 64),
	}

	proposalSize, err := encodedSize(wire.Proposal{
		Authorized:        authorized,
		View:              0,
		LeaderID:          0,
		LeaderIdentitySig: bytes.Repeat([]byte{0x55}, 64),
	})
	if err != nil {
		return MessageSizes{}, err
	}

	approvalSize, err := encodedSize(wire.Approval{
		Epoch:         1,
		Round:         1,
		View:          0,
		CommandDigest: digest,
		SignerID:      0,
		PartialBLSSig: bytes.Repeat([]byte{0x66}, 50),
		IdentitySig:   bytes.Repeat([]byte{0x77}, 64),
	})
	if err != nil {
		return MessageSizes{}, err
	}

	signerIDs := make([]uint32, threshold)
	changes := make([]wire.ViewChange, threshold)
	for index := 0; index < threshold; index++ {
		signerIDs[index] = uint32(index)
		changes[index] = wire.ViewChange{
			Epoch:         1,
			Round:         1,
			NewView:       1,
			CommandDigest: digest,
			SenderID:      uint32(index),
			IdentitySig:   bytes.Repeat([]byte{0x88}, 64),
		}
	}

	certificateSize, err := encodedSize(wire.Certificate{
		Epoch:           1,
		Round:           1,
		View:            0,
		CommandDigest:   digest,
		SignerIDs:       signerIDs,
		ThresholdBLSSig: bytes.Repeat([]byte{0x99}, 48),
	})
	if err != nil {
		return MessageSizes{}, err
	}

	viewChangeSize, err := encodedSize(changes[0])
	if err != nil {
		return MessageSizes{}, err
	}

	timeoutSize, err := encodedSize(wire.TimeoutCertificate{
		Epoch:         1,
		Round:         1,
		NewView:       1,
		CommandDigest: digest,
		Changes:       changes,
	})
	if err != nil {
		return MessageSizes{}, err
	}

	return MessageSizes{
		Proposal:           proposalSize,
		Approval:           approvalSize,
		Certificate:        certificateSize,
		ViewChange:         viewChangeSize,
		TimeoutCertificate: timeoutSize,
	}, nil
}

type RoundResult struct {
	Success              bool
	Latency              time.Duration
	ViewsUsed            int
	RejectedMessages     uint64
	TimeoutCertificates  uint64
	CertificateReceivers uint64
}

type Result struct {
	Config               Config
	Sizes                MessageSizes
	Rounds               []RoundResult
	Successes            int
	SuccessRate          float64
	MeanLatency          time.Duration
	P95Latency           time.Duration
	MeanViews            float64
	RejectedMessages     uint64
	TimeoutCertificates  uint64
	CertificateReceivers uint64
	Network              transport.Statistics
}

type runner struct {
	config   Config
	sizes    MessageSizes
	network  *transport.Simulator
	sequence uint64
}

func Run(config Config) (Result, error) {
	if err := config.Validate(); err != nil {
		return Result{}, err
	}

	sizes, err := CalculateMessageSizes(
		config.PayloadBytes,
		config.Threshold,
	)
	if err != nil {
		return Result{}, fmt.Errorf("calculate message sizes: %w", err)
	}

	network, err := transport.NewSimulator(config.Network, config.Seed)
	if err != nil {
		return Result{}, err
	}

	runner := &runner{
		config:  config,
		sizes:   sizes,
		network: network,
	}

	result := Result{
		Config: config,
		Sizes:  sizes,
		Rounds: make([]RoundResult, 0, config.Rounds),
	}

	successfulLatencies := make([]time.Duration, 0, config.Rounds)
	var totalViews int

	for roundIndex := 0; roundIndex < config.Rounds; roundIndex++ {
		roundResult, err := runner.runRound(uint64(roundIndex + 1))
		if err != nil {
			return Result{}, fmt.Errorf(
				"round %d: %w",
				roundIndex+1,
				err,
			)
		}
		result.Rounds = append(result.Rounds, roundResult)
		totalViews += roundResult.ViewsUsed
		result.RejectedMessages += roundResult.RejectedMessages
		result.TimeoutCertificates += roundResult.TimeoutCertificates
		result.CertificateReceivers += roundResult.CertificateReceivers
		if roundResult.Success {
			result.Successes++
			successfulLatencies = append(
				successfulLatencies,
				roundResult.Latency,
			)
		}
	}

	result.SuccessRate = float64(result.Successes) /
		float64(config.Rounds)
	result.MeanViews = float64(totalViews) / float64(config.Rounds)
	result.MeanLatency = meanDuration(successfulLatencies)
	result.P95Latency = percentileDuration(successfulLatencies, 0.95)
	result.Network = network.Statistics()

	return result, nil
}

func (runner *runner) nextSequence() uint64 {
	runner.sequence++
	return runner.sequence
}

func (runner *runner) send(
	kind string,
	from uint32,
	to uint32,
	size int,
) ([]transport.Delivery, error) {
	return runner.network.Send(transport.Message{
		Sequence:  runner.nextSequence(),
		Kind:      kind,
		From:      from,
		To:        to,
		SizeBytes: size,
	})
}

func earliestDelivery(
	deliveries []transport.Delivery,
) (time.Duration, bool, int) {
	if len(deliveries) == 0 {
		return 0, false, 0
	}
	earliest := deliveries[0].Delay
	for _, delivery := range deliveries[1:] {
		if delivery.Delay < earliest {
			earliest = delivery.Delay
		}
	}
	return earliest, true, len(deliveries) - 1
}

func (runner *runner) runRound(round uint64) (RoundResult, error) {
	config := runner.config
	elapsed := time.Duration(0)
	result := RoundResult{}

	for view := uint64(0); view < uint64(config.MaxViews); view++ {
		result.ViewsUsed++
		leader := uint32((round + view) % uint64(config.NodeCount))
		scenario := config.Attack.ScenarioAt(view)
		leaderSilent := config.Attack.NodeSilent(leader)

		proposalArrival := make(map[uint32]time.Duration)
		ordinal := 0

		for node := 0; node < config.NodeCount; node++ {
			nodeID := uint32(node)

			if nodeID == leader {
				// A silent or malicious leader does not contribute a local
				// proposal/share in the faulty view.
				if !leaderSilent &&
					scenario != attack.LeaderCrash &&
					scenario != attack.ProposalWithholding &&
					scenario != attack.SelectiveProposal {
					proposalArrival[nodeID] = 0
				}
				continue
			}

			if leaderSilent {
				ordinal++
				continue
			}

			allowed := config.Attack.DeliverProposal(
				view,
				nodeID,
				ordinal,
				config.Threshold,
			)
			ordinal++
			if !allowed {
				continue
			}

			deliveries, err := runner.send(
				"proposal",
				leader,
				nodeID,
				runner.sizes.Proposal,
			)
			if err != nil {
				return result, err
			}
			delay, delivered, duplicates := earliestDelivery(deliveries)
			result.RejectedMessages += uint64(duplicates)
			if delivered {
				proposalArrival[nodeID] = delay
			}
		}

		type approvalArrival struct {
			signerID uint32
			arrival  time.Duration
		}
		approvals := make([]approvalArrival, 0, config.NodeCount)
		acceptedSoFar := 0
		mutatedOne := false

		nodeIDs := make([]int, 0, len(proposalArrival))
		for nodeID := range proposalArrival {
			nodeIDs = append(nodeIDs, int(nodeID))
		}
		sort.Ints(nodeIDs)

		for _, rawNodeID := range nodeIDs {
			signerID := uint32(rawNodeID)
			if !config.Attack.DeliverApproval(
				view,
				signerID,
				acceptedSoFar,
				config.Threshold,
			) {
				continue
			}

			// Forged/substituted approval attacks affect one malicious
			// follower and are rejected before threshold counting.
			if !mutatedOne && signerID != leader &&
				(scenario == attack.ForgedApproval ||
					scenario == attack.SignerSubstitution) {
				mutatedOne = true
				result.RejectedMessages++
				continue
			}

			if signerID == leader {
				approvals = append(approvals, approvalArrival{
					signerID: signerID,
					arrival:  proposalArrival[signerID],
				})
				acceptedSoFar++
				continue
			}

			deliveries, err := runner.send(
				"approval",
				signerID,
				leader,
				runner.sizes.Approval,
			)
			if err != nil {
				return result, err
			}
			delay, delivered, duplicates := earliestDelivery(deliveries)
			result.RejectedMessages += uint64(duplicates)
			if delivered {
				approvals = append(approvals, approvalArrival{
					signerID: signerID,
					arrival: proposalArrival[signerID] +
						delay,
				})
				acceptedSoFar++
			}
		}

		if len(approvals) >= config.Threshold {
			sort.Slice(approvals, func(left, right int) bool {
				if approvals[left].arrival == approvals[right].arrival {
					return approvals[left].signerID <
						approvals[right].signerID
				}
				return approvals[left].arrival < approvals[right].arrival
			})
			certificateReady := elapsed +
				approvals[config.Threshold-1].arrival +
				config.ReconstructDelay

			certificateArrivals := make([]time.Duration, 0, config.NodeCount)
			for node := 0; node < config.NodeCount; node++ {
				nodeID := uint32(node)
				if !config.Attack.DeliverCertificate(view, nodeID) {
					continue
				}

				if nodeID == leader {
					certificateArrivals = append(
						certificateArrivals,
						certificateReady+config.VerifyDelay,
					)
					continue
				}

				deliveries, err := runner.send(
					"certificate",
					leader,
					nodeID,
					runner.sizes.Certificate,
				)
				if err != nil {
					return result, err
				}
				delay, delivered, duplicates := earliestDelivery(deliveries)
				result.RejectedMessages += uint64(duplicates)
				if delivered {
					certificateArrivals = append(
						certificateArrivals,
						certificateReady+delay+config.VerifyDelay,
					)
				}
			}

			result.CertificateReceivers += uint64(len(certificateArrivals))
			if len(certificateArrivals) >= config.Threshold {
				sort.Slice(certificateArrivals, func(left, right int) bool {
					return certificateArrivals[left] <
						certificateArrivals[right]
				})
				result.Success = true
				result.Latency = certificateArrivals[config.Threshold-1]
				return result, nil
			}
		}

		// The current view failed. At the timeout, honest members send
		// authenticated view-change messages to the deterministic next leader.
		nextView := view + 1
		nextLeader := uint32(
			(round + nextView) % uint64(config.NodeCount),
		)
		collectorID := nextLeader
		if config.Attack.NodeSilent(collectorID) {
			foundCollector := false
			for candidate := 0; candidate < config.NodeCount; candidate++ {
				candidateID := uint32(candidate)
				if !config.Attack.NodeSilent(candidateID) {
					collectorID = candidateID
					foundCollector = true
					break
				}
			}
			if !foundCollector {
				result.Latency = elapsed + config.ViewTimeout
				return result, nil
			}
		}
		timeoutAt := elapsed + config.ViewTimeout
		viewChangeBySender := make(map[uint32]time.Duration)

		for retry := 0; retry < config.TimeoutRetries &&
			len(viewChangeBySender) < config.Threshold; retry++ {
			for node := 0; node < config.NodeCount; node++ {
				nodeID := uint32(node)
				if _, alreadyReceived := viewChangeBySender[nodeID]; alreadyReceived {
					continue
				}
				if config.Attack.NodeSilent(nodeID) {
					continue
				}
				if nodeID == leader &&
					(scenario == attack.LeaderCrash ||
						scenario == attack.ProposalWithholding ||
						scenario == attack.SelectiveProposal ||
						scenario == attack.ApprovalDropping ||
						scenario == attack.CertificateWithholding) {
					continue
				}

				if nodeID == collectorID {
					viewChangeBySender[nodeID] =
						time.Duration(retry) * time.Millisecond
					continue
				}

				deliveries, err := runner.send(
					"view_change",
					nodeID,
					collectorID,
					runner.sizes.ViewChange,
				)
				if err != nil {
					return result, err
				}
				delay, delivered, duplicates := earliestDelivery(deliveries)
				result.RejectedMessages += uint64(duplicates)
				if delivered {
					viewChangeBySender[nodeID] =
						time.Duration(retry)*time.Millisecond + delay
				}
			}
		}

		viewChangeArrivals := make(
			[]time.Duration,
			0,
			len(viewChangeBySender),
		)
		for _, arrival := range viewChangeBySender {
			viewChangeArrivals = append(viewChangeArrivals, arrival)
		}

		if len(viewChangeArrivals) < config.Threshold {
			result.Latency = timeoutAt
			return result, nil
		}

		sort.Slice(viewChangeArrivals, func(left, right int) bool {
			return viewChangeArrivals[left] < viewChangeArrivals[right]
		})
		certificateArrival := viewChangeArrivals[config.Threshold-1]
		result.TimeoutCertificates++

		// The next leader broadcasts the compact timeout certificate. The
		// application-byte cost is counted even though only the threshold
		// arrival is needed to enter the next view.
		timeoutCertificateArrivals := []time.Duration{0}
		for node := 0; node < config.NodeCount; node++ {
			nodeID := uint32(node)
			if nodeID == collectorID || config.Attack.NodeSilent(nodeID) {
				continue
			}
			deliveries, err := runner.send(
				"timeout_certificate",
				collectorID,
				nodeID,
				runner.sizes.TimeoutCertificate,
			)
			if err != nil {
				return result, err
			}
			delay, delivered, duplicates := earliestDelivery(deliveries)
			result.RejectedMessages += uint64(duplicates)
			if delivered {
				timeoutCertificateArrivals = append(
					timeoutCertificateArrivals,
					delay,
				)
			}
		}

		if len(timeoutCertificateArrivals) < config.Threshold {
			result.Latency = timeoutAt + certificateArrival
			return result, nil
		}
		sort.Slice(
			timeoutCertificateArrivals,
			func(left, right int) bool {
				return timeoutCertificateArrivals[left] <
					timeoutCertificateArrivals[right]
			},
		)
		elapsed = timeoutAt + certificateArrival +
			timeoutCertificateArrivals[config.Threshold-1]
	}

	result.Latency = elapsed
	return result, nil
}

func meanDuration(values []time.Duration) time.Duration {
	if len(values) == 0 {
		return 0
	}
	var total time.Duration
	for _, value := range values {
		total += value
	}
	return total / time.Duration(len(values))
}

func percentileDuration(
	values []time.Duration,
	percentile float64,
) time.Duration {
	if len(values) == 0 {
		return 0
	}
	copyValues := append([]time.Duration(nil), values...)
	sort.Slice(copyValues, func(left, right int) bool {
		return copyValues[left] < copyValues[right]
	})
	index := int(float64(len(copyValues)-1) * percentile)
	if index < 0 {
		index = 0
	}
	if index >= len(copyValues) {
		index = len(copyValues) - 1
	}
	return copyValues[index]
}
