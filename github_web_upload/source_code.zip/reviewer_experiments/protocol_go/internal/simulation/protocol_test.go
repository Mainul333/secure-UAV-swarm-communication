package simulation_test

import (
	"testing"
	"time"

	"uav-bft/internal/attack"
	"uav-bft/internal/simulation"
	"uav-bft/internal/transport"
)

func baseConfig() simulation.Config {
	config := simulation.DefaultConfig()
	config.Rounds = 20
	config.Network = transport.IdealProfile()
	config.ViewTimeout = 20 * time.Millisecond
	config.MaxViews = 4
	return config
}

func TestBenignProtocolSucceedsWithoutViewChange(t *testing.T) {
	config := baseConfig()
	config.Attack = attack.BenignPlan()

	result, err := simulation.Run(config)
	if err != nil {
		t.Fatalf("run simulation: %v", err)
	}
	if result.SuccessRate != 1 {
		t.Fatalf("success rate=%f; expected 1", result.SuccessRate)
	}
	if result.MeanViews != 1 {
		t.Fatalf("mean views=%f; expected 1", result.MeanViews)
	}
}

func TestWithholdingRecoversInReplacementView(t *testing.T) {
	for _, scenario := range []attack.Scenario{
		attack.ProposalWithholding,
		attack.SelectiveProposal,
		attack.ApprovalDropping,
		attack.CertificateWithholding,
	} {
		config := baseConfig()
		config.Attack = attack.NewPlan(scenario)

		result, err := simulation.Run(config)
		if err != nil {
			t.Fatalf("scenario %s: %v", scenario, err)
		}
		if result.SuccessRate != 1 {
			t.Fatalf(
				"scenario %s success=%f; expected 1",
				scenario,
				result.SuccessRate,
			)
		}
		if result.MeanViews < 2 {
			t.Fatalf(
				"scenario %s mean views=%f; expected >=2",
				scenario,
				result.MeanViews,
			)
		}
		if result.TimeoutCertificates == 0 {
			t.Fatalf("scenario %s produced no timeout certificate", scenario)
		}
	}
}

func TestAtMostFFollowerSilenceMaintainsLiveness(t *testing.T) {
	config := baseConfig()
	plan := attack.NewPlan(attack.FollowerSilence)
	plan.SilentNodes[3] = struct{}{}
	config.Attack = plan

	result, err := simulation.Run(config)
	if err != nil {
		t.Fatalf("run simulation: %v", err)
	}
	if result.SuccessRate != 1 {
		t.Fatalf("success rate=%f; expected 1", result.SuccessRate)
	}
}

func TestMoreThanFOfflineCanBreakLiveness(t *testing.T) {
	config := baseConfig()
	plan := attack.NewPlan(attack.FollowerSilence)
	plan.SilentNodes[2] = struct{}{}
	plan.SilentNodes[3] = struct{}{}
	config.Attack = plan

	result, err := simulation.Run(config)
	if err != nil {
		t.Fatalf("run simulation: %v", err)
	}
	if result.SuccessRate != 0 {
		t.Fatalf("success rate=%f; expected 0", result.SuccessRate)
	}
}

func TestForgedApprovalRejectedButRoundSucceeds(t *testing.T) {
	config := baseConfig()
	config.NodeCount = 7
	config.Threshold = 5
	config.Attack = attack.NewPlan(attack.ForgedApproval)

	result, err := simulation.Run(config)
	if err != nil {
		t.Fatalf("run simulation: %v", err)
	}
	if result.SuccessRate != 1 {
		t.Fatalf("success rate=%f; expected 1", result.SuccessRate)
	}
	if result.RejectedMessages == 0 {
		t.Fatal("forged approval was not counted as rejected")
	}
}
