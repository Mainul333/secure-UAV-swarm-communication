package simulation

import (
	"time"

	"uav-bft/internal/attack"
)

type signedArrival struct {
	id uint32
	at time.Duration
}

// selectSigners returns k members other than the leader. Members without
// verifiable evidence of misbehaviour are eligible; members that failed to
// answer earlier (the availability score) are used only when the others do
// not suffice. The order within each group is random.
func (runner *runner) selectSigners(leader uint32, k int) []uint32 {
	preferred := make([]uint32, 0, runner.config.NodeCount)
	fallback := make([]uint32, 0)
	for node := 0; node < runner.config.NodeCount; node++ {
		id := uint32(node)
		if id == leader || runner.evidence[id] {
			continue
		}
		if runner.suspected[id] {
			fallback = append(fallback, id)
		} else {
			preferred = append(preferred, id)
		}
	}
	runner.rng.Shuffle(len(preferred), func(i, j int) { preferred[i], preferred[j] = preferred[j], preferred[i] })
	runner.rng.Shuffle(len(fallback), func(i, j int) { fallback[i], fallback[j] = fallback[j], fallback[i] })
	candidates := append(preferred, fallback...)
	if len(candidates) < k {
		return nil
	}
	return candidates[:k]
}

// signerSetView runs one view with threshold Schnorr semantics and returns the
// arrival times of the t shares when a signing session succeeds, or nil.
func (runner *runner) signerSetView(
	view uint64,
	leader uint32,
	scenario attack.Scenario,
	result *RoundResult,
) ([]signedArrival, error) {
	config := runner.config
	t := config.Threshold
	retries := config.SignerRetries
	if retries < 0 {
		retries = 0
	}
	sessions := config.MaxSessions
	if sessions <= 0 {
		sessions = 1
	}
	gap := config.ViewTimeout / time.Duration(2*(retries+1))
	sessionWait := gap * time.Duration(retries+1)
	commitmentList := 68 * t // identifier and two 32-byte nonce commitments per signer

	selected := runner.selectSigners(leader, t-1)
	if selected == nil {
		return nil, nil
	}
	inSet := make(map[uint32]bool, len(selected))
	for _, id := range selected {
		inSet[id] = true
	}

	// The proposal reaches every member; members of the signer set also
	// receive the commitment list, which starts the signing session.
	proposalArrival := make(map[uint32]time.Duration)
	for node := 0; node < config.NodeCount; node++ {
		id := uint32(node)
		if id == leader {
			continue
		}
		size := runner.sizes.Proposal
		if inSet[id] {
			size += commitmentList
		}
		deliveries, err := runner.send("proposal", leader, id, size)
		if err != nil {
			return nil, err
		}
		delay, delivered, duplicates := earliestDelivery(deliveries)
		result.RejectedMessages += uint64(duplicates)
		if delivered {
			proposalArrival[id] = delay
		}
	}

	// In the forged-approval scenarios one malicious follower answers with an
	// invalid share; FROST identifies it, so it is excluded permanently.
	forger := uint32(config.NodeCount)
	if scenario == attack.ForgedApproval || scenario == attack.SignerSubstitution {
		for node := 0; node < config.NodeCount; node++ {
			if uint32(node) != leader {
				forger = uint32(node)
				break
			}
		}
		result.RejectedMessages++
	}

	start := time.Duration(0)
	for session := 0; session < sessions && start+sessionWait <= config.ViewTimeout; session++ {
		if session > 0 {
			selected = runner.selectSigners(leader, t-1)
			if selected == nil {
				return nil, nil
			}
		}
		arrivals := []signedArrival{{id: leader, at: start}}
		failed := make([]uint32, 0)
		for _, id := range selected {
			answered := false
			for attempt := 0; attempt <= retries && !answered; attempt++ {
				sendAt := start + time.Duration(attempt)*gap
				var requestDelay time.Duration
				if session == 0 && attempt == 0 {
					delay, ok := proposalArrival[id]
					if !ok {
						continue
					}
					requestDelay = delay
				} else {
					deliveries, err := runner.send("signing_request", leader, id, 32+commitmentList)
					if err != nil {
						return nil, err
					}
					delay, delivered, duplicates := earliestDelivery(deliveries)
					result.RejectedMessages += uint64(duplicates)
					if !delivered {
						continue
					}
					requestDelay = delay
				}
				if !config.Attack.DeliverApproval(view, id, len(arrivals), t) {
					break
				}
				if id == forger {
					runner.evidence[id] = true
					break
				}
				deliveries, err := runner.send("approval", id, leader, runner.sizes.Approval)
				if err != nil {
					return nil, err
				}
				delay, delivered, duplicates := earliestDelivery(deliveries)
				result.RejectedMessages += uint64(duplicates)
				if delivered {
					arrivals = append(arrivals, signedArrival{id: id, at: sendAt + requestDelay + delay})
					answered = true
				}
			}
			if !answered {
				failed = append(failed, id)
			}
		}
		if len(failed) == 0 {
			latest := time.Duration(0)
			for _, arrival := range arrivals {
				if arrival.at > latest {
					latest = arrival.at
				}
			}
			if latest <= config.ViewTimeout {
				return arrivals, nil
			}
			return nil, nil
		}
		for _, id := range failed {
			if !runner.evidence[id] {
				runner.suspected[id] = true
			}
		}
		start += sessionWait
	}
	return nil, nil
}
