package threshold_test

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"path/filepath"
	"testing"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

func testCommand(
	now time.Time,
	payload string,
	nonce string,
) wire.Command {
	return wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           25,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte(payload),
		Nonce:           []byte(nonce),
	}
}

func authorize(
	t *testing.T,
	privateKey []byte,
	baseStationID uint32,
	command wire.Command,
	now time.Time,
) wire.AuthorizedCommand {
	t.Helper()

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		baseStationID,
		command,
		now,
	)
	if err != nil {
		t.Fatalf("authorize command: %v", err)
	}

	return authorized
}

func TestRealPartialStoredAndReusedAcrossViews(t *testing.T) {
	const (
		nodeCount = 4
		threshold = 3
	)

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		t.Fatalf("run honest DKG: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate base-station key: %v", err)
	}

	now := time.Unix(1_700_000_000, 0).UTC()

	authorized := authorize(
		t,
		privateKey,
		1,
		testCommand(
			now,
			"MOVE:X=5,Y=5,Z=-5",
			"0123456789ABCDEF",
		),
		now,
	)

	store, err := storage.OpenVoteStore(
		filepath.Join(t.TempDir(), "node0.db"),
	)
	if err != nil {
		t.Fatalf("open vote store: %v", err)
	}
	defer store.Close()

	follower, err := thresholdprotocol.NewFollowerSigner(
		scheme,
		result.Shares[0].PriShare(),
		result.PublicPoly,
		store,
		publicKey,
	)
	if err != nil {
		t.Fatalf("create follower signer: %v", err)
	}

	first, err := follower.Approve(
		context.Background(),
		authorized,
		0,
		now,
	)
	if err != nil {
		t.Fatalf("first approval: %v", err)
	}

	if !first.Created {
		t.Fatal("first threshold partial was not marked as new")
	}

	if len(first.Approval.PartialBLSSig) != 50 {
		t.Fatalf(
			"partial-signature size=%d; expected 50",
			len(first.Approval.PartialBLSSig),
		)
	}

	second, err := follower.Approve(
		context.Background(),
		authorized,
		1,
		now,
	)
	if err != nil {
		t.Fatalf("reused approval: %v", err)
	}

	if second.Created {
		t.Fatal("same command created a second partial signature")
	}

	if second.Approval.View != 1 {
		t.Fatalf(
			"reused approval view=%d; expected 1",
			second.Approval.View,
		)
	}

	if !bytes.Equal(
		first.Approval.PartialBLSSig,
		second.Approval.PartialBLSSig,
	) {
		t.Fatal("stored partial changed across views")
	}
}

func TestConflictingAuthorizedCommandRejected(t *testing.T) {
	result, err := dkg.RunHonest(4, 3)
	if err != nil {
		t.Fatalf("run honest DKG: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate base-station key: %v", err)
	}

	now := time.Unix(1_700_000_000, 0).UTC()

	firstAuthorized := authorize(
		t,
		privateKey,
		1,
		testCommand(
			now,
			"MOVE:X=5,Y=5,Z=-5",
			"0123456789ABCDEF",
		),
		now,
	)

	secondAuthorized := authorize(
		t,
		privateKey,
		1,
		testCommand(
			now,
			"LAND",
			"FEDCBA9876543210",
		),
		now,
	)

	store, err := storage.OpenVoteStore(
		filepath.Join(t.TempDir(), "node0.db"),
	)
	if err != nil {
		t.Fatalf("open vote store: %v", err)
	}
	defer store.Close()

	follower, err := thresholdprotocol.NewFollowerSigner(
		scheme,
		result.Shares[0].PriShare(),
		result.PublicPoly,
		store,
		publicKey,
	)
	if err != nil {
		t.Fatalf("create follower signer: %v", err)
	}

	first, err := follower.Approve(
		context.Background(),
		firstAuthorized,
		0,
		now,
	)
	if err != nil {
		t.Fatalf("first approval: %v", err)
	}

	_, err = follower.Approve(
		context.Background(),
		secondAuthorized,
		1,
		now,
	)

	if !errors.Is(err, storage.ErrConflictingVote) {
		t.Fatalf(
			"expected conflicting-vote error, got %v",
			err,
		)
	}

	stored, err := store.GetVote(
		context.Background(),
		firstAuthorized.Command.Epoch,
		firstAuthorized.Command.Round,
	)
	if err != nil {
		t.Fatalf("read stored vote: %v", err)
	}

	if !bytes.Equal(
		stored.PartialSignature,
		first.Approval.PartialBLSSig,
	) {
		t.Fatal("conflicting request replaced stored partial")
	}
}

func TestInvalidBaseStationCommandCreatesNoVote(t *testing.T) {
	result, err := dkg.RunHonest(4, 3)
	if err != nil {
		t.Fatalf("run honest DKG: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate base-station key: %v", err)
	}

	now := time.Unix(1_700_000_000, 0).UTC()

	authorized := authorize(
		t,
		privateKey,
		1,
		testCommand(
			now,
			"MOVE:X=5,Y=5,Z=-5",
			"0123456789ABCDEF",
		),
		now,
	)

	authorized.Command.Payload = []byte("MALICIOUS-LAND")

	store, err := storage.OpenVoteStore(
		filepath.Join(t.TempDir(), "node0.db"),
	)
	if err != nil {
		t.Fatalf("open vote store: %v", err)
	}
	defer store.Close()

	follower, err := thresholdprotocol.NewFollowerSigner(
		scheme,
		result.Shares[0].PriShare(),
		result.PublicPoly,
		store,
		publicKey,
	)
	if err != nil {
		t.Fatalf("create follower signer: %v", err)
	}

	_, err = follower.Approve(
		context.Background(),
		authorized,
		0,
		now,
	)

	if err == nil {
		t.Fatal("tampered base-station command was accepted")
	}

	_, err = store.GetVote(
		context.Background(),
		authorized.Command.Epoch,
		authorized.Command.Round,
	)

	if !errors.Is(err, storage.ErrVoteNotFound) {
		t.Fatalf(
			"invalid command created a vote: %v",
			err,
		)
	}
}

func TestStoredPartialReusedAfterVoteStoreRestart(t *testing.T) {
	result, err := dkg.RunHonest(4, 3)
	if err != nil {
		t.Fatalf("run honest DKG: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate base-station key: %v", err)
	}

	now := time.Unix(1_700_000_000, 0).UTC()

	authorized := authorize(
		t,
		privateKey,
		1,
		testCommand(
			now,
			"MOVE:X=5,Y=5,Z=-5",
			"0123456789ABCDEF",
		),
		now,
	)

	path := filepath.Join(t.TempDir(), "persistent-node0.db")

	firstStore, err := storage.OpenVoteStore(path)
	if err != nil {
		t.Fatalf("open first vote store: %v", err)
	}

	firstFollower, err := thresholdprotocol.NewFollowerSigner(
		scheme,
		result.Shares[0].PriShare(),
		result.PublicPoly,
		firstStore,
		publicKey,
	)
	if err != nil {
		t.Fatalf("create first follower: %v", err)
	}

	first, err := firstFollower.Approve(
		context.Background(),
		authorized,
		0,
		now,
	)
	if err != nil {
		t.Fatalf("first approval: %v", err)
	}

	if err := firstStore.Close(); err != nil {
		t.Fatalf("close first vote store: %v", err)
	}

	secondStore, err := storage.OpenVoteStore(path)
	if err != nil {
		t.Fatalf("reopen vote store: %v", err)
	}
	defer secondStore.Close()

	secondFollower, err := thresholdprotocol.NewFollowerSigner(
		scheme,
		result.Shares[0].PriShare(),
		result.PublicPoly,
		secondStore,
		publicKey,
	)
	if err != nil {
		t.Fatalf("create restarted follower: %v", err)
	}

	second, err := secondFollower.Approve(
		context.Background(),
		authorized,
		1,
		now,
	)
	if err != nil {
		t.Fatalf("approval after restart: %v", err)
	}

	if second.Created {
		t.Fatal("restart created a second partial signature")
	}

	if !bytes.Equal(
		first.Approval.PartialBLSSig,
		second.Approval.PartialBLSSig,
	) {
		t.Fatal("restart did not recover the stored partial")
	}
}

func TestEndToEndThresholdCertificate(t *testing.T) {
	const (
		nodeCount = 4
		threshold = 3
	)

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		t.Fatalf("run honest DKG: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate base-station key: %v", err)
	}

	now := time.Unix(1_700_000_000, 0).UTC()

	authorized := authorize(
		t,
		privateKey,
		1,
		testCommand(
			now,
			"MOVE:X=5,Y=5,Z=-5",
			"0123456789ABCDEF",
		),
		now,
	)

	approvals := make([]wire.Approval, 0, threshold)

	for index := 0; index < threshold; index++ {
		store, err := storage.OpenVoteStore(
			filepath.Join(
				t.TempDir(),
				fmt.Sprintf("node%d.db", index),
			),
		)
		if err != nil {
			t.Fatalf("node %d open vote store: %v", index, err)
		}
		defer store.Close()

		follower, err := thresholdprotocol.NewFollowerSigner(
			scheme,
			result.Shares[index].PriShare(),
			result.PublicPoly,
			store,
			publicKey,
		)
		if err != nil {
			t.Fatalf(
				"node %d create follower: %v",
				index,
				err,
			)
		}

		approval, err := follower.Approve(
			context.Background(),
			authorized,
			0,
			now,
		)
		if err != nil {
			t.Fatalf(
				"node %d approve command: %v",
				index,
				err,
			)
		}

		approvals = append(
			approvals,
			approval.Approval,
		)
	}

	certificate, err := thresholdprotocol.RecoverCertificate(
		scheme,
		result.PublicPoly,
		result.PublicKey,
		authorized,
		0,
		approvals,
		uint32(threshold),
		uint32(nodeCount),
	)
	if err != nil {
		t.Fatalf("recover certificate: %v", err)
	}

	if len(certificate.ThresholdBLSSig) != 48 {
		t.Fatalf(
			"certificate size=%d; expected 48",
			len(certificate.ThresholdBLSSig),
		)
	}

	if len(certificate.SignerIDs) != threshold {
		t.Fatalf(
			"certificate signer count=%d; expected %d",
			len(certificate.SignerIDs),
			threshold,
		)
	}
}
