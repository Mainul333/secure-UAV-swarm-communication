package threshold

import (
	"bytes"
	"errors"
	"fmt"
	"sort"

	"go.dedis.ch/kyber/v4"
	"go.dedis.ch/kyber/v4/share"
	"go.dedis.ch/kyber/v4/sign"

	"uav-bft/internal/wire"
)

var (
	ErrInvalidThresholdParameters = errors.New(
		"invalid threshold parameters",
	)
	ErrInsufficientApprovals = errors.New(
		"insufficient unique approvals",
	)
	ErrApprovalCommandMismatch = errors.New(
		"approval does not match authorized command",
	)
	ErrDuplicateSigner = errors.New(
		"duplicate approval signer",
	)
	ErrApprovalIndexMismatch = errors.New(
		"approval signer ID does not match partial-signature index",
	)
	ErrInvalidPartialSignature = errors.New(
		"invalid threshold partial signature",
	)
	ErrRecoveredSignatureInvalid = errors.New(
		"recovered threshold signature is invalid",
	)
)

type verifiedApproval struct {
	signerID uint32
	partial  []byte
}

// RecoverCertificate verifies the approvals, selects a deterministic
// threshold subset, reconstructs the full BLS signature, and verifies it.
func RecoverCertificate(
	scheme sign.ThresholdScheme,
	publicPolynomial *share.PubPoly,
	groupPublicKey kyber.Point,
	authorized wire.AuthorizedCommand,
	view uint64,
	approvals []wire.Approval,
	threshold uint32,
	nodeCount uint32,
) (wire.Certificate, error) {
	if scheme == nil ||
		publicPolynomial == nil ||
		groupPublicKey == nil ||
		threshold == 0 ||
		nodeCount == 0 ||
		threshold > nodeCount {
		return wire.Certificate{}, ErrInvalidThresholdParameters
	}

	digest, err := wire.CertificateDigest(authorized)
	if err != nil {
		return wire.Certificate{}, fmt.Errorf(
			"calculate certificate digest: %w",
			err,
		)
	}

	unique := make(map[uint32]struct{})
	verified := make([]verifiedApproval, 0, len(approvals))

	for _, approval := range approvals {
		if approval.Epoch != authorized.Command.Epoch ||
			approval.Round != authorized.Command.Round ||
			!bytes.Equal(approval.CommandDigest, digest[:]) {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d",
				ErrApprovalCommandMismatch,
				approval.SignerID,
			)
		}

		if approval.SignerID >= nodeCount {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d n=%d",
				ErrApprovalIndexMismatch,
				approval.SignerID,
				nodeCount,
			)
		}

		if _, exists := unique[approval.SignerID]; exists {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d",
				ErrDuplicateSigner,
				approval.SignerID,
			)
		}

		partialIndex, err := scheme.IndexOf(
			approval.PartialBLSSig,
		)
		if err != nil {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d: %v",
				ErrInvalidPartialSignature,
				approval.SignerID,
				err,
			)
		}

		if partialIndex < 0 ||
			uint32(partialIndex) != approval.SignerID {
			return wire.Certificate{}, fmt.Errorf(
				"%w: claimed=%d encoded=%d",
				ErrApprovalIndexMismatch,
				approval.SignerID,
				partialIndex,
			)
		}

		if err := scheme.VerifyPartial(
			publicPolynomial,
			digest[:],
			approval.PartialBLSSig,
		); err != nil {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d: %v",
				ErrInvalidPartialSignature,
				approval.SignerID,
				err,
			)
		}

		unique[approval.SignerID] = struct{}{}

		verified = append(verified, verifiedApproval{
			signerID: approval.SignerID,
			partial: append(
				[]byte(nil),
				approval.PartialBLSSig...,
			),
		})
	}

	if len(verified) < int(threshold) {
		return wire.Certificate{}, fmt.Errorf(
			"%w: received=%d required=%d",
			ErrInsufficientApprovals,
			len(verified),
			threshold,
		)
	}

	// Canonical signer ordering makes the chosen threshold subset
	// deterministic across honest leaders.
	sort.Slice(
		verified,
		func(left, right int) bool {
			return verified[left].signerID <
				verified[right].signerID
		},
	)

	selected := verified[:int(threshold)]

	partials := make([][]byte, 0, threshold)
	signerIDs := make([]uint32, 0, threshold)

	for _, approval := range selected {
		partials = append(partials, approval.partial)
		signerIDs = append(signerIDs, approval.signerID)
	}

	recovered, err := scheme.Recover(
		publicPolynomial,
		digest[:],
		partials,
		threshold,
		nodeCount,
	)
	if err != nil {
		return wire.Certificate{}, fmt.Errorf(
			"recover threshold certificate: %w",
			err,
		)
	}

	if err := scheme.VerifyRecovered(
		groupPublicKey,
		digest[:],
		recovered,
	); err != nil {
		return wire.Certificate{}, fmt.Errorf(
			"%w: %v",
			ErrRecoveredSignatureInvalid,
			err,
		)
	}

	return wire.Certificate{
		Epoch:           authorized.Command.Epoch,
		Round:           authorized.Command.Round,
		View:            view,
		CommandDigest:   append([]byte(nil), digest[:]...),
		SignerIDs:       signerIDs,
		ThresholdBLSSig: append([]byte(nil), recovered...),
	}, nil
}
