package threshold

import (
	"context"
	"crypto/ed25519"
	"errors"
	"fmt"
	"time"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

var ErrNilFollowerSigner = errors.New(
	"follower signer is nil",
)

// AuthenticatedFollowerSigner adds a UAV identity signature to every
// real threshold-BLS approval.
type AuthenticatedFollowerSigner struct {
	follower           *FollowerSigner
	identityPrivateKey ed25519.PrivateKey
	identityPublicKey  ed25519.PublicKey
}

// NewAuthenticatedFollowerSigner creates an identity-authenticated
// threshold signer.
func NewAuthenticatedFollowerSigner(
	follower *FollowerSigner,
	identityPrivateKey ed25519.PrivateKey,
) (*AuthenticatedFollowerSigner, error) {
	if follower == nil {
		return nil, ErrNilFollowerSigner
	}

	if len(identityPrivateKey) != ed25519.PrivateKeySize {
		return nil, identity.ErrInvalidPrivateKey
	}

	publicKeyValue := identityPrivateKey.Public()

	publicKey, ok := publicKeyValue.(ed25519.PublicKey)
	if !ok {
		return nil, identity.ErrInvalidPublicKey
	}

	return &AuthenticatedFollowerSigner{
		follower: follower,
		identityPrivateKey: append(
			ed25519.PrivateKey(nil),
			identityPrivateKey...,
		),
		identityPublicKey: append(
			ed25519.PublicKey(nil),
			publicKey...,
		),
	}, nil
}

// SignerID returns the DKG participant index.
func (a *AuthenticatedFollowerSigner) SignerID() uint32 {
	return a.follower.SignerID()
}

// IdentityPublicKey returns a defensive copy of the UAV identity key.
func (a *AuthenticatedFollowerSigner) IdentityPublicKey() ed25519.PublicKey {
	return append(
		ed25519.PublicKey(nil),
		a.identityPublicKey...,
	)
}

// Approve creates or reuses the persistent BLS partial and then signs
// the complete approval envelope for the requested view.
func (a *AuthenticatedFollowerSigner) Approve(
	ctx context.Context,
	authorized wire.AuthorizedCommand,
	view uint64,
	now time.Time,
) (ApprovalResult, error) {
	result, err := a.follower.Approve(
		ctx,
		authorized,
		view,
		now,
	)
	if err != nil {
		return ApprovalResult{}, err
	}

	signature, err := identity.SignApprovalEnvelope(
		a.identityPrivateKey,
		result.Approval,
	)
	if err != nil {
		return ApprovalResult{}, fmt.Errorf(
			"sign approval envelope: %w",
			err,
		)
	}

	result.Approval.IdentitySig = signature

	return result, nil
}
