package threshold

import (
	"crypto/ed25519"
	"errors"
	"fmt"

	"go.dedis.ch/kyber/v4"
	"go.dedis.ch/kyber/v4/share"
	"go.dedis.ch/kyber/v4/sign"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

var (
	ErrMissingApprovalIdentityKey = errors.New(
		"missing registered identity key for approval signer",
	)
	ErrApprovalViewMismatch = errors.New(
		"approval view does not match certificate view",
	)
	ErrAuthenticatedApprovalRejected = errors.New(
		"authenticated approval rejected",
	)
)

// RecoverAuthenticatedCertificate first verifies each UAV identity
// envelope. Only then does it verify BLS partial signatures and recover
// the threshold certificate.
func RecoverAuthenticatedCertificate(
	scheme sign.ThresholdScheme,
	publicPolynomial *share.PubPoly,
	groupPublicKey kyber.Point,
	authorized wire.AuthorizedCommand,
	view uint64,
	approvals []wire.Approval,
	identityPublicKeys map[uint32]ed25519.PublicKey,
	threshold uint32,
	nodeCount uint32,
) (wire.Certificate, error) {
	for _, approval := range approvals {
		if approval.View != view {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d approval=%d expected=%d",
				ErrApprovalViewMismatch,
				approval.SignerID,
				approval.View,
				view,
			)
		}

		if approval.SignerID >= nodeCount {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer ID %d outside membership size %d",
				ErrAuthenticatedApprovalRejected,
				approval.SignerID,
				nodeCount,
			)
		}

		publicKey, exists := identityPublicKeys[approval.SignerID]
		if !exists {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d",
				ErrMissingApprovalIdentityKey,
				approval.SignerID,
			)
		}

		if err := identity.VerifyApprovalEnvelope(
			publicKey,
			approval,
		); err != nil {
			return wire.Certificate{}, fmt.Errorf(
				"%w: signer=%d: %v",
				ErrAuthenticatedApprovalRejected,
				approval.SignerID,
				err,
			)
		}
	}

	return RecoverCertificate(
		scheme,
		publicPolynomial,
		groupPublicKey,
		authorized,
		view,
		approvals,
		threshold,
		nodeCount,
	)
}
