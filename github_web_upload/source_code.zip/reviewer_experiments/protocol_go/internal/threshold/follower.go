package threshold

import (
	"context"
	"crypto/ed25519"
	"errors"
	"fmt"
	"time"

	"go.dedis.ch/kyber/v4/share"
	"go.dedis.ch/kyber/v4/sign"

	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	"uav-bft/internal/wire"
)

var (
	ErrNilThresholdScheme   = errors.New("threshold scheme is nil")
	ErrNilPrivateShare      = errors.New("private DKG share is nil")
	ErrNilPublicPolynomial  = errors.New("public polynomial is nil")
	ErrNilVoteStore         = errors.New("vote store is nil")
	ErrPrivateShareMismatch = errors.New(
		"private DKG share does not match public polynomial",
	)
	ErrPartialSignerIndex = errors.New(
		"partial-signature index does not match follower index",
	)
	ErrStoredPartialInvalid = errors.New(
		"stored threshold partial signature is invalid",
	)
)

// ApprovalResult reports whether the follower created a new partial
// signature or reused its persistent vote from an earlier request/view.
type ApprovalResult struct {
	Approval wire.Approval
	Created  bool
}

// FollowerSigner verifies base-station authorization, enforces one vote,
// and creates real threshold-BLS partial signatures.
type FollowerSigner struct {
	scheme               sign.ThresholdScheme
	privateShare         *share.PriShare
	publicPolynomial     *share.PubPoly
	voteStore            *storage.VoteStore
	baseStationPublicKey ed25519.PublicKey
}

// NewFollowerSigner constructs a follower signer.
//
// The DKG share is checked against the public commitment polynomial before
// it is allowed to generate any threshold signature.
func NewFollowerSigner(
	scheme sign.ThresholdScheme,
	privateShare *share.PriShare,
	publicPolynomial *share.PubPoly,
	voteStore *storage.VoteStore,
	baseStationPublicKey ed25519.PublicKey,
) (*FollowerSigner, error) {
	if scheme == nil {
		return nil, ErrNilThresholdScheme
	}

	if privateShare == nil || privateShare.V == nil {
		return nil, ErrNilPrivateShare
	}

	if publicPolynomial == nil {
		return nil, ErrNilPublicPolynomial
	}

	if voteStore == nil {
		return nil, ErrNilVoteStore
	}

	if len(baseStationPublicKey) != ed25519.PublicKeySize {
		return nil, identity.ErrInvalidPublicKey
	}

	if !publicPolynomial.Check(privateShare) {
		return nil, ErrPrivateShareMismatch
	}

	return &FollowerSigner{
		scheme:           scheme,
		privateShare:     privateShare,
		publicPolynomial: publicPolynomial,
		voteStore:        voteStore,
		baseStationPublicKey: append(
			ed25519.PublicKey(nil),
			baseStationPublicKey...,
		),
	}, nil
}

// SignerID returns the DKG participant index.
func (f *FollowerSigner) SignerID() uint32 {
	return f.privateShare.I
}

// Approve verifies an authorized command and returns exactly one persistent
// threshold-BLS partial signature for its epoch and round.
//
// The BLS partial signs CertificateDigest, which includes the command,
// epoch, round, payload, nonce, base-station ID, and BS authorization.
// View is intentionally outside the BLS digest so the same stored partial
// may be resent to a replacement leader in a later view.
func (f *FollowerSigner) Approve(
	ctx context.Context,
	authorized wire.AuthorizedCommand,
	view uint64,
	now time.Time,
) (ApprovalResult, error) {
	if err := identity.VerifyAuthorizedCommand(
		f.baseStationPublicKey,
		authorized,
		now,
	); err != nil {
		return ApprovalResult{}, fmt.Errorf(
			"verify base-station authorization: %w",
			err,
		)
	}

	digest, err := wire.CertificateDigest(authorized)
	if err != nil {
		return ApprovalResult{}, fmt.Errorf(
			"calculate certificate digest: %w",
			err,
		)
	}

	voteResult, err := f.voteStore.GetOrCreateVote(
		ctx,
		authorized.Command.Epoch,
		authorized.Command.Round,
		digest[:],
		func() ([]byte, error) {
			partial, err := f.scheme.Sign(
				f.privateShare,
				digest[:],
			)
			if err != nil {
				return nil, fmt.Errorf(
					"threshold-BLS partial signing: %w",
					err,
				)
			}

			if err := f.scheme.VerifyPartial(
				f.publicPolynomial,
				digest[:],
				partial,
			); err != nil {
				return nil, fmt.Errorf(
					"self-verify threshold partial: %w",
					err,
				)
			}

			return partial, nil
		},
	)
	if err != nil {
		return ApprovalResult{}, err
	}

	// Verify both newly generated and persisted partial signatures.
	if err := f.scheme.VerifyPartial(
		f.publicPolynomial,
		digest[:],
		voteResult.Vote.PartialSignature,
	); err != nil {
		return ApprovalResult{}, fmt.Errorf(
			"%w: %v",
			ErrStoredPartialInvalid,
			err,
		)
	}

	partialIndex, err := f.scheme.IndexOf(
		voteResult.Vote.PartialSignature,
	)
	if err != nil {
		return ApprovalResult{}, fmt.Errorf(
			"decode threshold partial index: %w",
			err,
		)
	}

	if partialIndex < 0 ||
		uint32(partialIndex) != f.privateShare.I {
		return ApprovalResult{}, fmt.Errorf(
			"%w: partial=%d follower=%d",
			ErrPartialSignerIndex,
			partialIndex,
			f.privateShare.I,
		)
	}

	return ApprovalResult{
		Approval: wire.Approval{
			Epoch:         authorized.Command.Epoch,
			Round:         authorized.Command.Round,
			View:          view,
			CommandDigest: append([]byte(nil), digest[:]...),
			SignerID:      f.privateShare.I,
			PartialBLSSig: append(
				[]byte(nil),
				voteResult.Vote.PartialSignature...,
			),

			// The Ed25519 approval-envelope signature is added in the
			// next milestone.
			IdentitySig: nil,
		},
		Created: voteResult.Created,
	}, nil
}
