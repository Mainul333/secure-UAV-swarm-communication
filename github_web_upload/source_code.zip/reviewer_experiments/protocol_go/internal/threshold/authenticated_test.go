package threshold_test

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"errors"
	"fmt"
	"path/filepath"
	"testing"
	"time"

	"go.dedis.ch/kyber/v4/sign"
	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

type authenticatedFixture struct {
	nodeCount int
	threshold int
	now       time.Time

	dkgResult *dkg.Result
	scheme    sign.ThresholdScheme

	authorized wire.AuthorizedCommand

	signers  []*thresholdprotocol.AuthenticatedFollowerSigner
	registry map[uint32]ed25519.PublicKey
}

func newAuthenticatedFixture(
	t *testing.T,
) *authenticatedFixture {
	t.Helper()

	const (
		nodeCount = 4
		threshold = 3
	)

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		t.Fatalf("run GJKR: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	_, baseStationPrivateKey, err :=
		identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate base-station key: %v", err)
	}

	baseStationPublicValue :=
		baseStationPrivateKey.Public()

	baseStationPublicKey, ok :=
		baseStationPublicValue.(ed25519.PublicKey)
	if !ok {
		t.Fatal("invalid base-station public-key type")
	}

	now := time.Unix(1_700_000_000, 0).UTC()

	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           40,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte("MOVE:X=5,Y=5,Z=-5"),
		Nonce:           []byte("0123456789ABCDEF"),
	}

	authorized, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		command,
		now,
	)
	if err != nil {
		t.Fatalf("authorize command: %v", err)
	}

	signers := make(
		[]*thresholdprotocol.AuthenticatedFollowerSigner,
		threshold,
	)

	registry := make(
		map[uint32]ed25519.PublicKey,
		threshold,
	)

	for index := 0; index < threshold; index++ {
		store, err := storage.OpenVoteStore(
			filepath.Join(
				t.TempDir(),
				fmt.Sprintf("node%d.db", index),
			),
		)
		if err != nil {
			t.Fatalf(
				"node %d open vote store: %v",
				index,
				err,
			)
		}

		t.Cleanup(func() {
			_ = store.Close()
		})

		follower, err :=
			thresholdprotocol.NewFollowerSigner(
				scheme,
				result.Shares[index].PriShare(),
				result.PublicPoly,
				store,
				baseStationPublicKey,
			)
		if err != nil {
			t.Fatalf(
				"node %d create follower: %v",
				index,
				err,
			)
		}

		publicKey, privateKey, err :=
			identity.GenerateKeyPair()
		if err != nil {
			t.Fatalf(
				"node %d generate identity: %v",
				index,
				err,
			)
		}

		authenticatedSigner, err :=
			thresholdprotocol.
				NewAuthenticatedFollowerSigner(
					follower,
					privateKey,
				)
		if err != nil {
			t.Fatalf(
				"node %d wrap follower: %v",
				index,
				err,
			)
		}

		signerID := authenticatedSigner.SignerID()

		if signerID != uint32(index) {
			t.Fatalf(
				"node %d has signer ID %d",
				index,
				signerID,
			)
		}

		signers[index] = authenticatedSigner
		registry[signerID] = publicKey
	}

	return &authenticatedFixture{
		nodeCount:  nodeCount,
		threshold:  threshold,
		now:        now,
		dkgResult:  result,
		scheme:     scheme,
		authorized: authorized,
		signers:    signers,
		registry:   registry,
	}
}

func approvalsForView(
	t *testing.T,
	fixture *authenticatedFixture,
	view uint64,
) []wire.Approval {
	t.Helper()

	approvals := make(
		[]wire.Approval,
		0,
		fixture.threshold,
	)

	for index, signer := range fixture.signers {
		result, err := signer.Approve(
			context.Background(),
			fixture.authorized,
			view,
			fixture.now,
		)
		if err != nil {
			t.Fatalf(
				"node %d approve view %d: %v",
				index,
				view,
				err,
			)
		}

		approvals = append(
			approvals,
			result.Approval,
		)
	}

	return approvals
}

func recoverAuthenticated(
	fixture *authenticatedFixture,
	view uint64,
	approvals []wire.Approval,
) (wire.Certificate, error) {
	return thresholdprotocol.
		RecoverAuthenticatedCertificate(
			fixture.scheme,
			fixture.dkgResult.PublicPoly,
			fixture.dkgResult.PublicKey,
			fixture.authorized,
			view,
			approvals,
			fixture.registry,
			uint32(fixture.threshold),
			uint32(fixture.nodeCount),
		)
}

func TestAuthenticatedApprovalsRecoverCertificate(
	t *testing.T,
) {
	fixture := newAuthenticatedFixture(t)
	approvals := approvalsForView(t, fixture, 0)

	certificate, err := recoverAuthenticated(
		fixture,
		0,
		approvals,
	)
	if err != nil {
		t.Fatalf("recover authenticated certificate: %v", err)
	}

	if len(certificate.ThresholdBLSSig) != 48 {
		t.Fatalf(
			"certificate size=%d; expected 48",
			len(certificate.ThresholdBLSSig),
		)
	}
}

func TestTamperedPartialRejectedByIdentityEnvelope(
	t *testing.T,
) {
	fixture := newAuthenticatedFixture(t)
	approvals := approvalsForView(t, fixture, 0)

	approvals[0].PartialBLSSig[10] ^= 0x01

	_, err := recoverAuthenticated(
		fixture,
		0,
		approvals,
	)

	if !errors.Is(
		err,
		thresholdprotocol.ErrAuthenticatedApprovalRejected,
	) {
		t.Fatalf(
			"expected authenticated-approval rejection, got %v",
			err,
		)
	}
}

func TestSignerIDSubstitutionRejected(t *testing.T) {
	fixture := newAuthenticatedFixture(t)
	approvals := approvalsForView(t, fixture, 0)

	approvals[0].SignerID = approvals[1].SignerID

	_, err := recoverAuthenticated(
		fixture,
		0,
		approvals,
	)

	if !errors.Is(
		err,
		thresholdprotocol.ErrAuthenticatedApprovalRejected,
	) {
		t.Fatalf(
			"expected signer-substitution rejection, got %v",
			err,
		)
	}
}

func TestWrongFollowerIdentityRejected(t *testing.T) {
	fixture := newAuthenticatedFixture(t)
	approvals := approvalsForView(t, fixture, 0)

	_, wrongPrivateKey, err :=
		identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate wrong identity: %v", err)
	}

	approvals[0].IdentitySig, err =
		identity.SignApprovalEnvelope(
			wrongPrivateKey,
			approvals[0],
		)
	if err != nil {
		t.Fatalf("create forged approval envelope: %v", err)
	}

	_, err = recoverAuthenticated(
		fixture,
		0,
		approvals,
	)

	if !errors.Is(
		err,
		thresholdprotocol.ErrAuthenticatedApprovalRejected,
	) {
		t.Fatalf(
			"expected wrong-identity rejection, got %v",
			err,
		)
	}
}

func TestOldViewEnvelopeRejected(t *testing.T) {
	fixture := newAuthenticatedFixture(t)
	viewZero := approvalsForView(t, fixture, 0)

	_, err := recoverAuthenticated(
		fixture,
		1,
		viewZero,
	)

	if !errors.Is(
		err,
		thresholdprotocol.ErrApprovalViewMismatch,
	) {
		t.Fatalf(
			"expected view-mismatch rejection, got %v",
			err,
		)
	}
}

func TestStoredPartialReauthenticatedForNewView(
	t *testing.T,
) {
	fixture := newAuthenticatedFixture(t)

	viewZero := approvalsForView(t, fixture, 0)
	viewOne := approvalsForView(t, fixture, 1)

	for index := range viewZero {
		if !bytes.Equal(
			viewZero[index].PartialBLSSig,
			viewOne[index].PartialBLSSig,
		) {
			t.Fatalf(
				"node %d changed stored BLS partial",
				index,
			)
		}

		if bytes.Equal(
			viewZero[index].IdentitySig,
			viewOne[index].IdentitySig,
		) {
			t.Fatalf(
				"node %d reused old-view identity envelope",
				index,
			)
		}
	}

	certificate, err := recoverAuthenticated(
		fixture,
		1,
		viewOne,
	)
	if err != nil {
		t.Fatalf(
			"recover replacement-view certificate: %v",
			err,
		)
	}

	if certificate.View != 1 {
		t.Fatalf(
			"certificate view=%d; expected 1",
			certificate.View,
		)
	}
}
