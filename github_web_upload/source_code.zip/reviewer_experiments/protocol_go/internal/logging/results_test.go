package logging_test

import (
	"encoding/csv"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	experimentlog "uav-bft/internal/logging"
)

func TestResultWriters(t *testing.T) {
	row := experimentlog.ProtocolResult{
		NodeCount:        4,
		FaultBound:       1,
		Threshold:        3,
		Profile:          "ideal",
		Scenario:         "benign",
		Seed:             1,
		Rounds:           10,
		Successes:        10,
		SuccessRate:      1,
		MeanLatencyMS:    4.2,
		LogicalMessages:  100,
		ApplicationBytes: 5000,
		Model:            "deterministic-go",
	}

	csvPath := filepath.Join(t.TempDir(), "results.csv")
	if err := experimentlog.WriteProtocolCSV(
		csvPath,
		[]experimentlog.ProtocolResult{row},
	); err != nil {
		t.Fatalf("write CSV: %v", err)
	}

	file, err := os.Open(csvPath)
	if err != nil {
		t.Fatalf("open CSV: %v", err)
	}
	records, err := csv.NewReader(file).ReadAll()
	_ = file.Close()
	if err != nil {
		t.Fatalf("read CSV: %v", err)
	}
	if len(records) != 2 {
		t.Fatalf("CSV rows=%d; expected 2", len(records))
	}

	jsonPath := filepath.Join(t.TempDir(), "results.json")
	if err := experimentlog.WriteJSON(
		jsonPath,
		[]experimentlog.ProtocolResult{row},
	); err != nil {
		t.Fatalf("write JSON: %v", err)
	}
	encoded, err := os.ReadFile(jsonPath)
	if err != nil {
		t.Fatalf("read JSON: %v", err)
	}
	var decoded []experimentlog.ProtocolResult
	if err := json.Unmarshal(encoded, &decoded); err != nil {
		t.Fatalf("decode JSON: %v", err)
	}
	if len(decoded) != 1 || decoded[0].NodeCount != 4 {
		t.Fatalf("unexpected JSON: %+v", decoded)
	}
}
