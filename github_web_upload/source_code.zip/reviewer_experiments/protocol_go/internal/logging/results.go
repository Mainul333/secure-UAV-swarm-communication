package logging

import (
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
)

var ErrEmptyOutputPath = errors.New("output path is empty")

// ProtocolResult is one aggregate experiment row. The model field prevents
// application-layer simulations from being confused with ns-3 or PX4 data.
type ProtocolResult struct {
	NodeCount            int     `json:"n"`
	FaultBound           int     `json:"f"`
	Threshold            int     `json:"t"`
	Profile              string  `json:"profile"`
	Scenario             string  `json:"scenario"`
	Seed                 int64   `json:"seed"`
	Rounds               int     `json:"rounds"`
	Successes            int     `json:"successes"`
	SuccessRate          float64 `json:"success_rate"`
	MeanLatencyMS        float64 `json:"mean_latency_ms"`
	P95LatencyMS         float64 `json:"p95_latency_ms"`
	MeanViews            float64 `json:"mean_views"`
	LogicalMessages      uint64  `json:"logical_messages"`
	ApplicationBytes     uint64  `json:"application_bytes"`
	DroppedMessages      uint64  `json:"dropped_messages"`
	DuplicateMessages    uint64  `json:"duplicate_messages"`
	ReorderedMessages    uint64  `json:"reordered_messages"`
	RejectedMessages     uint64  `json:"rejected_messages"`
	TimeoutCertificates  uint64  `json:"timeout_certificates"`
	CertificateReceivers uint64  `json:"certificate_receivers"`
	Model                string  `json:"model"`
}

func ensureParent(path string) error {
	if path == "" {
		return ErrEmptyOutputPath
	}
	return os.MkdirAll(filepath.Dir(path), 0o755)
}

func atomicWrite(
	path string,
	write func(*os.File) error,
) error {
	if err := ensureParent(path); err != nil {
		return err
	}

	temporary, err := os.CreateTemp(
		filepath.Dir(path),
		".uav-bft-result-*",
	)
	if err != nil {
		return fmt.Errorf("create temporary result file: %w", err)
	}
	temporaryPath := temporary.Name()

	cleanup := func() {
		_ = temporary.Close()
		_ = os.Remove(temporaryPath)
	}

	if err := write(temporary); err != nil {
		cleanup()
		return err
	}
	if err := temporary.Sync(); err != nil {
		cleanup()
		return fmt.Errorf("sync result file: %w", err)
	}
	if err := temporary.Close(); err != nil {
		_ = os.Remove(temporaryPath)
		return fmt.Errorf("close result file: %w", err)
	}
	if err := os.Rename(temporaryPath, path); err != nil {
		_ = os.Remove(temporaryPath)
		return fmt.Errorf("replace result file: %w", err)
	}
	return nil
}

func WriteProtocolCSV(
	path string,
	rows []ProtocolResult,
) error {
	return atomicWrite(path, func(file *os.File) error {
		writer := csv.NewWriter(file)
		header := []string{
			"n", "f", "t", "profile", "scenario", "seed",
			"rounds", "successes", "success_rate",
			"mean_latency_ms", "p95_latency_ms", "mean_views",
			"logical_messages", "application_bytes",
			"dropped_messages", "duplicate_messages",
			"reordered_messages", "rejected_messages",
			"timeout_certificates", "certificate_receivers", "model",
		}
		if err := writer.Write(header); err != nil {
			return fmt.Errorf("write CSV header: %w", err)
		}

		for _, row := range rows {
			record := []string{
				strconv.Itoa(row.NodeCount),
				strconv.Itoa(row.FaultBound),
				strconv.Itoa(row.Threshold),
				row.Profile,
				row.Scenario,
				strconv.FormatInt(row.Seed, 10),
				strconv.Itoa(row.Rounds),
				strconv.Itoa(row.Successes),
				strconv.FormatFloat(row.SuccessRate, 'f', 6, 64),
				strconv.FormatFloat(row.MeanLatencyMS, 'f', 6, 64),
				strconv.FormatFloat(row.P95LatencyMS, 'f', 6, 64),
				strconv.FormatFloat(row.MeanViews, 'f', 6, 64),
				strconv.FormatUint(row.LogicalMessages, 10),
				strconv.FormatUint(row.ApplicationBytes, 10),
				strconv.FormatUint(row.DroppedMessages, 10),
				strconv.FormatUint(row.DuplicateMessages, 10),
				strconv.FormatUint(row.ReorderedMessages, 10),
				strconv.FormatUint(row.RejectedMessages, 10),
				strconv.FormatUint(row.TimeoutCertificates, 10),
				strconv.FormatUint(row.CertificateReceivers, 10),
				row.Model,
			}
			if err := writer.Write(record); err != nil {
				return fmt.Errorf("write CSV row: %w", err)
			}
		}

		writer.Flush()
		if err := writer.Error(); err != nil {
			return fmt.Errorf("flush CSV: %w", err)
		}
		return nil
	})
}

func WriteJSON(path string, value any) error {
	return atomicWrite(path, func(file *os.File) error {
		encoder := json.NewEncoder(file)
		encoder.SetIndent("", "  ")
		if err := encoder.Encode(value); err != nil {
			return fmt.Errorf("encode JSON result: %w", err)
		}
		return nil
	})
}
