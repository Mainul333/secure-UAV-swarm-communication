package trust

import (
	"errors"
	"fmt"
	"slices"
	"sync"
)

var (
	ErrInvalidTrustConfig = errors.New("invalid trust configuration")
	ErrUnknownTrustNode   = errors.New("unknown trust node")
)

type Config struct {
	InitialAlpha  float64
	InitialBeta   float64
	SuccessWeight float64
	FailureWeight float64
	Decay         float64
	MinimumScore  float64
}

func DefaultConfig() Config {
	return Config{
		InitialAlpha:  1,
		InitialBeta:   1,
		SuccessWeight: 1,
		FailureWeight: 2,
		Decay:         0.98,
		MinimumScore:  0.55,
	}
}

func (config Config) Validate() error {
	if config.InitialAlpha <= 0 ||
		config.InitialBeta <= 0 ||
		config.SuccessWeight <= 0 ||
		config.FailureWeight <= 0 ||
		config.Decay <= 0 ||
		config.Decay > 1 ||
		config.MinimumScore < 0 ||
		config.MinimumScore > 1 {
		return ErrInvalidTrustConfig
	}
	return nil
}

type Evidence struct {
	Alpha     float64 `json:"alpha"`
	Beta      float64 `json:"beta"`
	Successes uint64  `json:"successes"`
	Failures  uint64  `json:"failures"`
}

func (evidence Evidence) Score() float64 {
	denominator := evidence.Alpha + evidence.Beta
	if denominator <= 0 {
		return 0
	}
	return evidence.Alpha / denominator
}

type Tracker struct {
	mu       sync.RWMutex
	config   Config
	evidence map[uint32]Evidence
}

func NewTracker(
	members []uint32,
	config Config,
) (*Tracker, error) {
	if err := config.Validate(); err != nil {
		return nil, err
	}
	if len(members) == 0 {
		return nil, ErrInvalidTrustConfig
	}

	canonical := append([]uint32(nil), members...)
	slices.Sort(canonical)
	evidence := make(map[uint32]Evidence, len(canonical))

	for index, member := range canonical {
		if index > 0 && member == canonical[index-1] {
			return nil, fmt.Errorf(
				"%w: duplicate member %d",
				ErrInvalidTrustConfig,
				member,
			)
		}
		evidence[member] = Evidence{
			Alpha: config.InitialAlpha,
			Beta:  config.InitialBeta,
		}
	}

	return &Tracker{config: config, evidence: evidence}, nil
}

func (tracker *Tracker) Observe(
	nodeID uint32,
	success bool,
) error {
	tracker.mu.Lock()
	defer tracker.mu.Unlock()

	evidence, exists := tracker.evidence[nodeID]
	if !exists {
		return fmt.Errorf("%w: node=%d", ErrUnknownTrustNode, nodeID)
	}

	evidence.Alpha *= tracker.config.Decay
	evidence.Beta *= tracker.config.Decay

	if success {
		evidence.Alpha += tracker.config.SuccessWeight
		evidence.Successes++
	} else {
		evidence.Beta += tracker.config.FailureWeight
		evidence.Failures++
	}

	tracker.evidence[nodeID] = evidence
	return nil
}

func (tracker *Tracker) Score(nodeID uint32) (float64, error) {
	tracker.mu.RLock()
	defer tracker.mu.RUnlock()

	evidence, exists := tracker.evidence[nodeID]
	if !exists {
		return 0, fmt.Errorf("%w: node=%d", ErrUnknownTrustNode, nodeID)
	}
	return evidence.Score(), nil
}

func (tracker *Tracker) Eligible(nodeID uint32) (bool, error) {
	score, err := tracker.Score(nodeID)
	if err != nil {
		return false, err
	}
	return score >= tracker.config.MinimumScore, nil
}

func (tracker *Tracker) Snapshot() map[uint32]Evidence {
	tracker.mu.RLock()
	defer tracker.mu.RUnlock()

	copyEvidence := make(map[uint32]Evidence, len(tracker.evidence))
	for nodeID, evidence := range tracker.evidence {
		copyEvidence[nodeID] = evidence
	}
	return copyEvidence
}

type SweepResult struct {
	Cutoff         float64 `json:"cutoff"`
	TruePositive   int     `json:"true_positive"`
	FalsePositive  int     `json:"false_positive"`
	TrueNegative   int     `json:"true_negative"`
	FalseNegative  int     `json:"false_negative"`
	Precision      float64 `json:"precision"`
	Recall         float64 `json:"recall"`
	HonestEligible int     `json:"honest_eligible"`
}

// Sweep evaluates how a quantitative eligibility cutoff separates known
// malicious nodes from honest nodes. "Positive" means excluded as malicious.
func Sweep(
	snapshot map[uint32]Evidence,
	malicious map[uint32]struct{},
	cutoffs []float64,
) ([]SweepResult, error) {
	results := make([]SweepResult, 0, len(cutoffs))

	for _, cutoff := range cutoffs {
		if cutoff < 0 || cutoff > 1 {
			return nil, ErrInvalidTrustConfig
		}

		result := SweepResult{Cutoff: cutoff}
		for nodeID, evidence := range snapshot {
			_, isMalicious := malicious[nodeID]
			excluded := evidence.Score() < cutoff

			switch {
			case isMalicious && excluded:
				result.TruePositive++
			case !isMalicious && excluded:
				result.FalsePositive++
			case !isMalicious && !excluded:
				result.TrueNegative++
				result.HonestEligible++
			case isMalicious && !excluded:
				result.FalseNegative++
			}
		}

		precisionDenominator := result.TruePositive + result.FalsePositive
		if precisionDenominator > 0 {
			result.Precision = float64(result.TruePositive) /
				float64(precisionDenominator)
		}
		recallDenominator := result.TruePositive + result.FalseNegative
		if recallDenominator > 0 {
			result.Recall = float64(result.TruePositive) /
				float64(recallDenominator)
		}
		results = append(results, result)
	}

	return results, nil
}
