package trust_test

import (
	"testing"

	"uav-bft/internal/trust"
)

func TestFailuresReduceTrustAndSuccessesRecover(t *testing.T) {
	tracker, err := trust.NewTracker(
		[]uint32{0, 1},
		trust.DefaultConfig(),
	)
	if err != nil {
		t.Fatalf("create tracker: %v", err)
	}

	initial, err := tracker.Score(0)
	if err != nil {
		t.Fatalf("initial score: %v", err)
	}

	for index := 0; index < 5; index++ {
		if err := tracker.Observe(0, false); err != nil {
			t.Fatalf("failure observation: %v", err)
		}
	}
	failed, _ := tracker.Score(0)
	if failed >= initial {
		t.Fatalf("failure score=%f initial=%f", failed, initial)
	}

	for index := 0; index < 30; index++ {
		if err := tracker.Observe(0, true); err != nil {
			t.Fatalf("success observation: %v", err)
		}
	}
	recovered, _ := tracker.Score(0)
	if recovered <= failed {
		t.Fatalf("recovered score=%f failed=%f", recovered, failed)
	}
}

func TestTrustSweepCountsClassification(t *testing.T) {
	snapshot := map[uint32]trust.Evidence{
		0: {Alpha: 9, Beta: 1},
		1: {Alpha: 8, Beta: 2},
		2: {Alpha: 1, Beta: 9},
		3: {Alpha: 2, Beta: 8},
	}
	malicious := map[uint32]struct{}{2: {}, 3: {}}

	results, err := trust.Sweep(
		snapshot,
		malicious,
		[]float64{0.5},
	)
	if err != nil {
		t.Fatalf("sweep: %v", err)
	}

	result := results[0]
	if result.TruePositive != 2 ||
		result.TrueNegative != 2 ||
		result.FalsePositive != 0 ||
		result.FalseNegative != 0 {
		t.Fatalf("unexpected classification: %+v", result)
	}
}
