package dkg

import (
	"errors"
	"fmt"
	"slices"
	"time"

	"go.dedis.ch/kyber/v4"
	"go.dedis.ch/kyber/v4/pairing/bls12381/kilic"
	"go.dedis.ch/kyber/v4/share"
	rabin "go.dedis.ch/kyber/v4/share/dkg/rabin"
)

var (
	ErrInvalidNodeCount  = errors.New("node count must be at least 2")
	ErrInvalidThreshold  = errors.New("threshold must satisfy 2 <= t <= n")
	ErrQUALMismatch      = errors.New("honest nodes derived different QUAL sets")
	ErrPublicKeyMismatch = errors.New(
		"honest nodes derived different distributed public keys",
	)
)

// Statistics separates protocol objects from broadcast deliveries.
// Serialized-byte accounting will be added after transport encoding.
type Statistics struct {
	Duration time.Duration

	DealObjects             int
	ResponseObjects         int
	ResponseDeliveries      int
	JustificationObjects    int
	JustificationDeliveries int

	SecretCommitObjects    int
	SecretCommitDeliveries int

	ComplaintObjects      int
	ReconstructionObjects int
}

// Result contains the output of one honest in-process GJKR execution.
type Result struct {
	Suite *kilic.SuiteBLS12381

	NodeCount int
	Threshold int

	QUAL []uint32

	Shares     []*rabin.DistKeyShare
	PublicPoly *share.PubPoly
	PublicKey  kyber.Point

	Statistics Statistics
}

// RunHonest performs the complete honest GJKR flow in one process.
//
// This is a protocol-correctness baseline. Later milestones replace the
// direct function calls with authenticated network messages, loss, delay,
// jitter, malicious dealers, complaints, and phase deadlines.
func RunHonest(nodeCount, threshold int) (*Result, error) {
	if nodeCount < 2 {
		return nil, ErrInvalidNodeCount
	}

	if threshold < 2 || threshold > nodeCount {
		return nil, ErrInvalidThreshold
	}

	started := time.Now()

	// This adapter uses G2 for public keys and the BLS12-381 scalar field.
	// The same suite is used for DKG and threshold BLS.
	suite := kilic.NewSuiteBLS12381()

	longTermPrivate := make([]kyber.Scalar, nodeCount)
	longTermPublic := make([]kyber.Point, nodeCount)

	for index := 0; index < nodeCount; index++ {
		longTermPrivate[index] = suite.Scalar().Pick(
			suite.RandomStream(),
		)

		longTermPublic[index] = suite.Point().Mul(
			longTermPrivate[index],
			nil,
		)
	}

	generators := make([]*rabin.DistKeyGenerator, nodeCount)

	for index := 0; index < nodeCount; index++ {
		generator, err := rabin.NewDistKeyGenerator(
			suite,
			longTermPrivate[index],
			longTermPublic,
			uint32(threshold),
		)
		if err != nil {
			return nil, fmt.Errorf(
				"create DKG generator for node %d: %w",
				index,
				err,
			)
		}

		generators[index] = generator
	}

	stats := Statistics{}

	// Phase 1: every dealer creates one encrypted deal for every
	// other participant.
	responses := make([]*rabin.Response, 0)

	for dealerIndex, generator := range generators {
		deals, err := generator.Deals()
		if err != nil {
			return nil, fmt.Errorf(
				"node %d create deals: %w",
				dealerIndex,
				err,
			)
		}

		stats.DealObjects += len(deals)

		for recipientIndex, deal := range deals {
			response, err := generators[recipientIndex].ProcessDeal(
				deal,
			)
			if err != nil {
				return nil, fmt.Errorf(
					"node %d process deal from node %d: %w",
					recipientIndex,
					dealerIndex,
					err,
				)
			}

			if response == nil {
				return nil, fmt.Errorf(
					"node %d returned nil response for dealer %d",
					recipientIndex,
					dealerIndex,
				)
			}

			responses = append(responses, response)
			stats.ResponseObjects++
		}
	}

	// Phase 2: responses are reliably broadcast. The response creator
	// is skipped because ProcessDeal already created its local response.
	justifications := make([]*rabin.Justification, 0)

	for _, response := range responses {
		responseCreator := int(response.Response.Index)

		for receiverIndex, generator := range generators {
			if receiverIndex == responseCreator {
				continue
			}

			justification, err := generator.ProcessResponse(response)
			if err != nil {
				return nil, fmt.Errorf(
					"node %d process response from node %d: %w",
					receiverIndex,
					responseCreator,
					err,
				)
			}

			stats.ResponseDeliveries++

			if justification != nil {
				justifications = append(
					justifications,
					justification,
				)
				stats.JustificationObjects++
			}
		}
	}

	// In an honest execution, this list should be empty. The code still
	// handles it so the transport structure is ready for malicious tests.
	for _, justification := range justifications {
		dealerIndex := int(justification.Index)

		for receiverIndex, generator := range generators {
			if receiverIndex == dealerIndex {
				continue
			}

			if err := generator.ProcessJustification(
				justification,
			); err != nil {
				return nil, fmt.Errorf(
					"node %d process justification from node %d: %w",
					receiverIndex,
					dealerIndex,
					err,
				)
			}

			stats.JustificationDeliveries++
		}
	}

	for index, generator := range generators {
		if !generator.Certified() {
			return nil, fmt.Errorf(
				"node %d did not certify enough deals",
				index,
			)
		}
	}

	// QUAL is mathematically a set. Kyber may return its indices in a
	// different iteration order at different participants, so compare
	// sorted copies and retain a canonical sorted representation.
	referenceQUAL := append([]uint32(nil), generators[0].QUAL()...)
	slices.Sort(referenceQUAL)

	for index := 1; index < nodeCount; index++ {
		currentQUAL := append(
			[]uint32(nil),
			generators[index].QUAL()...,
		)
		slices.Sort(currentQUAL)

		if !slices.Equal(referenceQUAL, currentQUAL) {
			return nil, fmt.Errorf(
				"%w: node0=%v node%d=%v",
				ErrQUALMismatch,
				referenceQUAL,
				index,
				currentQUAL,
			)
		}
	}

	// Phase 3: each qualified dealer reveals its secret polynomial
	// commitments. SecretCommits() installs the sender's own commitments,
	// so broadcasts are processed only by the other participants.
	secretCommitments := make([]*rabin.SecretCommits, nodeCount)

	for senderIndex, generator := range generators {
		secretCommits, err := generator.SecretCommits()
		if err != nil {
			return nil, fmt.Errorf(
				"node %d create secret commitments: %w",
				senderIndex,
				err,
			)
		}

		secretCommitments[senderIndex] = secretCommits
		stats.SecretCommitObjects++
	}

	complaints := make([]*rabin.ComplaintCommits, 0)

	for senderIndex, secretCommits := range secretCommitments {
		for receiverIndex, generator := range generators {
			if receiverIndex == senderIndex {
				continue
			}

			complaint, err := generator.ProcessSecretCommits(
				secretCommits,
			)
			if err != nil {
				return nil, fmt.Errorf(
					"node %d process secret commitments from node %d: %w",
					receiverIndex,
					senderIndex,
					err,
				)
			}

			stats.SecretCommitDeliveries++

			if complaint != nil {
				complaints = append(complaints, complaint)
				stats.ComplaintObjects++
			}
		}
	}

	// A fully honest execution must not create commitment complaints.
	if len(complaints) != 0 {
		return nil, fmt.Errorf(
			"honest DKG unexpectedly created %d commitment complaints",
			len(complaints),
		)
	}

	distributedShares := make(
		[]*rabin.DistKeyShare,
		nodeCount,
	)

	for index, generator := range generators {
		distributedShare, err := generator.DistKeyShare()
		if err != nil {
			return nil, fmt.Errorf(
				"node %d derive distributed share: %w",
				index,
				err,
			)
		}

		distributedShares[index] = distributedShare
	}

	referencePublicKey := distributedShares[0].Public()

	for index := 1; index < nodeCount; index++ {
		if !referencePublicKey.Equal(
			distributedShares[index].Public(),
		) {
			return nil, fmt.Errorf(
				"%w: node %d",
				ErrPublicKeyMismatch,
				index,
			)
		}
	}

	// DKG commitments and BLS public keys are in G2.
	publicPolynomial := share.NewPubPoly(
		suite.G2(),
		suite.G2().Point().Base(),
		distributedShares[0].Commitments(),
	)

	stats.Duration = time.Since(started)

	return &Result{
		Suite:      suite,
		NodeCount:  nodeCount,
		Threshold:  threshold,
		QUAL:       referenceQUAL,
		Shares:     distributedShares,
		PublicPoly: publicPolynomial,
		PublicKey:  referencePublicKey,
		Statistics: stats,
	}, nil
}
