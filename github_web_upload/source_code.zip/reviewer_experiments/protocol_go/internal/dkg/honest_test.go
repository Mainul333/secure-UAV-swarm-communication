package dkg_test

import (
	"bytes"
	"crypto/sha256"
	"testing"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
)

func TestHonestGJKRAndThresholdBLS(t *testing.T) {
	const (
		nodeCount = 4
		threshold = 3
	)

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		t.Fatalf("honest GJKR failed: %v", err)
	}

	if len(result.QUAL) != nodeCount {
		t.Fatalf(
			"QUAL size=%d; expected %d",
			len(result.QUAL),
			nodeCount,
		)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	message := sha256.Sum256(
		[]byte("UAV-BFT-CERTIFICATE-TEST"),
	)

	partialSignatures := make([][]byte, 0, threshold)

	for index := 0; index < threshold; index++ {
		partial, err := scheme.Sign(
			result.Shares[index].PriShare(),
			message[:],
		)
		if err != nil {
			t.Fatalf(
				"node %d create partial signature: %v",
				index,
				err,
			)
		}

		if err := scheme.VerifyPartial(
			result.PublicPoly,
			message[:],
			partial,
		); err != nil {
			t.Fatalf(
				"node %d partial verification failed: %v",
				index,
				err,
			)
		}

		partialIndex, err := scheme.IndexOf(partial)
		if err != nil {
			t.Fatalf(
				"node %d partial index decoding failed: %v",
				index,
				err,
			)
		}

		if partialIndex != index {
			t.Fatalf(
				"partial index=%d; expected %d",
				partialIndex,
				index,
			)
		}

		partialSignatures = append(
			partialSignatures,
			partial,
		)
	}

	recovered, err := scheme.Recover(
		result.PublicPoly,
		message[:],
		partialSignatures,
		uint32(threshold),
		uint32(nodeCount),
	)
	if err != nil {
		t.Fatalf("threshold reconstruction failed: %v", err)
	}

	if err := scheme.VerifyRecovered(
		result.PublicKey,
		message[:],
		recovered,
	); err != nil {
		t.Fatalf("recovered BLS signature invalid: %v", err)
	}

	if len(recovered) != 48 {
		t.Fatalf(
			"recovered signature size=%d; expected 48",
			len(recovered),
		)
	}
}

func TestThresholdMinusOneCannotReconstruct(t *testing.T) {
	const (
		nodeCount = 4
		threshold = 3
	)

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		t.Fatalf("honest GJKR failed: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	message := sha256.Sum256(
		[]byte("INSUFFICIENT-SHARES"),
	)

	partials := make([][]byte, 0, threshold-1)

	for index := 0; index < threshold-1; index++ {
		partial, err := scheme.Sign(
			result.Shares[index].PriShare(),
			message[:],
		)
		if err != nil {
			t.Fatalf("partial signing failed: %v", err)
		}

		partials = append(partials, partial)
	}

	_, err = scheme.Recover(
		result.PublicPoly,
		message[:],
		partials,
		uint32(threshold),
		uint32(nodeCount),
	)

	if err == nil {
		t.Fatal("t-1 partial signatures reconstructed a certificate")
	}
}

func TestDifferentThresholdSubsetsRecoverSameSignature(
	t *testing.T,
) {
	const (
		nodeCount = 7
		threshold = 5
	)

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		t.Fatalf("honest GJKR failed: %v", err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	message := sha256.Sum256(
		[]byte("SUBSET-INDEPENDENCE"),
	)

	allPartials := make([][]byte, nodeCount)

	for index := 0; index < nodeCount; index++ {
		allPartials[index], err = scheme.Sign(
			result.Shares[index].PriShare(),
			message[:],
		)
		if err != nil {
			t.Fatalf(
				"node %d partial signing failed: %v",
				index,
				err,
			)
		}
	}

	firstSubset := [][]byte{
		allPartials[0],
		allPartials[1],
		allPartials[2],
		allPartials[3],
		allPartials[4],
	}

	secondSubset := [][]byte{
		allPartials[1],
		allPartials[2],
		allPartials[4],
		allPartials[5],
		allPartials[6],
	}

	firstRecovered, err := scheme.Recover(
		result.PublicPoly,
		message[:],
		firstSubset,
		uint32(threshold),
		uint32(nodeCount),
	)
	if err != nil {
		t.Fatalf("first reconstruction failed: %v", err)
	}

	secondRecovered, err := scheme.Recover(
		result.PublicPoly,
		message[:],
		secondSubset,
		uint32(threshold),
		uint32(nodeCount),
	)
	if err != nil {
		t.Fatalf("second reconstruction failed: %v", err)
	}

	if !bytes.Equal(firstRecovered, secondRecovered) {
		t.Fatal(
			"different valid subsets recovered different signatures",
		)
	}

	if err := scheme.VerifyRecovered(
		result.PublicKey,
		message[:],
		firstRecovered,
	); err != nil {
		t.Fatalf("first recovered signature invalid: %v", err)
	}

	if err := scheme.VerifyRecovered(
		result.PublicKey,
		message[:],
		secondRecovered,
	); err != nil {
		t.Fatalf("second recovered signature invalid: %v", err)
	}
}
