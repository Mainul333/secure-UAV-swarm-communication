package identity_test

import (
	"bytes"
	"testing"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

func TestProposalIdentityBindsViewAndLeader(t *testing.T) {
	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatal(err)
	}
	proposal := wire.Proposal{
		Authorized: wire.AuthorizedCommand{
			Command: wire.Command{
				ProtocolVersion: wire.CurrentProtocolVersion,
				Epoch:           1,
				Round:           2,
				IssuedAtUnixNs:  1,
				ExpiresAtUnixNs: 2,
				CommandType:     1,
				Payload:         []byte("MOVE"),
				Nonce:           bytes.Repeat([]byte{1}, 16),
			},
			BaseStationID:  1,
			BaseStationSig: bytes.Repeat([]byte{2}, 64),
		},
		View:     3,
		LeaderID: 4,
	}
	proposal, err = identity.SignProposal(privateKey, proposal)
	if err != nil {
		t.Fatal(err)
	}
	if err := identity.VerifyProposal(publicKey, proposal); err != nil {
		t.Fatalf("valid proposal rejected: %v", err)
	}
	proposal.View++
	if err := identity.VerifyProposal(publicKey, proposal); err == nil {
		t.Fatal("modified view was accepted")
	}
}
