package identity_test

import (
	"bytes"
	"testing"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

func approvalForIdentityTest() wire.Approval {
	return wire.Approval{
		Epoch:         1,
		Round:         10,
		View:          2,
		CommandDigest: bytes.Repeat([]byte{0x10}, 32),
		SignerID:      3,
		PartialBLSSig: bytes.Repeat([]byte{0x20}, 50),
	}
}

func TestValidApprovalIdentityAccepted(t *testing.T) {
	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate key pair: %v", err)
	}

	approval := approvalForIdentityTest()

	approval.IdentitySig, err =
		identity.SignApprovalEnvelope(
			privateKey,
			approval,
		)
	if err != nil {
		t.Fatalf("sign approval: %v", err)
	}

	if err := identity.VerifyApprovalEnvelope(
		publicKey,
		approval,
	); err != nil {
		t.Fatalf("valid approval rejected: %v", err)
	}
}

func TestModifiedApprovalPartialRejected(t *testing.T) {
	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate key pair: %v", err)
	}

	approval := approvalForIdentityTest()

	approval.IdentitySig, err =
		identity.SignApprovalEnvelope(
			privateKey,
			approval,
		)
	if err != nil {
		t.Fatalf("sign approval: %v", err)
	}

	approval.PartialBLSSig[3] ^= 0x01

	if err := identity.VerifyApprovalEnvelope(
		publicKey,
		approval,
	); err == nil {
		t.Fatal("modified BLS partial was accepted")
	}
}

func TestModifiedApprovalSignerIDRejected(t *testing.T) {
	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate key pair: %v", err)
	}

	approval := approvalForIdentityTest()

	approval.IdentitySig, err =
		identity.SignApprovalEnvelope(
			privateKey,
			approval,
		)
	if err != nil {
		t.Fatalf("sign approval: %v", err)
	}

	approval.SignerID++

	if err := identity.VerifyApprovalEnvelope(
		publicKey,
		approval,
	); err == nil {
		t.Fatal("modified signer ID was accepted")
	}
}

func TestWrongFollowerIdentityRejected(t *testing.T) {
	_, firstPrivateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate first key pair: %v", err)
	}

	secondPublicKey, _, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate second key pair: %v", err)
	}

	approval := approvalForIdentityTest()

	approval.IdentitySig, err =
		identity.SignApprovalEnvelope(
			firstPrivateKey,
			approval,
		)
	if err != nil {
		t.Fatalf("sign approval: %v", err)
	}

	if err := identity.VerifyApprovalEnvelope(
		secondPublicKey,
		approval,
	); err == nil {
		t.Fatal("wrong follower public key was accepted")
	}
}
