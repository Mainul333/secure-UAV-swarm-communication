package identity

import (
	"crypto/ed25519"
	"errors"
	"fmt"

	"uav-bft/internal/wire"
)

var ErrInvalidViewChangeIdentity = errors.New(
	"invalid view-change identity signature",
)

// SignViewChange authenticates one timeout/view-change request with the
// sender's long-term Ed25519 identity key.
func SignViewChange(
	privateKey ed25519.PrivateKey,
	change wire.ViewChange,
) (wire.ViewChange, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return wire.ViewChange{}, ErrInvalidPrivateKey
	}

	digest, err := wire.ViewChangeIdentityDigest(change)
	if err != nil {
		return wire.ViewChange{}, fmt.Errorf(
			"calculate view-change identity digest: %w",
			err,
		)
	}

	change.IdentitySig = ed25519.Sign(privateKey, digest[:])
	return change, nil
}

// VerifyViewChange verifies the complete view-change envelope.
func VerifyViewChange(
	publicKey ed25519.PublicKey,
	change wire.ViewChange,
) error {
	if len(publicKey) != ed25519.PublicKeySize {
		return ErrInvalidPublicKey
	}

	if len(change.IdentitySig) != ed25519.SignatureSize {
		return ErrInvalidViewChangeIdentity
	}

	digest, err := wire.ViewChangeIdentityDigest(change)
	if err != nil {
		return fmt.Errorf(
			"calculate view-change identity digest: %w",
			err,
		)
	}

	if !ed25519.Verify(publicKey, digest[:], change.IdentitySig) {
		return ErrInvalidViewChangeIdentity
	}

	return nil
}
