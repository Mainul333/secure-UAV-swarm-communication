package identity

import (
	"crypto/ed25519"
	"errors"
	"fmt"

	"uav-bft/internal/wire"
)

var ErrInvalidProposalIdentity = errors.New(
	"invalid leader proposal identity signature",
)

func SignProposal(
	privateKey ed25519.PrivateKey,
	proposal wire.Proposal,
) (wire.Proposal, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return wire.Proposal{}, ErrInvalidPrivateKey
	}
	digest, err := wire.ProposalIdentityDigest(proposal)
	if err != nil {
		return wire.Proposal{}, fmt.Errorf("proposal digest: %w", err)
	}
	proposal.LeaderIdentitySig = ed25519.Sign(privateKey, digest[:])
	return proposal, nil
}

func VerifyProposal(
	publicKey ed25519.PublicKey,
	proposal wire.Proposal,
) error {
	if len(publicKey) != ed25519.PublicKeySize {
		return ErrInvalidPublicKey
	}
	if len(proposal.LeaderIdentitySig) != ed25519.SignatureSize {
		return ErrInvalidProposalIdentity
	}
	digest, err := wire.ProposalIdentityDigest(proposal)
	if err != nil {
		return fmt.Errorf("proposal digest: %w", err)
	}
	if !ed25519.Verify(publicKey, digest[:], proposal.LeaderIdentitySig) {
		return ErrInvalidProposalIdentity
	}
	return nil
}
