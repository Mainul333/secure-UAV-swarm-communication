package identity

import (
	"crypto/ed25519"
	"crypto/rand"
	"errors"
	"fmt"
	"time"

	"uav-bft/internal/wire"
)

var (
	ErrInvalidPrivateKey    = errors.New("invalid Ed25519 private key")
	ErrInvalidPublicKey     = errors.New("invalid Ed25519 public key")
	ErrInvalidAuthorization = errors.New("invalid base-station authorization")
)

// GenerateKeyPair creates one Ed25519 base-station identity.
func GenerateKeyPair() (
	ed25519.PublicKey,
	ed25519.PrivateKey,
	error,
) {
	publicKey, privateKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, nil, err
	}

	return publicKey, privateKey, nil
}

// AuthorizeCommand signs a complete command and binds it to the
// base-station identifier.
func AuthorizeCommand(
	privateKey ed25519.PrivateKey,
	baseStationID uint32,
	command wire.Command,
	now time.Time,
) (wire.AuthorizedCommand, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return wire.AuthorizedCommand{}, ErrInvalidPrivateKey
	}

	if err := wire.ValidateCommand(command, now); err != nil {
		return wire.AuthorizedCommand{}, fmt.Errorf(
			"command validation failed: %w",
			err,
		)
	}

	digest, err := wire.AuthorizationDigest(command, baseStationID)
	if err != nil {
		return wire.AuthorizedCommand{}, err
	}

	signature := ed25519.Sign(privateKey, digest[:])

	return wire.AuthorizedCommand{
		Command:        command,
		BaseStationID:  baseStationID,
		BaseStationSig: append([]byte(nil), signature...),
	}, nil
}

// VerifyAuthorizedCommand validates the command and verifies its
// base-station Ed25519 authorization.
func VerifyAuthorizedCommand(
	publicKey ed25519.PublicKey,
	authorized wire.AuthorizedCommand,
	now time.Time,
) error {
	if len(publicKey) != ed25519.PublicKeySize {
		return ErrInvalidPublicKey
	}

	if len(authorized.BaseStationSig) != ed25519.SignatureSize {
		return ErrInvalidAuthorization
	}

	if err := wire.ValidateCommand(authorized.Command, now); err != nil {
		return fmt.Errorf("command validation failed: %w", err)
	}

	digest, err := wire.AuthorizationDigest(
		authorized.Command,
		authorized.BaseStationID,
	)
	if err != nil {
		return err
	}

	if !ed25519.Verify(
		publicKey,
		digest[:],
		authorized.BaseStationSig,
	) {
		return ErrInvalidAuthorization
	}

	return nil
}
