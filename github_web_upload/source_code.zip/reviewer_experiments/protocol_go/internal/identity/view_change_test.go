package identity_test

import (
	"bytes"
	"testing"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

func TestViewChangeIdentityRoundTrip(t *testing.T) {
	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate identity: %v", err)
	}

	change, err := identity.SignViewChange(
		privateKey,
		wire.ViewChange{
			Epoch:         1,
			Round:         6,
			NewView:       2,
			CommandDigest: bytes.Repeat([]byte{0x55}, 32),
			SenderID:      3,
		},
	)
	if err != nil {
		t.Fatalf("sign view change: %v", err)
	}

	if err := identity.VerifyViewChange(publicKey, change); err != nil {
		t.Fatalf("verify view change: %v", err)
	}

	change.NewView++
	if err := identity.VerifyViewChange(publicKey, change); err == nil {
		t.Fatal("modified new view was accepted")
	}
}

func TestViewChangeWrongIdentityRejected(t *testing.T) {
	_, firstPrivateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate first identity: %v", err)
	}

	secondPublicKey, _, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("generate second identity: %v", err)
	}

	change, err := identity.SignViewChange(
		firstPrivateKey,
		wire.ViewChange{
			Epoch:         1,
			Round:         6,
			NewView:       2,
			CommandDigest: bytes.Repeat([]byte{0x55}, 32),
			SenderID:      3,
		},
	)
	if err != nil {
		t.Fatalf("sign view change: %v", err)
	}

	if err := identity.VerifyViewChange(secondPublicKey, change); err == nil {
		t.Fatal("wrong identity key was accepted")
	}
}
