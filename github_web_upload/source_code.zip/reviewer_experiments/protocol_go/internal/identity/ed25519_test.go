package identity_test

import (
	"testing"
	"time"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

func validCommand(now time.Time) wire.Command {
	return wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           10,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte("MOVE:X=5,Y=5,Z=-5"),
		Nonce:           []byte("1234567890ABCDEF"),
	}
}

func TestValidAuthorizationAccepted(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("key generation failed: %v", err)
	}

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		validCommand(now),
		now,
	)
	if err != nil {
		t.Fatalf("authorization failed: %v", err)
	}

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		authorized,
		now,
	); err != nil {
		t.Fatalf("valid authorization rejected: %v", err)
	}
}

func TestModifiedPayloadRejected(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("key generation failed: %v", err)
	}

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		validCommand(now),
		now,
	)
	if err != nil {
		t.Fatalf("authorization failed: %v", err)
	}

	authorized.Command.Payload = []byte("LAND")

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		authorized,
		now,
	); err == nil {
		t.Fatal("modified payload was accepted")
	}
}

func TestModifiedRoundRejected(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("key generation failed: %v", err)
	}

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		validCommand(now),
		now,
	)
	if err != nil {
		t.Fatalf("authorization failed: %v", err)
	}

	authorized.Command.Round++

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		authorized,
		now,
	); err == nil {
		t.Fatal("modified round was accepted")
	}
}

func TestModifiedBaseStationIDRejected(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("key generation failed: %v", err)
	}

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		validCommand(now),
		now,
	)
	if err != nil {
		t.Fatalf("authorization failed: %v", err)
	}

	authorized.BaseStationID = 2

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		authorized,
		now,
	); err == nil {
		t.Fatal("modified base-station identifier was accepted")
	}
}

func TestWrongPublicKeyRejected(t *testing.T) {
	now := time.Unix(1_700_000_000, 0).UTC()

	_, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("first key generation failed: %v", err)
	}

	wrongPublicKey, _, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("second key generation failed: %v", err)
	}

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		validCommand(now),
		now,
	)
	if err != nil {
		t.Fatalf("authorization failed: %v", err)
	}

	if err := identity.VerifyAuthorizedCommand(
		wrongPublicKey,
		authorized,
		now,
	); err == nil {
		t.Fatal("wrong public key was accepted")
	}
}

func TestExpiredAuthorizationRejected(t *testing.T) {
	signingTime := time.Unix(1_700_000_000, 0).UTC()

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		t.Fatalf("key generation failed: %v", err)
	}

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		validCommand(signingTime),
		signingTime,
	)
	if err != nil {
		t.Fatalf("authorization failed: %v", err)
	}

	verificationTime := signingTime.Add(2 * time.Minute)

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		authorized,
		verificationTime,
	); err == nil {
		t.Fatal("expired authorization was accepted")
	}
}
