package identity

import (
	"crypto/ed25519"
	"errors"
	"fmt"

	"uav-bft/internal/wire"
)

var ErrInvalidApprovalIdentity = errors.New(
	"invalid approval-envelope identity signature",
)

// SignApprovalEnvelope authenticates an approval using the UAV's
// long-term Ed25519 identity key.
func SignApprovalEnvelope(
	privateKey ed25519.PrivateKey,
	approval wire.Approval,
) ([]byte, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return nil, ErrInvalidPrivateKey
	}

	digest, err := wire.ApprovalIdentityDigest(approval)
	if err != nil {
		return nil, fmt.Errorf(
			"calculate approval identity digest: %w",
			err,
		)
	}

	signature := ed25519.Sign(privateKey, digest[:])

	return append([]byte(nil), signature...), nil
}

// VerifyApprovalEnvelope verifies the sender identity over the exact
// approval content.
func VerifyApprovalEnvelope(
	publicKey ed25519.PublicKey,
	approval wire.Approval,
) error {
	if len(publicKey) != ed25519.PublicKeySize {
		return ErrInvalidPublicKey
	}

	if len(approval.IdentitySig) != ed25519.SignatureSize {
		return ErrInvalidApprovalIdentity
	}

	digest, err := wire.ApprovalIdentityDigest(approval)
	if err != nil {
		return fmt.Errorf(
			"calculate approval identity digest: %w",
			err,
		)
	}

	if !ed25519.Verify(
		publicKey,
		digest[:],
		approval.IdentitySig,
	) {
		return ErrInvalidApprovalIdentity
	}

	return nil
}
