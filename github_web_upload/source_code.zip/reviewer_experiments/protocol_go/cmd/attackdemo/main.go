package main

import (
	"context"
	"crypto/ed25519"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

func main() {
	const (
		nodeCount = 4
		threshold = 3
	)

	ctx := context.Background()
	now := time.Now().UTC()
	dkgResult, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		panic(err)
	}
	scheme := tbls.NewThresholdSchemeOnG1(dkgResult.Suite)

	baseStationPublicKey, baseStationPrivateKey, err :=
		identity.GenerateKeyPair()
	if err != nil {
		panic(err)
	}
	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           70,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(5 * time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte("MOVE:X=5,Y=5,Z=-5"),
		Nonce:           []byte("0123456789ABCDEF"),
	}
	authorized, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		command,
		now,
	)
	if err != nil {
		panic(err)
	}

	stateDirectory, err := os.MkdirTemp("", "uav-bft-attack-demo-*")
	if err != nil {
		panic(err)
	}
	defer os.RemoveAll(stateDirectory)

	signers := make(
		[]*thresholdprotocol.AuthenticatedFollowerSigner,
		threshold,
	)
	registry := make(map[uint32]ed25519.PublicKey, threshold)
	stores := make([]*storage.VoteStore, 0, threshold)
	defer func() {
		for _, store := range stores {
			_ = store.Close()
		}
	}()

	for index := 0; index < threshold; index++ {
		store, err := storage.OpenVoteStore(filepath.Join(
			stateDirectory,
			fmt.Sprintf("node%d.db", index),
		))
		if err != nil {
			panic(err)
		}
		stores = append(stores, store)

		follower, err := thresholdprotocol.NewFollowerSigner(
			scheme,
			dkgResult.Shares[index].PriShare(),
			dkgResult.PublicPoly,
			store,
			baseStationPublicKey,
		)
		if err != nil {
			panic(err)
		}

		publicKey, privateKey, err := identity.GenerateKeyPair()
		if err != nil {
			panic(err)
		}
		authenticated, err :=
			thresholdprotocol.NewAuthenticatedFollowerSigner(
				follower,
				privateKey,
			)
		if err != nil {
			panic(err)
		}
		signers[index] = authenticated
		registry[authenticated.SignerID()] = publicKey
	}

	approvals := make([]wire.Approval, 0, threshold)
	for _, signer := range signers {
		approval, err := signer.Approve(ctx, authorized, 0, now)
		if err != nil {
			panic(err)
		}
		approvals = append(approvals, approval.Approval)
	}

	certificate, err := thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		authorized,
		0,
		approvals,
		registry,
		threshold,
		nodeCount,
	)
	if err != nil {
		panic(err)
	}
	fmt.Println("Valid threshold certificate: PASSED")

	forged := append([]wire.Approval(nil), approvals...)
	forged[0].PartialBLSSig = append(
		[]byte(nil),
		forged[0].PartialBLSSig...,
	)
	forged[0].PartialBLSSig[0] ^= 0x80
	_, err = thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		authorized,
		0,
		forged,
		registry,
		threshold,
		nodeCount,
	)
	if !errors.Is(err, thresholdprotocol.ErrAuthenticatedApprovalRejected) {
		panic(fmt.Sprintf("forged partial was not rejected: %v", err))
	}
	fmt.Println("Forged threshold partial: REJECTED")

	substitution := append([]wire.Approval(nil), approvals...)
	substitution[0].SignerID = substitution[1].SignerID
	_, err = thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		authorized,
		0,
		substitution,
		registry,
		threshold,
		nodeCount,
	)
	if !errors.Is(err, thresholdprotocol.ErrAuthenticatedApprovalRejected) {
		panic(fmt.Sprintf("signer substitution was not rejected: %v", err))
	}
	fmt.Println("Signer-ID substitution: REJECTED")

	_, err = thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		authorized,
		1,
		approvals,
		registry,
		threshold,
		nodeCount,
	)
	if !errors.Is(err, thresholdprotocol.ErrApprovalViewMismatch) {
		panic(fmt.Sprintf("old-view replay was not rejected: %v", err))
	}
	fmt.Println("Old-view replay: REJECTED")

	_, err = thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		authorized,
		0,
		approvals[:threshold-1],
		registry,
		threshold,
		nodeCount,
	)
	if !errors.Is(err, thresholdprotocol.ErrInsufficientApprovals) {
		panic(fmt.Sprintf("t-1 approvals were not rejected: %v", err))
	}
	fmt.Println("Threshold-minus-one reconstruction: REJECTED")

	tamperedAuthorization := authorized
	tamperedAuthorization.Command.Payload = []byte("MALICIOUS-LAND")
	_, err = signers[0].Approve(ctx, tamperedAuthorization, 0, now)
	if err == nil {
		panic("tampered base-station authorization was accepted")
	}
	fmt.Println("Tampered base-station command: REJECTED")

	conflicting, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		wire.Command{
			ProtocolVersion: wire.CurrentProtocolVersion,
			Epoch:           1,
			Round:           70,
			IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
			ExpiresAtUnixNs: now.Add(5 * time.Minute).UnixNano(),
			CommandType:     2,
			Payload:         []byte("LAND"),
			Nonce:           []byte("FEDCBA9876543210"),
		},
		now,
	)
	if err != nil {
		panic(err)
	}
	_, err = signers[0].Approve(ctx, conflicting, 1, now)
	if !errors.Is(err, storage.ErrConflictingVote) {
		panic(fmt.Sprintf("conflicting command was not rejected: %v", err))
	}
	fmt.Println("Conflicting valid command in same round: REJECTED")
	fmt.Println("Recovered certificate bytes:", len(certificate.ThresholdBLSSig))
	fmt.Println("Authenticated attack checks: PASSED")
}
