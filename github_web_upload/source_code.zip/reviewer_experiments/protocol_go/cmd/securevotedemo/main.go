package main

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

func makeCommand(
	now time.Time,
	payload string,
	nonce string,
) wire.Command {
	return wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           1,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte(payload),
		Nonce:           []byte(nonce),
	}
}

func main() {
	const (
		nodeCount = 4
		threshold = 3
	)

	ctx := context.Background()
	now := time.Now().UTC()

	fmt.Println("Running n=4, t=3 GJKR correctness setup...")

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		panic(err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	baseStationPublicKey, baseStationPrivateKey, err :=
		identity.GenerateKeyPair()
	if err != nil {
		panic(err)
	}

	authorized, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		makeCommand(
			now,
			"MOVE:X=5,Y=5,Z=-5",
			"0123456789ABCDEF",
		),
		now,
	)
	if err != nil {
		panic(err)
	}

	stateDirectory, err := os.MkdirTemp(
		"",
		"uav-bft-secure-vote-*",
	)
	if err != nil {
		panic(err)
	}
	defer os.RemoveAll(stateDirectory)

	stores := make([]*storage.VoteStore, threshold)
	followers := make(
		[]*thresholdprotocol.FollowerSigner,
		threshold,
	)

	for index := 0; index < threshold; index++ {
		store, err := storage.OpenVoteStore(
			filepath.Join(
				stateDirectory,
				fmt.Sprintf("node%d.db", index),
			),
		)
		if err != nil {
			panic(err)
		}

		stores[index] = store
		defer store.Close()

		follower, err :=
			thresholdprotocol.NewFollowerSigner(
				scheme,
				result.Shares[index].PriShare(),
				result.PublicPoly,
				store,
				baseStationPublicKey,
			)
		if err != nil {
			panic(err)
		}

		followers[index] = follower
	}

	viewZeroApprovals := make(
		[]wire.Approval,
		0,
		threshold,
	)

	for index, follower := range followers {
		result, err := follower.Approve(
			ctx,
			authorized,
			0,
			now,
		)
		if err != nil {
			panic(err)
		}

		fmt.Printf(
			"Node %d view 0: created=%v partial=%d bytes\n",
			index,
			result.Created,
			len(result.Approval.PartialBLSSig),
		)

		viewZeroApprovals = append(
			viewZeroApprovals,
			result.Approval,
		)
	}

	viewOneApprovals := make(
		[]wire.Approval,
		0,
		threshold,
	)

	for index, follower := range followers {
		result, err := follower.Approve(
			ctx,
			authorized,
			1,
			now,
		)
		if err != nil {
			panic(err)
		}

		if result.Created {
			panic("same command created a new partial in view 1")
		}

		if !bytes.Equal(
			viewZeroApprovals[index].PartialBLSSig,
			result.Approval.PartialBLSSig,
		) {
			panic("partial changed across view change")
		}

		fmt.Printf(
			"Node %d view 1: reused stored partial\n",
			index,
		)

		viewOneApprovals = append(
			viewOneApprovals,
			result.Approval,
		)
	}

	conflictingAuthorized, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		makeCommand(
			now,
			"LAND",
			"FEDCBA9876543210",
		),
		now,
	)
	if err != nil {
		panic(err)
	}

	_, err = followers[0].Approve(
		ctx,
		conflictingAuthorized,
		1,
		now,
	)

	if !errors.Is(err, storage.ErrConflictingVote) {
		panic(fmt.Sprintf(
			"expected conflicting-vote rejection, got %v",
			err,
		))
	}

	fmt.Println(
		"Conflicting valid BS command in same round: REJECTED",
	)

	certificate, err :=
		thresholdprotocol.RecoverCertificate(
			scheme,
			result.PublicPoly,
			result.PublicKey,
			authorized,
			1,
			viewOneApprovals,
			threshold,
			nodeCount,
		)
	if err != nil {
		panic(err)
	}

	fmt.Println("Threshold certificate: PASSED")
	fmt.Println("Certificate view:", certificate.View)
	fmt.Println("Certificate signers:", certificate.SignerIDs)
	fmt.Println(
		"Certificate size:",
		len(certificate.ThresholdBLSSig),
		"bytes",
	)
	fmt.Println(
		"Persistent real-share one-vote integration: PASSED",
	)
}
