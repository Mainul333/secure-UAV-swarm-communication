package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/csv"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/attack"
	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/simulation"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/transport"
	"uav-bft/internal/trust"
	"uav-bft/internal/wire"
)

type trialRow struct {
	Run              int     `json:"run"`
	Ablation         string  `json:"ablation"`
	Scenario         string  `json:"scenario"`
	ExpectedOutcome  string  `json:"expected_outcome"`
	ObservedOutcome  string  `json:"observed_outcome"`
	Passed           bool    `json:"passed"`
	LatencyMS        float64 `json:"latency_ms"`
	SuccessRatePct   float64 `json:"success_rate_pct"`
	RejectedEvidence int     `json:"rejected_evidence"`
	Details          string  `json:"details"`
}

type completion struct {
	Runs            int    `json:"runs"`
	ExecutedRows    int    `json:"executed_rows"`
	ValidatedRows   int    `json:"validated_rows"`
	Success         bool   `json:"success"`
	StartedAt       string `json:"started_at"`
	FinishedAt      string `json:"finished_at"`
	TrialsCSV       string `json:"trials_csv"`
	SummaryCSV      string `json:"summary_csv"`
	ImportantNotice string `json:"important_notice"`
}

func makeCommand(
	privateKey ed25519.PrivateKey,
	epoch uint64,
	round uint64,
	variant string,
) (wire.AuthorizedCommand, error) {
	now := time.Now().UTC()
	nonce := make([]byte, 32)
	if _, err := rand.Read(nonce); err != nil {
		return wire.AuthorizedCommand{}, err
	}
	payload, err := json.Marshal(map[string]any{
		"action":  "test-command",
		"variant": variant,
	})
	if err != nil {
		return wire.AuthorizedCommand{}, err
	}
	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           epoch,
		Round:           round,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(10 * time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         payload,
		Nonce:           nonce,
	}
	return identity.AuthorizeCommand(privateKey, 1, command, now)
}

type setup struct {
	nodeCount    int
	threshold    int
	dkgResult    *dkg.Result
	basePublic   ed25519.PublicKey
	basePrivate  ed25519.PrivateKey
	authorizedA  wire.AuthorizedCommand
	authorizedB  wire.AuthorizedCommand
	signers      []*thresholdprotocol.AuthenticatedFollowerSigner
	registry     map[uint32]ed25519.PublicKey
	stores       []*storage.VoteStore
	voteDir      string
	identityKeys []ed25519.PrivateKey
}

func newSetup(nodeCount, threshold int, run int) (*setup, error) {
	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		return nil, err
	}
	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)
	basePublic, basePrivate, err := identity.GenerateKeyPair()
	if err != nil {
		return nil, err
	}
	round := uint64(time.Now().UnixNano()) + uint64(run)
	authorizedA, err := makeCommand(basePrivate, 1, round, "A")
	if err != nil {
		return nil, err
	}
	authorizedB, err := makeCommand(basePrivate, 1, round, "B")
	if err != nil {
		return nil, err
	}
	voteDir, err := os.MkdirTemp("", "uav-bft-ablation-votes-")
	if err != nil {
		return nil, err
	}
	fixture := &setup{
		nodeCount:    nodeCount,
		threshold:    threshold,
		dkgResult:    result,
		basePublic:   basePublic,
		basePrivate:  basePrivate,
		authorizedA:  authorizedA,
		authorizedB:  authorizedB,
		registry:     make(map[uint32]ed25519.PublicKey, nodeCount),
		voteDir:      voteDir,
		identityKeys: make([]ed25519.PrivateKey, 0, nodeCount),
	}
	for index := 0; index < nodeCount; index++ {
		store, err := storage.OpenVoteStore(filepath.Join(voteDir, fmt.Sprintf("node-%d.db", index)))
		if err != nil {
			fixture.close()
			return nil, err
		}
		fixture.stores = append(fixture.stores, store)
		follower, err := thresholdprotocol.NewFollowerSigner(
			scheme,
			result.Shares[index].PriShare(),
			result.PublicPoly,
			store,
			basePublic,
		)
		if err != nil {
			fixture.close()
			return nil, err
		}
		publicKey, privateKey, err := identity.GenerateKeyPair()
		if err != nil {
			fixture.close()
			return nil, err
		}
		signer, err := thresholdprotocol.NewAuthenticatedFollowerSigner(follower, privateKey)
		if err != nil {
			fixture.close()
			return nil, err
		}
		fixture.signers = append(fixture.signers, signer)
		fixture.registry[signer.SignerID()] = publicKey
		fixture.identityKeys = append(fixture.identityKeys, privateKey)
	}
	return fixture, nil
}

func (s *setup) close() {
	for _, store := range s.stores {
		_ = store.Close()
	}
	if s.voteDir != "" {
		_ = os.RemoveAll(s.voteDir)
	}
}

func collectApprovals(s *setup, authorized wire.AuthorizedCommand, count int) ([]wire.Approval, error) {
	approvals := make([]wire.Approval, 0, count)
	for index := 0; index < count; index++ {
		result, err := s.signers[index].Approve(context.Background(), authorized, 0, time.Now().UTC())
		if err != nil {
			return nil, err
		}
		approvals = append(approvals, result.Approval)
	}
	return approvals, nil
}

func authenticatedEnvelopeRows(run int, s *setup) ([]trialRow, error) {
	approvals, err := collectApprovals(s, s.authorizedA, s.threshold)
	if err != nil {
		return nil, err
	}
	tampered := append([]wire.Approval(nil), approvals...)
	tampered[0].IdentitySig = append([]byte(nil), tampered[0].IdentitySig...)
	if len(tampered[0].IdentitySig) > 0 {
		tampered[0].IdentitySig[0] ^= 0x80
	}
	scheme := tbls.NewThresholdSchemeOnG1(s.dkgResult.Suite)

	started := time.Now()
	_, fullErr := thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		s.dkgResult.PublicPoly,
		s.dkgResult.PublicKey,
		s.authorizedA,
		0,
		tampered,
		s.registry,
		uint32(s.threshold),
		uint32(s.nodeCount),
	)
	fullLatency := float64(time.Since(started).Microseconds()) / 1000

	started = time.Now()
	_, unauthErr := thresholdprotocol.RecoverCertificate(
		scheme,
		s.dkgResult.PublicPoly,
		s.dkgResult.PublicKey,
		s.authorizedA,
		0,
		tampered,
		uint32(s.threshold),
		uint32(s.nodeCount),
	)
	unauthLatency := float64(time.Since(started).Microseconds()) / 1000

	return []trialRow{
		{
			Run: run, Ablation: "full_authenticated_approvals", Scenario: "tampered_identity_envelope",
			ExpectedOutcome: "reject", ObservedOutcome: map[bool]string{true: "rejected", false: "accepted"}[fullErr != nil],
			Passed: fullErr != nil, LatencyMS: fullLatency, RejectedEvidence: map[bool]int{true: 1, false: 0}[fullErr != nil],
			Details: fmt.Sprintf("authenticated recovery error=%v", fullErr),
		},
		{
			Run: run, Ablation: "without_authenticated_approvals", Scenario: "tampered_identity_envelope",
			ExpectedOutcome: "tamper_not_detected_by_ablation", ObservedOutcome: map[bool]string{true: "accepted", false: "rejected"}[unauthErr == nil],
			Passed: unauthErr == nil, LatencyMS: unauthLatency,
			Details: fmt.Sprintf("unauthenticated recovery error=%v", unauthErr),
		},
	}, nil
}

func persistentVoteRows(run int, s *setup) ([]trialRow, error) {
	_, err := s.signers[0].Approve(context.Background(), s.authorizedA, 0, time.Now().UTC())
	if err != nil {
		return nil, err
	}
	started := time.Now()
	_, conflictErr := s.signers[0].Approve(context.Background(), s.authorizedB, 0, time.Now().UTC())
	fullLatency := float64(time.Since(started).Microseconds()) / 1000
	fullRejected := errors.Is(conflictErr, storage.ErrConflictingVote)

	scheme := tbls.NewThresholdSchemeOnG1(s.dkgResult.Suite)
	digestA, err := wire.CertificateDigest(s.authorizedA)
	if err != nil {
		return nil, err
	}
	digestB, err := wire.CertificateDigest(s.authorizedB)
	if err != nil {
		return nil, err
	}
	started = time.Now()
	partialA, errA := scheme.Sign(s.dkgResult.Shares[1].PriShare(), digestA[:])
	partialB, errB := scheme.Sign(s.dkgResult.Shares[1].PriShare(), digestB[:])
	verifyA := scheme.VerifyPartial(s.dkgResult.PublicPoly, digestA[:], partialA)
	verifyB := scheme.VerifyPartial(s.dkgResult.PublicPoly, digestB[:], partialB)
	ablationLatency := float64(time.Since(started).Microseconds()) / 1000
	bothSigned := errA == nil && errB == nil && verifyA == nil && verifyB == nil

	return []trialRow{
		{
			Run: run, Ablation: "full_persistent_one_vote", Scenario: "conflicting_command_same_epoch_round",
			ExpectedOutcome: "reject_second_vote", ObservedOutcome: map[bool]string{true: "rejected", false: "accepted"}[fullRejected],
			Passed: fullRejected, LatencyMS: fullLatency, RejectedEvidence: map[bool]int{true: 1, false: 0}[fullRejected],
			Details: fmt.Sprintf("second approval error=%v", conflictErr),
		},
		{
			Run: run, Ablation: "without_persistent_one_vote", Scenario: "conflicting_command_same_epoch_round",
			ExpectedOutcome: "both_conflicting_partials_possible", ObservedOutcome: map[bool]string{true: "both_signed", false: "signing_failed"}[bothSigned],
			Passed: bothSigned, LatencyMS: ablationLatency,
			Details: fmt.Sprintf("signA=%v signB=%v verifyA=%v verifyB=%v", errA, errB, verifyA, verifyB),
		},
	}, nil
}

func viewChangeRows(run int) ([]trialRow, error) {
	base := simulation.DefaultConfig()
	base.NodeCount = 10
	base.Threshold = 7
	base.Rounds = 30
	base.ViewTimeout = 150 * time.Millisecond
	base.TimeoutRetries = 3
	base.Network = transport.IdealProfile()
	base.Seed = int64(202600 + run)
	base.Attack = attack.NewPlan(attack.ProposalWithholding)

	full := base
	full.MaxViews = 3
	started := time.Now()
	fullResult, err := simulation.Run(full)
	fullLatency := float64(time.Since(started).Microseconds()) / 1000
	if err != nil {
		return nil, err
	}

	without := base
	without.MaxViews = 1
	started = time.Now()
	withoutResult, err := simulation.Run(without)
	withoutLatency := float64(time.Since(started).Microseconds()) / 1000
	if err != nil {
		return nil, err
	}

	return []trialRow{
		{
			Run: run, Ablation: "full_view_change", Scenario: "proposal_withholding",
			ExpectedOutcome: "recover_in_replacement_view", ObservedOutcome: fmt.Sprintf("success_rate=%.1f%%", fullResult.SuccessRate*100),
			Passed: fullResult.SuccessRate == 1, LatencyMS: fullLatency, SuccessRatePct: fullResult.SuccessRate * 100,
			Details: fmt.Sprintf("mean_views=%.3f mean_protocol_latency_ms=%.3f", fullResult.MeanViews, float64(fullResult.MeanLatency.Microseconds())/1000),
		},
		{
			Run: run, Ablation: "without_view_change", Scenario: "proposal_withholding",
			ExpectedOutcome: "liveness_failure", ObservedOutcome: fmt.Sprintf("success_rate=%.1f%%", withoutResult.SuccessRate*100),
			Passed: withoutResult.SuccessRate == 0, LatencyMS: withoutLatency, SuccessRatePct: withoutResult.SuccessRate * 100,
			Details: fmt.Sprintf("mean_views=%.3f mean_protocol_latency_ms=%.3f", withoutResult.MeanViews, float64(withoutResult.MeanLatency.Microseconds())/1000),
		},
	}, nil
}

func trustRows(run int) ([]trialRow, error) {
	members := make([]uint32, 10)
	for index := range members {
		members[index] = uint32(index)
	}
	tracker, err := trust.NewTracker(members, trust.DefaultConfig())
	if err != nil {
		return nil, err
	}
	for observation := 0; observation < 4; observation++ {
		if err := tracker.Observe(0, false); err != nil {
			return nil, err
		}
		for node := uint32(1); node < 10; node++ {
			if err := tracker.Observe(node, true); err != nil {
				return nil, err
			}
		}
	}
	eligible, err := tracker.Eligible(0)
	if err != nil {
		return nil, err
	}
	score, err := tracker.Score(0)
	if err != nil {
		return nil, err
	}
	const rounds = 30
	roundRobinMalicious := 0
	trustAwareMalicious := 0
	for round := 0; round < rounds; round++ {
		candidate := uint32(round % 10)
		if candidate == 0 {
			roundRobinMalicious++
		}
		if candidate == 0 && eligible {
			trustAwareMalicious++
		}
	}
	return []trialRow{
		{
			Run: run, Ablation: "full_trust_aware_selection", Scenario: "repeated_malicious_leader",
			ExpectedOutcome: "exclude_low_trust_leader", ObservedOutcome: fmt.Sprintf("malicious_selections=%d", trustAwareMalicious),
			Passed: !eligible && trustAwareMalicious == 0, RejectedEvidence: roundRobinMalicious - trustAwareMalicious,
			Details: fmt.Sprintf("malicious_score=%.6f eligible=%v rounds=%d", score, eligible, rounds),
		},
		{
			Run: run, Ablation: "without_trust_aware_selection", Scenario: "repeated_malicious_leader",
			ExpectedOutcome: "round_robin_reselects_malicious_node", ObservedOutcome: fmt.Sprintf("malicious_selections=%d", roundRobinMalicious),
			Passed:  roundRobinMalicious > 0,
			Details: fmt.Sprintf("round_robin selections over %d rounds", rounds),
		},
	}, nil
}

func centralizedBaselineRow(run int, s *setup) (trialRow, error) {
	started := time.Now()
	const repetitions = 1000
	for index := 0; index < repetitions; index++ {
		if err := identity.VerifyAuthorizedCommand(s.basePublic, s.authorizedA, time.Now().UTC()); err != nil {
			return trialRow{}, err
		}
	}
	elapsed := float64(time.Since(started).Microseconds()) / 1000 / repetitions
	return trialRow{
		Run: run, Ablation: "internal_single_authority_baseline", Scenario: "normal_authorization",
		ExpectedOutcome: "fast_but_no_quorum_fault_tolerance", ObservedOutcome: "single_signature_verified",
		Passed: true, LatencyMS: elapsed,
		Details: "Internal architectural baseline only; not a substitute for an external published baseline.",
	}, nil
}

func writeTrials(path string, rows []trialRow) error {
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	header := []string{"run", "ablation", "scenario", "expected_outcome", "observed_outcome", "passed", "latency_ms", "success_rate_pct", "rejected_evidence", "details"}
	if err := writer.Write(header); err != nil {
		return err
	}
	for _, row := range rows {
		if err := writer.Write([]string{
			strconv.Itoa(row.Run), row.Ablation, row.Scenario, row.ExpectedOutcome, row.ObservedOutcome,
			strconv.FormatBool(row.Passed), fmt.Sprintf("%.6f", row.LatencyMS), fmt.Sprintf("%.6f", row.SuccessRatePct),
			strconv.Itoa(row.RejectedEvidence), row.Details,
		}); err != nil {
			return err
		}
	}
	return writer.Error()
}

func writeSummary(path string, rows []trialRow) error {
	type aggregate struct {
		count, passed int
		latency       float64
		successRate   float64
	}
	groups := make(map[string]*aggregate)
	for _, row := range rows {
		key := row.Ablation + "|" + row.Scenario
		group := groups[key]
		if group == nil {
			group = &aggregate{}
			groups[key] = group
		}
		group.count++
		if row.Passed {
			group.passed++
		}
		group.latency += row.LatencyMS
		group.successRate += row.SuccessRatePct
	}
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	if err := writer.Write([]string{"ablation", "scenario", "runs", "validated_runs", "validation_rate_pct", "mean_latency_ms", "mean_success_rate_pct"}); err != nil {
		return err
	}
	for key, group := range groups {
		parts := []rune(key)
		separator := -1
		for index, value := range parts {
			if value == '|' {
				separator = index
				break
			}
		}
		ablation := string(parts[:separator])
		scenario := string(parts[separator+1:])
		if err := writer.Write([]string{
			ablation, scenario, strconv.Itoa(group.count), strconv.Itoa(group.passed),
			fmt.Sprintf("%.3f", 100*float64(group.passed)/float64(group.count)),
			fmt.Sprintf("%.6f", group.latency/float64(group.count)),
			fmt.Sprintf("%.6f", group.successRate/float64(group.count)),
		}); err != nil {
			return err
		}
	}
	return writer.Error()
}

func main() {
	outputDir := flag.String("output-dir", "", "output directory")
	runs := flag.Int("runs", 3, "number of repeated ablation runs")
	flag.Parse()
	if *outputDir == "" || *runs < 1 {
		fmt.Fprintln(os.Stderr, "--output-dir is required and --runs must be >=1")
		os.Exit(2)
	}
	if err := os.MkdirAll(*outputDir, 0o755); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	startedAt := time.Now().UTC()
	rows := make([]trialRow, 0, *runs*9)
	for run := 1; run <= *runs; run++ {
		fixture, err := newSetup(10, 7, run)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(3)
		}
		authRows, err := authenticatedEnvelopeRows(run, fixture)
		if err != nil {
			fixture.close()
			fmt.Fprintln(os.Stderr, err)
			os.Exit(4)
		}
		rows = append(rows, authRows...)
		voteRows, err := persistentVoteRows(run, fixture)
		if err != nil {
			fixture.close()
			fmt.Fprintln(os.Stderr, err)
			os.Exit(5)
		}
		rows = append(rows, voteRows...)
		viewRows, err := viewChangeRows(run)
		if err != nil {
			fixture.close()
			fmt.Fprintln(os.Stderr, err)
			os.Exit(6)
		}
		rows = append(rows, viewRows...)
		trustRowsValue, err := trustRows(run)
		if err != nil {
			fixture.close()
			fmt.Fprintln(os.Stderr, err)
			os.Exit(7)
		}
		rows = append(rows, trustRowsValue...)
		baseline, err := centralizedBaselineRow(run, fixture)
		fixture.close()
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(8)
		}
		rows = append(rows, baseline)
	}

	trialsPath := filepath.Join(*outputDir, "go_ablation_trials.csv")
	summaryPath := filepath.Join(*outputDir, "go_ablation_summary.csv")
	if err := writeTrials(trialsPath, rows); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(9)
	}
	if err := writeSummary(summaryPath, rows); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(10)
	}
	validated := 0
	for _, row := range rows {
		if row.Passed {
			validated++
		}
	}
	record := completion{
		Runs: *runs, ExecutedRows: len(rows), ValidatedRows: validated,
		Success: validated == len(rows), StartedAt: startedAt.Format(time.RFC3339Nano),
		FinishedAt: time.Now().UTC().Format(time.RFC3339Nano), TrialsCSV: trialsPath, SummaryCSV: summaryPath,
		ImportantNotice: "The single-authority row is an internal architectural baseline. An exact external/published baseline must be implemented from its original specification or code before making literature-comparison claims.",
	}
	encoded, _ := json.MarshalIndent(record, "", "  ")
	if err := os.WriteFile(filepath.Join(*outputDir, "go_ablation_completion_summary.json"), append(encoded, '\n'), 0o644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(11)
	}
	fmt.Printf("GO ABLATION CAMPAIGN: %d/%d VALIDATED\n", validated, len(rows))
	if validated != len(rows) {
		os.Exit(1)
	}
}
