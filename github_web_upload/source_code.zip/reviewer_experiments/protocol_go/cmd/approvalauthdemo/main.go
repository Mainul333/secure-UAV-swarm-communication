package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

func main() {
	const (
		nodeCount = 4
		threshold = 3
	)

	ctx := context.Background()
	now := time.Now().UTC()

	result, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		panic(fmt.Errorf("run GJKR DKG: %w", err))
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	baseStationPublicKey, baseStationPrivateKey, err :=
		identity.GenerateKeyPair()
	if err != nil {
		panic(fmt.Errorf("generate base-station identity: %w", err))
	}

	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           50,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte("MOVE:X=5,Y=5,Z=-5"),
		Nonce:           []byte("0123456789ABCDEF"),
	}

	authorized, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		command,
		now,
	)
	if err != nil {
		panic(fmt.Errorf("authorize command: %w", err))
	}

	stateDirectory, err := os.MkdirTemp(
		"",
		"uav-bft-approval-auth-*",
	)
	if err != nil {
		panic(fmt.Errorf("create temporary state directory: %w", err))
	}
	defer os.RemoveAll(stateDirectory)

	signers := make(
		[]*thresholdprotocol.AuthenticatedFollowerSigner,
		threshold,
	)

	identityRegistry := make(
		map[uint32]ed25519.PublicKey,
		threshold,
	)

	stores := make([]*storage.VoteStore, 0, threshold)

	defer func() {
		for _, store := range stores {
			if err := store.Close(); err != nil {
				fmt.Fprintf(
					os.Stderr,
					"close vote store: %v\n",
					err,
				)
			}
		}
	}()

	for index := 0; index < threshold; index++ {
		store, err := storage.OpenVoteStore(
			filepath.Join(
				stateDirectory,
				fmt.Sprintf("node%d.db", index),
			),
		)
		if err != nil {
			panic(fmt.Errorf(
				"node %d open vote store: %w",
				index,
				err,
			))
		}

		stores = append(stores, store)

		follower, err :=
			thresholdprotocol.NewFollowerSigner(
				scheme,
				result.Shares[index].PriShare(),
				result.PublicPoly,
				store,
				baseStationPublicKey,
			)
		if err != nil {
			panic(fmt.Errorf(
				"node %d create follower signer: %w",
				index,
				err,
			))
		}

		identityPublicKey, identityPrivateKey, err :=
			identity.GenerateKeyPair()
		if err != nil {
			panic(fmt.Errorf(
				"node %d generate UAV identity: %w",
				index,
				err,
			))
		}

		authenticatedSigner, err :=
			thresholdprotocol.NewAuthenticatedFollowerSigner(
				follower,
				identityPrivateKey,
			)
		if err != nil {
			panic(fmt.Errorf(
				"node %d create authenticated signer: %w",
				index,
				err,
			))
		}

		signerID := authenticatedSigner.SignerID()

		signers[index] = authenticatedSigner
		identityRegistry[signerID] = identityPublicKey
	}

	viewZeroApprovals := make(
		[]wire.Approval,
		0,
		threshold,
	)

	for _, signer := range signers {
		approvalResult, err := signer.Approve(
			ctx,
			authorized,
			0,
			now,
		)
		if err != nil {
			panic(fmt.Errorf(
				"sign view-zero approval: %w",
				err,
			))
		}

		viewZeroApprovals = append(
			viewZeroApprovals,
			approvalResult.Approval,
		)
	}

	viewOneApprovals := make(
		[]wire.Approval,
		0,
		threshold,
	)

	for index, signer := range signers {
		approvalResult, err := signer.Approve(
			ctx,
			authorized,
			1,
			now,
		)
		if err != nil {
			panic(fmt.Errorf(
				"sign view-one approval: %w",
				err,
			))
		}

		if approvalResult.Created {
			panic(fmt.Sprintf(
				"node %d created a second BLS partial",
				index,
			))
		}

		if !bytes.Equal(
			viewZeroApprovals[index].PartialBLSSig,
			approvalResult.Approval.PartialBLSSig,
		) {
			panic(fmt.Sprintf(
				"node %d changed its stored BLS partial",
				index,
			))
		}

		if bytes.Equal(
			viewZeroApprovals[index].IdentitySig,
			approvalResult.Approval.IdentitySig,
		) {
			panic(fmt.Sprintf(
				"node %d reused its old-view identity envelope",
				index,
			))
		}

		viewOneApprovals = append(
			viewOneApprovals,
			approvalResult.Approval,
		)
	}

	certificate, err :=
		thresholdprotocol.RecoverAuthenticatedCertificate(
			scheme,
			result.PublicPoly,
			result.PublicKey,
			authorized,
			1,
			viewOneApprovals,
			identityRegistry,
			uint32(threshold),
			uint32(nodeCount),
		)
	if err != nil {
		panic(fmt.Errorf(
			"recover authenticated certificate: %w",
			err,
		))
	}

	fmt.Println("GJKR DKG: PASSED")
	fmt.Println("Base-station authorization: PASSED")
	fmt.Println("Persistent BLS-share reuse: PASSED")
	fmt.Println("New-view identity reauthentication: PASSED")
	fmt.Println("Leader identity-envelope verification: PASSED")
	fmt.Println("Threshold certificate reconstruction: PASSED")
	fmt.Println("Certificate view:", certificate.View)
	fmt.Println("Certificate signers:", certificate.SignerIDs)

	fmt.Printf(
		"Approval identity-signature size: %d bytes\n",
		len(viewOneApprovals[0].IdentitySig),
	)

	fmt.Printf(
		"Threshold partial-signature size: %d bytes\n",
		len(viewOneApprovals[0].PartialBLSSig),
	)

	fmt.Printf(
		"Recovered certificate size: %d bytes\n",
		len(certificate.ThresholdBLSSig),
	)
}
