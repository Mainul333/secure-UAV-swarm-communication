package main

import (
	"encoding/csv"
	"flag"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"uav-bft/internal/trust"
)

func parseSizes(value string) ([]int, error) {
	parts := strings.Split(value, ",")
	values := make([]int, 0, len(parts))
	for _, part := range parts {
		value, err := strconv.Atoi(strings.TrimSpace(part))
		if err != nil || value < 2 {
			return nil, fmt.Errorf("invalid size %q", part)
		}
		values = append(values, value)
	}
	return values, nil
}

func main() {
	var (
		sizesText    = flag.String("sizes", "4,10,20,50,100", "swarm sizes")
		seedCount    = flag.Int("seed-count", 10, "deterministic seeds")
		observations = flag.Int("observations", 100, "observations per node")
		output       = flag.String(
			"output",
			"results/trust_sensitivity.csv",
			"CSV output path",
		)
	)
	flag.Parse()

	if *seedCount <= 0 || *observations <= 0 {
		fmt.Fprintln(os.Stderr, "seed-count and observations must be positive")
		os.Exit(2)
	}
	sizes, err := parseSizes(*sizesText)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}

	if err := os.MkdirAll(filepath.Dir(*output), 0o755); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	file, err := os.Create(*output)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()

	header := []string{
		"n", "f", "t", "seed", "cutoff",
		"true_positive", "false_positive", "true_negative", "false_negative",
		"precision", "recall", "honest_eligible", "liveness_possible",
	}
	if err := writer.Write(header); err != nil {
		panic(err)
	}

	cutoffs := []float64{0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80}
	rowCount := 0

	for _, nodeCount := range sizes {
		faultBound := (nodeCount - 1) / 3
		threshold := nodeCount - faultBound
		members := make([]uint32, nodeCount)
		for index := range members {
			members[index] = uint32(index)
		}

		malicious := make(map[uint32]struct{}, faultBound)
		for offset := 0; offset < faultBound; offset++ {
			malicious[uint32(nodeCount-1-offset)] = struct{}{}
		}

		for seed := 1; seed <= *seedCount; seed++ {
			config := trust.DefaultConfig()
			tracker, err := trust.NewTracker(members, config)
			if err != nil {
				panic(err)
			}
			random := rand.New(rand.NewSource(int64(seed*1000 + nodeCount)))

			for observation := 0; observation < *observations; observation++ {
				for _, nodeID := range members {
					_, isMalicious := malicious[nodeID]
					successProbability := 0.95
					if isMalicious {
						successProbability = 0.30
					}
					if err := tracker.Observe(
						nodeID,
						random.Float64() < successProbability,
					); err != nil {
						panic(err)
					}
				}
			}

			results, err := trust.Sweep(
				tracker.Snapshot(),
				malicious,
				cutoffs,
			)
			if err != nil {
				panic(err)
			}

			for _, result := range results {
				livenessPossible := result.HonestEligible >= threshold
				record := []string{
					strconv.Itoa(nodeCount),
					strconv.Itoa(faultBound),
					strconv.Itoa(threshold),
					strconv.Itoa(seed),
					strconv.FormatFloat(result.Cutoff, 'f', 2, 64),
					strconv.Itoa(result.TruePositive),
					strconv.Itoa(result.FalsePositive),
					strconv.Itoa(result.TrueNegative),
					strconv.Itoa(result.FalseNegative),
					strconv.FormatFloat(result.Precision, 'f', 6, 64),
					strconv.FormatFloat(result.Recall, 'f', 6, 64),
					strconv.Itoa(result.HonestEligible),
					strconv.FormatBool(livenessPossible),
				}
				if err := writer.Write(record); err != nil {
					panic(err)
				}
				rowCount++
			}
		}
		fmt.Printf("Completed trust sweep n=%d, f=%d, t=%d\n", nodeCount, faultBound, threshold)
	}

	writer.Flush()
	if err := writer.Error(); err != nil {
		panic(err)
	}
	absolute, _ := filepath.Abs(*output)
	fmt.Println("Saved:", absolute)
	fmt.Println("Rows:", rowCount)
}
