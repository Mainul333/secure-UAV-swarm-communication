package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"time"

	"uav-bft/internal/transport"
	"uav-bft/internal/wire"
)

func main() {
	listen := flag.String("listen", "127.0.0.1:9100", "UDP listen address")
	nodeID := flag.Uint("id", 1, "UAV node ID")
	once := flag.Bool("once", false, "exit after one valid frame")
	flag.Parse()

	endpoint, err := transport.ListenUDP(*listen)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer endpoint.Close()
	fmt.Printf("UAV node %d listening on %s\n", *nodeID, endpoint.LocalAddr())

	for {
		ctx, cancel := context.WithTimeout(
			context.Background(),
			24*time.Hour,
		)
		frame, remote, err := endpoint.Receive(ctx)
		cancel()
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}

		var envelope wire.NetworkEnvelope
		if err := wire.DecodeCanonical(frame.Payload, &envelope); err != nil {
			fmt.Fprintln(os.Stderr, "decode envelope:", err)
			continue
		}
		if envelope.ReceiverID != uint32(*nodeID) {
			fmt.Fprintf(
				os.Stderr,
				"ignoring frame for node %d\n",
				envelope.ReceiverID,
			)
			continue
		}
		fmt.Printf(
			"received type=%d sender=%d sequence=%d payload=%q\n",
			envelope.Type,
			envelope.SenderID,
			envelope.Sequence,
			string(envelope.Payload),
		)

		ack := wire.NetworkEnvelope{
			Type:       wire.MessageTypeAcknowledgement,
			SenderID:   uint32(*nodeID),
			ReceiverID: envelope.SenderID,
			Sequence:   envelope.Sequence,
			Payload:    []byte("ACK"),
		}
		encoded, err := wire.CanonicalBytes(ack)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		ackContext, ackCancel := context.WithTimeout(
			context.Background(),
			3*time.Second,
		)
		err = endpoint.Send(
			ackContext,
			remote,
			transport.Frame{
				Type:       wire.MessageTypeAcknowledgement,
				SenderID:   uint32(*nodeID),
				ReceiverID: envelope.SenderID,
				Sequence:   envelope.Sequence,
				Payload:    encoded,
			},
		)
		ackCancel()
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}

		if *once {
			return
		}
	}
}
