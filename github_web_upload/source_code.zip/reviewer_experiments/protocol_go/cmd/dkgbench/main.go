package main

import (
	"crypto/sha256"
	"encoding/csv"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
)

func parseSizes(value string) ([]int, error) {
	parts := strings.Split(value, ",")
	values := make([]int, 0, len(parts))
	for _, part := range parts {
		parsed, err := strconv.Atoi(strings.TrimSpace(part))
		if err != nil || parsed < 2 {
			return nil, fmt.Errorf("invalid DKG size %q", part)
		}
		values = append(values, parsed)
	}
	return values, nil
}

func main() {
	sizesText := flag.String(
		"sizes",
		"4,10,20",
		"comma-separated DKG sizes",
	)
	runs := flag.Int("runs", 1, "runs per size")
	allowExpensive := flag.Bool(
		"allow-expensive",
		false,
		"permit n>20; this can take many minutes",
	)
	output := flag.String(
		"output",
		"results/dkg_small_benchmark.csv",
		"CSV output path",
	)
	flag.Parse()

	sizes, err := parseSizes(*sizesText)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if *runs <= 0 {
		fmt.Fprintln(os.Stderr, "runs must be positive")
		os.Exit(2)
	}
	for _, size := range sizes {
		if size > 20 && !*allowExpensive {
			fmt.Fprintf(
				os.Stderr,
				"refusing n=%d without -allow-expensive; saved n=50/100 results are not rerun\n",
				size,
			)
			os.Exit(2)
		}
	}

	if err := os.MkdirAll(filepath.Dir(*output), 0o755); err != nil {
		panic(err)
	}
	file, err := os.Create(*output)
	if err != nil {
		panic(err)
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()

	header := []string{
		"n", "f", "t", "run", "dkg_ms", "deal_objects",
		"response_objects", "response_deliveries",
		"secret_commit_deliveries", "partial_sign_verify_ms",
		"reconstruction_ms", "final_verification_ms",
		"partial_signature_bytes", "recovered_signature_bytes",
	}
	if err := writer.Write(header); err != nil {
		panic(err)
	}

	message := sha256.Sum256([]byte("UAV-BFT-DKG-BENCHMARK"))
	for _, nodeCount := range sizes {
		faultBound := (nodeCount - 1) / 3
		threshold := nodeCount - faultBound
		for run := 1; run <= *runs; run++ {
			result, err := dkg.RunHonest(nodeCount, threshold)
			if err != nil {
				panic(err)
			}
			scheme := tbls.NewThresholdSchemeOnG1(result.Suite)
			partials := make([][]byte, 0, threshold)

			partialStarted := time.Now()
			for index := 0; index < threshold; index++ {
				partial, err := scheme.Sign(
					result.Shares[index].PriShare(),
					message[:],
				)
				if err != nil {
					panic(err)
				}
				if err := scheme.VerifyPartial(
					result.PublicPoly,
					message[:],
					partial,
				); err != nil {
					panic(err)
				}
				partials = append(partials, partial)
			}
			partialDuration := time.Since(partialStarted)

			reconstructionStarted := time.Now()
			recovered, err := scheme.Recover(
				result.PublicPoly,
				message[:],
				partials,
				uint32(threshold),
				uint32(nodeCount),
			)
			if err != nil {
				panic(err)
			}
			reconstructionDuration := time.Since(reconstructionStarted)

			verificationStarted := time.Now()
			if err := scheme.VerifyRecovered(
				result.PublicKey,
				message[:],
				recovered,
			); err != nil {
				panic(err)
			}
			verificationDuration := time.Since(verificationStarted)

			record := []string{
				strconv.Itoa(nodeCount),
				strconv.Itoa(faultBound),
				strconv.Itoa(threshold),
				strconv.Itoa(run),
				strconv.FormatFloat(
					float64(result.Statistics.Duration)/float64(time.Millisecond),
					'f', 6, 64,
				),
				strconv.Itoa(result.Statistics.DealObjects),
				strconv.Itoa(result.Statistics.ResponseObjects),
				strconv.Itoa(result.Statistics.ResponseDeliveries),
				strconv.Itoa(result.Statistics.SecretCommitDeliveries),
				strconv.FormatFloat(
					float64(partialDuration)/float64(time.Millisecond),
					'f', 6, 64,
				),
				strconv.FormatFloat(
					float64(reconstructionDuration)/float64(time.Millisecond),
					'f', 6, 64,
				),
				strconv.FormatFloat(
					float64(verificationDuration)/float64(time.Millisecond),
					'f', 6, 64,
				),
				strconv.Itoa(len(partials[0])),
				strconv.Itoa(len(recovered)),
			}
			if err := writer.Write(record); err != nil {
				panic(err)
			}
			fmt.Printf(
				"n=%d t=%d run=%d DKG=%s PASSED\n",
				nodeCount,
				threshold,
				run,
				result.Statistics.Duration,
			)
		}
	}
	writer.Flush()
	if err := writer.Error(); err != nil {
		panic(err)
	}
	absolute, _ := filepath.Abs(*output)
	fmt.Println("Saved:", absolute)
}
