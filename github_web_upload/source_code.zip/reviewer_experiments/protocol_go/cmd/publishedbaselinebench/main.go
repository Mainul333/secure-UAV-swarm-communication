package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/binary"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"go.dedis.ch/kyber/v4"
	"go.dedis.ch/kyber/v4/group/edwards25519"
	"go.dedis.ch/kyber/v4/pairing/bls12381/kilic"
	"go.dedis.ch/kyber/v4/share"
	"go.dedis.ch/kyber/v4/sign/tbls"
)

const (
	methodProposed    = "proposed_threshold_bls"
	methodFHotStuff   = "wang_fhotstuff_frost_independent"
	methodPBFT        = "huo_inspired_authenticated_pbft"
	scenarioNormal    = "normal"
	scenarioLeader    = "leader_withholding"
	scenarioMalformed = "malformed_followers"
)

type config struct {
	Nodes        []int    `json:"nodes"`
	Trials       int      `json:"trials"`
	PayloadBytes int      `json:"payload_bytes"`
	BatchSize    int      `json:"batch_size"`
	TimeoutMS    float64  `json:"view_timeout_ms"`
	Scenarios    []string `json:"scenarios"`
	OutputDir    string   `json:"output_dir"`
	CreatedAtUTC string   `json:"created_at_utc"`
}

type trialRow struct {
	Method                 string
	Scenario               string
	Nodes                  int
	Threshold              int
	FaultyNodes            int
	Trial                  int
	Success                bool
	RejectedInvalid        int
	SetupMS                float64
	ProcessingMS           float64
	TimeoutMS              float64
	TotalLatencyMS         float64
	ApplicationMessages    uint64
	NetworkDeliveries      uint64
	NetworkBytes           uint64
	VoteOrApprovalBytes    int
	CertificateBytesActual int
	CertificateBytesPaper  int
	SignatureOperations    uint64
	VerificationOperations uint64
	PayloadBytes           int
	BatchSize              int
	DigestHex              string
	ImplementationNote     string
}

type methodResult struct {
	Success                bool
	RejectedInvalid        int
	SetupDuration          time.Duration
	ProcessingDuration     time.Duration
	ApplicationMessages    uint64
	NetworkDeliveries      uint64
	NetworkBytes           uint64
	VoteOrApprovalBytes    int
	CertificateBytesActual int
	CertificateBytesPaper  int
	SignatureOperations    uint64
	VerificationOperations uint64
	DigestHex              string
	ImplementationNote     string
}

type proposedSetup struct {
	suite        *kilic.SuiteBLS12381
	priPoly      *share.PriPoly
	pubPoly      *share.PubPoly
	shares       []*share.PriShare
	groupPublic  kyber.Point
	identityPub  []ed25519.PublicKey
	identityPriv []ed25519.PrivateKey
	bsPub        ed25519.PublicKey
	bsPriv       ed25519.PrivateKey
	setup        time.Duration
}

type frostSetup struct {
	suite       *edwards25519.SuiteEd25519
	priPoly     *share.PriPoly
	pubPoly     *share.PubPoly
	shares      []*share.PriShare
	groupPublic kyber.Point
	setup       time.Duration
}

type pbftSetup struct {
	pub   []ed25519.PublicKey
	priv  []ed25519.PrivateKey
	setup time.Duration
}

type frostCommitment struct {
	index uint32
	d     kyber.Scalar
	e     kyber.Scalar
	D     kyber.Point
	E     kyber.Point
	rho   kyber.Scalar
	R     kyber.Point
}

func main() {
	nodesArg := flag.String("nodes", "4,10,20,50,100", "comma-separated node counts")
	trials := flag.Int("trials", 3, "number of repetitions per condition")
	payloadBytes := flag.Int("payload-bytes", 1000, "command/transaction payload size")
	batchSize := flag.Int("batch-size", 128, "transactions per consensus batch for metadata")
	timeoutMS := flag.Float64("view-timeout-ms", 5000, "configured leader-failure timeout")
	scenariosArg := flag.String("scenarios", "normal,leader_withholding,malformed_followers", "comma-separated scenarios")
	outputDir := flag.String("output-dir", "results/processed/published_baseline_comparison", "output directory")
	flag.Parse()

	nodes, err := parsePositiveInts(*nodesArg)
	must(err)
	if *trials < 1 {
		fatalf("trials must be positive")
	}
	if *payloadBytes < 1 {
		fatalf("payload-bytes must be positive")
	}
	if *batchSize < 1 {
		fatalf("batch-size must be positive")
	}
	scenarios, err := parseScenarios(*scenariosArg)
	must(err)

	absOut, err := filepath.Abs(*outputDir)
	must(err)
	must(os.MkdirAll(absOut, 0o755))

	cfg := config{
		Nodes:        nodes,
		Trials:       *trials,
		PayloadBytes: *payloadBytes,
		BatchSize:    *batchSize,
		TimeoutMS:    *timeoutMS,
		Scenarios:    scenarios,
		OutputDir:    absOut,
		CreatedAtUTC: time.Now().UTC().Format(time.RFC3339Nano),
	}
	writeJSON(filepath.Join(absOut, "baseline_benchmark_config.json"), cfg)

	trialPath := filepath.Join(absOut, "published_baseline_trials.csv")
	file, err := os.Create(trialPath)
	must(err)
	defer file.Close()
	writer := csv.NewWriter(file)
	defer writer.Flush()
	must(writer.Write([]string{
		"method", "scenario", "nodes", "threshold", "faulty_nodes", "trial", "success",
		"rejected_invalid", "setup_ms", "processing_ms", "timeout_ms", "total_latency_ms",
		"application_messages", "network_deliveries", "network_bytes", "vote_or_approval_bytes",
		"certificate_bytes_actual", "certificate_bytes_paper", "signature_operations",
		"verification_operations", "payload_bytes", "batch_size", "digest_hex", "implementation_note",
	}))

	for _, n := range nodes {
		if n < 4 {
			fatalf("node count %d is below the BFT minimum 4", n)
		}
		t := thresholdFor(n)
		f := (n - 1) / 3
		fmt.Printf("Preparing n=%d threshold=%d faulty=%d ...\n", n, t, f)

		proposed, err := newProposedSetup(n, t)
		if err != nil {
			fatalf("prepare proposed n=%d: %v", n, err)
		}
		frost, err := newFrostSetup(n, t)
		if err != nil {
			fatalf("prepare FHotStuff n=%d: %v", n, err)
		}
		pbft, err := newPBFTSetup(n)
		if err != nil {
			fatalf("prepare PBFT n=%d: %v", n, err)
		}

		for _, scenario := range scenarios {
			for trial := 1; trial <= *trials; trial++ {
				payload := deterministicPayload(n, trial, scenario, *payloadBytes)
				results := []struct {
					method string
					result methodResult
					err    error
				}{
					{methodProposed, runProposed(proposed, n, t, f, scenario, payload), nil},
					{methodFHotStuff, runFHotStuff(frost, n, t, f, scenario, payload), nil},
					{methodPBFT, runPBFT(pbft, n, t, f, scenario, payload), nil},
				}

				for _, item := range results {
					if item.err != nil {
						fatalf("%s n=%d scenario=%s trial=%d: %v", item.method, n, scenario, trial, item.err)
					}
					timeout := 0.0
					if scenario == scenarioLeader {
						timeout = *timeoutMS
					}
					row := trialRow{
						Method:                 item.method,
						Scenario:               scenario,
						Nodes:                  n,
						Threshold:              t,
						FaultyNodes:            f,
						Trial:                  trial,
						Success:                item.result.Success,
						RejectedInvalid:        item.result.RejectedInvalid,
						SetupMS:                durationMS(item.result.SetupDuration),
						ProcessingMS:           durationMS(item.result.ProcessingDuration),
						TimeoutMS:              timeout,
						TotalLatencyMS:         durationMS(item.result.ProcessingDuration) + timeout,
						ApplicationMessages:    item.result.ApplicationMessages,
						NetworkDeliveries:      item.result.NetworkDeliveries,
						NetworkBytes:           item.result.NetworkBytes,
						VoteOrApprovalBytes:    item.result.VoteOrApprovalBytes,
						CertificateBytesActual: item.result.CertificateBytesActual,
						CertificateBytesPaper:  item.result.CertificateBytesPaper,
						SignatureOperations:    item.result.SignatureOperations,
						VerificationOperations: item.result.VerificationOperations,
						PayloadBytes:           *payloadBytes,
						BatchSize:              *batchSize,
						DigestHex:              item.result.DigestHex,
						ImplementationNote:     item.result.ImplementationNote,
					}
					must(writeTrial(writer, row))
					writer.Flush()
					if err := writer.Error(); err != nil {
						fatalf("write trial CSV: %v", err)
					}
					fmt.Printf("  %-38s %-20s trial=%d success=%t processing=%.3f ms bytes=%d\n",
						item.method, scenario, trial, row.Success, row.ProcessingMS, row.NetworkBytes)
				}
			}
		}
	}

	manifest := map[string]any{
		"status":    "PASSED",
		"trial_csv": trialPath,
		"methods":   []string{methodProposed, methodFHotStuff, methodPBFT},
		"important_limitations": []string{
			"FHotStuff is an independent implementation from the paper specification, not the authors' official code.",
			"Huo et al. do not provide complete PBFT implementation details; the package uses standard authenticated PBFT under their stated sub-one-third Byzantine assumption.",
			"Per-command measurements exclude distributed key generation, matching Wang et al.'s computational-latency methodology.",
			"Wire-byte accounting uses the same payload and explicit message-delivery model for all methods; FHotStuff paper-format signature sizes are reported separately from actual in-memory encodings.",
		},
		"finished_at_utc": time.Now().UTC().Format(time.RFC3339Nano),
	}
	writeJSON(filepath.Join(absOut, "published_baseline_completion.json"), manifest)
	fmt.Println("PUBLISHED BASELINE PROTOCOL CAMPAIGN: PASSED")
	fmt.Println("Results:", absOut)
}

func thresholdFor(n int) int {
	return (2*n)/3 + 1
}

func parsePositiveInts(value string) ([]int, error) {
	seen := map[int]struct{}{}
	var out []int
	for _, token := range strings.Split(value, ",") {
		token = strings.TrimSpace(token)
		if token == "" {
			continue
		}
		v, err := strconv.Atoi(token)
		if err != nil || v <= 0 {
			return nil, fmt.Errorf("invalid positive integer %q", token)
		}
		if _, ok := seen[v]; !ok {
			seen[v] = struct{}{}
			out = append(out, v)
		}
	}
	if len(out) == 0 {
		return nil, errors.New("no node counts supplied")
	}
	sort.Ints(out)
	return out, nil
}

func parseScenarios(value string) ([]string, error) {
	allowed := map[string]bool{
		scenarioNormal:    true,
		scenarioLeader:    true,
		scenarioMalformed: true,
	}
	seen := map[string]struct{}{}
	var out []string
	for _, token := range strings.Split(value, ",") {
		token = strings.TrimSpace(strings.ToLower(token))
		if token == "" {
			continue
		}
		if !allowed[token] {
			return nil, fmt.Errorf("unsupported scenario %q", token)
		}
		if _, ok := seen[token]; !ok {
			seen[token] = struct{}{}
			out = append(out, token)
		}
	}
	if len(out) == 0 {
		return nil, errors.New("no scenarios supplied")
	}
	return out, nil
}

func deterministicPayload(n, trial int, scenario string, size int) []byte {
	seed := sha512.Sum512([]byte(fmt.Sprintf("UAV-BASELINE|n=%d|trial=%d|scenario=%s", n, trial, scenario)))
	payload := make([]byte, size)
	for i := range payload {
		payload[i] = seed[i%len(seed)] ^ byte(i*31+trial)
	}
	return payload
}

func newProposedSetup(n, t int) (*proposedSetup, error) {
	started := time.Now()
	suite := kilic.NewSuiteBLS12381()
	pri := share.NewPriPoly(suite, uint32(t), nil, suite.RandomStream())
	pub := pri.Commit(nil)
	shares := pri.Shares(uint32(n))
	identityPub := make([]ed25519.PublicKey, n)
	identityPriv := make([]ed25519.PrivateKey, n)
	for i := 0; i < n; i++ {
		pubKey, privKey, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
		identityPub[i], identityPriv[i] = pubKey, privKey
	}
	bsPub, bsPriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	return &proposedSetup{
		suite: suite, priPoly: pri, pubPoly: pub, shares: shares,
		groupPublic: pub.Commit(), identityPub: identityPub, identityPriv: identityPriv,
		bsPub: bsPub, bsPriv: bsPriv, setup: time.Since(started),
	}, nil
}

func newFrostSetup(n, t int) (*frostSetup, error) {
	started := time.Now()
	suite := edwards25519.NewBlakeSHA256Ed25519()
	pri := share.NewPriPoly(suite, uint32(t), nil, suite.RandomStream())
	pub := pri.Commit(nil)
	return &frostSetup{
		suite: suite, priPoly: pri, pubPoly: pub,
		shares: pri.Shares(uint32(n)), groupPublic: pub.Commit(), setup: time.Since(started),
	}, nil
}

func newPBFTSetup(n int) (*pbftSetup, error) {
	started := time.Now()
	pub := make([]ed25519.PublicKey, n)
	priv := make([]ed25519.PrivateKey, n)
	for i := 0; i < n; i++ {
		p, s, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
		pub[i], priv[i] = p, s
	}
	return &pbftSetup{pub: pub, priv: priv, setup: time.Since(started)}, nil
}

func runProposed(setup *proposedSetup, n, t, f int, scenario string, payload []byte) methodResult {
	message := sha256.Sum256(payload)
	scheme := tbls.NewThresholdSchemeOnG1(setup.suite)
	activeFaults := 0
	if scenario == scenarioMalformed {
		activeFaults = f
	}
	signerIDs := honestSignerIDs(n, t, activeFaults)
	started := time.Now()
	result := methodResult{Success: true, SetupDuration: setup.setup, DigestHex: hex.EncodeToString(message[:])}

	bsSig := ed25519.Sign(setup.bsPriv, message[:])
	result.SignatureOperations++
	for _, id := range signerIDs {
		if !ed25519.Verify(setup.bsPub, message[:], bsSig) {
			result.Success = false
		}
		result.VerificationOperations++
		_ = id
	}

	leaderEnvelope := append([]byte("PROPOSAL"), message[:]...)
	leaderSig := ed25519.Sign(setup.identityPriv[0], leaderEnvelope)
	result.SignatureOperations++
	if !ed25519.Verify(setup.identityPub[0], leaderEnvelope, leaderSig) {
		result.Success = false
	}
	result.VerificationOperations++

	if scenario == scenarioMalformed && f > 0 {
		for i := 0; i < f; i++ {
			bad := make([]byte, 32)
			_, _ = rand.Read(bad)
			if err := scheme.VerifyPartial(setup.pubPoly, message[:], bad); err != nil {
				result.RejectedInvalid++
			}
			result.VerificationOperations++
		}
	}

	partials := make([][]byte, 0, t)
	for _, id := range signerIDs {
		partial, err := scheme.Sign(setup.shares[id], message[:])
		if err != nil {
			result.Success = false
			continue
		}
		result.SignatureOperations++
		if err := scheme.VerifyPartial(setup.pubPoly, message[:], partial); err != nil {
			result.Success = false
		}
		result.VerificationOperations++
		envelope := append(append([]byte("APPROVAL"), message[:]...), partial...)
		identitySig := ed25519.Sign(setup.identityPriv[id], envelope)
		result.SignatureOperations++
		if !ed25519.Verify(setup.identityPub[id], envelope, identitySig) {
			result.Success = false
		}
		result.VerificationOperations++
		partials = append(partials, partial)
	}

	recovered, err := scheme.Recover(setup.pubPoly, message[:], partials, uint32(t), uint32(n))
	if err != nil {
		result.Success = false
	}
	if err == nil {
		if err := scheme.VerifyRecovered(setup.groupPublic, message[:], recovered); err != nil {
			result.Success = false
		}
		result.VerificationOperations++
		result.CertificateBytesActual = len(recovered) + 4*t + 56
	}
	if scenario == scenarioLeader {
		viewMessage := append([]byte("VIEW-CHANGE"), message[:]...)
		for _, id := range signerIDs {
			sig := ed25519.Sign(setup.identityPriv[id], viewMessage)
			result.SignatureOperations++
			if !ed25519.Verify(setup.identityPub[id], viewMessage, sig) {
				result.Success = false
			}
			result.VerificationOperations++
		}
	}
	result.ProcessingDuration = time.Since(started)

	partialLen := 0
	if len(partials) > 0 {
		partialLen = len(partials[0])
	}
	approvalBytes := partialLen + ed25519.SignatureSize + 32 + 32
	proposalBytes := len(payload) + len(bsSig) + len(leaderSig) + 96
	certificateBytes := result.CertificateBytesActual
	result.VoteOrApprovalBytes = approvalBytes
	result.CertificateBytesPaper = certificateBytes
	result.ApplicationMessages = uint64(2 + t)
	result.NetworkDeliveries = uint64(2*(n-1) + t)
	result.NetworkBytes = uint64(proposalBytes*(n-1) + approvalBytes*t + certificateBytes*(n-1))
	if scenario == scenarioLeader {
		viewChangeBytes := 32 + ed25519.SignatureSize + 32
		result.ApplicationMessages += uint64(t)
		result.NetworkDeliveries += uint64(t)
		result.NetworkBytes += uint64(viewChangeBytes * t)
	}
	if scenario == scenarioMalformed {
		result.ApplicationMessages += uint64(f)
		result.NetworkDeliveries += uint64(f)
		result.NetworkBytes += uint64(approvalBytes * f)
	}
	result.ImplementationNote = "Existing threshold-BLS primitive with dealer-generated shares for per-command comparison; includes BS authorization, UAV identity envelopes, partial verification, recovery, and final verification. Full GJKR DKG is intentionally excluded from per-command latency."
	return result
}

func runFHotStuff(setup *frostSetup, n, t, f int, scenario string, payload []byte) methodResult {
	message := sha512.Sum512(payload)
	activeFaults := 0
	if scenario == scenarioMalformed {
		activeFaults = f
	}
	signerIDs := honestSignerIDs(n, t, activeFaults)
	started := time.Now()
	result := methodResult{Success: true, SetupDuration: setup.setup, DigestHex: hex.EncodeToString(message[:])}
	current := message[:]
	for phase := 0; phase < 3; phase++ {
		phaseMessage := sha512.Sum512(append(append([]byte{}, current...), byte(phase)))
		malformedCount := 0
		if scenario == scenarioMalformed && phase == 0 {
			malformedCount = f
		}
		ok, rejected, sigOps, verifyOps, actualBytes := frostRound(setup, signerIDs, phaseMessage[:], malformedCount)
		result.RejectedInvalid += rejected
		result.SignatureOperations += sigOps
		result.VerificationOperations += verifyOps
		if !ok {
			result.Success = false
		}
		result.CertificateBytesActual = actualBytes
		current = phaseMessage[:]
	}
	result.ProcessingDuration = time.Since(started)

	paperVoteBytes := 33
	paperQCBytes := 32 + t
	proposalBaseBytes := len(payload) + 80
	var networkBytes uint64
	var deliveries uint64
	for phase := 0; phase < 3; phase++ {
		qcBytes := 0
		if phase > 0 {
			qcBytes = paperQCBytes
		}
		networkBytes += uint64((proposalBaseBytes + qcBytes) * (n - 1))
		networkBytes += uint64(paperVoteBytes * t)
		deliveries += uint64((n - 1) + t)
	}
	result.ApplicationMessages = uint64(3 + 3*t)
	result.NetworkDeliveries = deliveries
	result.NetworkBytes = networkBytes
	result.VoteOrApprovalBytes = paperVoteBytes
	result.CertificateBytesPaper = paperQCBytes
	if scenario == scenarioLeader {
		newViewBytes := paperQCBytes + 48
		result.ApplicationMessages += uint64(t)
		result.NetworkDeliveries += uint64(t)
		result.NetworkBytes += uint64(newViewBytes * t)
	}
	if scenario == scenarioMalformed {
		result.ApplicationMessages += uint64(f)
		result.NetworkDeliveries += uint64(f)
		result.NetworkBytes += uint64(paperVoteBytes * f)
	}
	result.ImplementationNote = "Independent FHotStuff/FROST implementation from Wang et al.: Edwards25519 group, SHA-512 binding/challenge hashes, precomputed two-nonce commitments, threshold Schnorr shares, three chained proposal-vote rounds, and paper-format 33-byte votes / (32+t)-byte QC accounting. Not authors' official code."
	return result
}

func frostRound(setup *frostSetup, signerIDs []int, message []byte, malformedCount int) (bool, int, uint64, uint64, int) {
	commitments := make([]frostCommitment, 0, len(signerIDs))
	commitmentBlob := make([]byte, 0, len(signerIDs)*68)
	for _, id := range signerIDs {
		d := setup.suite.Scalar().Pick(setup.suite.RandomStream())
		e := setup.suite.Scalar().Pick(setup.suite.RandomStream())
		D := setup.suite.Point().Mul(d, nil)
		E := setup.suite.Point().Mul(e, nil)
		Db, _ := D.MarshalBinary()
		Eb, _ := E.MarshalBinary()
		var idBytes [4]byte
		binary.LittleEndian.PutUint32(idBytes[:], uint32(id))
		commitmentBlob = append(commitmentBlob, idBytes[:]...)
		commitmentBlob = append(commitmentBlob, Db...)
		commitmentBlob = append(commitmentBlob, Eb...)
		commitments = append(commitments, frostCommitment{index: uint32(id), d: d, e: e, D: D, E: E})
	}

	R := setup.suite.Point().Null()
	for i := range commitments {
		commitments[i].rho = hashToScalar(setup.suite, "FROST-RHO", uint32(commitments[i].index), message, commitmentBlob)
		rhoE := setup.suite.Point().Mul(commitments[i].rho, commitments[i].E)
		commitments[i].R = setup.suite.Point().Add(commitments[i].D, rhoE)
		R = setup.suite.Point().Add(R, commitments[i].R)
	}
	Rb, _ := R.MarshalBinary()
	Yb, _ := setup.groupPublic.MarshalBinary()
	challenge := hashToScalar(setup.suite, "FROST-CHALLENGE", 0, message, Rb, Yb)

	zTotal := setup.suite.Scalar().Zero()
	ok := true
	rejected := 0
	var sigOps uint64
	var verifyOps uint64
	for i := range commitments {
		id := int(commitments[i].index)
		lambda := lagrangeAtZero(setup.suite, commitments[i].index, signerIDs)
		rhoE := setup.suite.Scalar().Mul(commitments[i].rho, commitments[i].e)
		lambdaShare := setup.suite.Scalar().Mul(lambda, setup.shares[id].V)
		lambdaShareChallenge := setup.suite.Scalar().Mul(lambdaShare, challenge)
		z := setup.suite.Scalar().Add(commitments[i].d, rhoE)
		z = setup.suite.Scalar().Add(z, lambdaShareChallenge)
		sigOps++

		left := setup.suite.Point().Mul(z, nil)
		publicShare := setup.pubPoly.Eval(uint32(id)).V
		rightTermScalar := setup.suite.Scalar().Mul(lambda, challenge)
		rightTerm := setup.suite.Point().Mul(rightTermScalar, publicShare)
		right := setup.suite.Point().Add(commitments[i].R, rightTerm)
		verifyOps++
		if !left.Equal(right) {
			ok = false
		}
		zTotal = setup.suite.Scalar().Add(zTotal, z)
	}

	for i := 0; i < malformedCount; i++ {
		badZ := setup.suite.Scalar().Pick(setup.suite.RandomStream())
		left := setup.suite.Point().Mul(badZ, nil)
		reference := commitments[i%len(commitments)].R
		if !left.Equal(reference) {
			rejected++
		}
		verifyOps++
	}

	left := setup.suite.Point().Mul(zTotal, nil)
	right := setup.suite.Point().Add(R, setup.suite.Point().Mul(challenge, setup.groupPublic))
	verifyOps++
	if !left.Equal(right) {
		ok = false
	}
	actualBytes := len(Rb) + setup.suite.ScalarLen()
	return ok, rejected, sigOps, verifyOps, actualBytes
}

func hashToScalar(suite *edwards25519.SuiteEd25519, domain string, id uint32, parts ...[]byte) kyber.Scalar {
	h := sha512.New()
	h.Write([]byte(domain))
	var idBytes [4]byte
	binary.LittleEndian.PutUint32(idBytes[:], id)
	h.Write(idBytes[:])
	for _, part := range parts {
		var length [8]byte
		binary.LittleEndian.PutUint64(length[:], uint64(len(part)))
		h.Write(length[:])
		h.Write(part)
	}
	return suite.Scalar().SetBytes(h.Sum(nil))
}

func lagrangeAtZero(suite *edwards25519.SuiteEd25519, signer uint32, signerIDs []int) kyber.Scalar {
	xi := suite.Scalar().SetInt64(int64(signer + 1))
	numerator := suite.Scalar().One()
	denominator := suite.Scalar().One()
	for _, id := range signerIDs {
		if uint32(id) == signer {
			continue
		}
		xj := suite.Scalar().SetInt64(int64(id + 1))
		numerator = suite.Scalar().Mul(numerator, xj)
		difference := suite.Scalar().Sub(xj, xi)
		denominator = suite.Scalar().Mul(denominator, difference)
	}
	return suite.Scalar().Div(numerator, denominator)
}

func runPBFT(setup *pbftSetup, n, t, f int, scenario string, payload []byte) methodResult {
	digest := sha256.Sum256(payload)
	started := time.Now()
	result := methodResult{Success: true, SetupDuration: setup.setup, DigestHex: hex.EncodeToString(digest[:])}

	preprepare := append([]byte("PREPREPARE"), digest[:]...)
	leaderSig := ed25519.Sign(setup.priv[0], preprepare)
	result.SignatureOperations++
	for receiver := 1; receiver < n; receiver++ {
		if !ed25519.Verify(setup.pub[0], preprepare, leaderSig) {
			result.Success = false
		}
		result.VerificationOperations++
	}

	prepareMessages := make([][]byte, n)
	prepareSigs := make([][]byte, n)
	for sender := 0; sender < n; sender++ {
		prepareMessages[sender] = append(append([]byte("PREPARE"), byte(sender)), digest[:]...)
		prepareSigs[sender] = ed25519.Sign(setup.priv[sender], prepareMessages[sender])
		result.SignatureOperations++
	}
	for receiver := 0; receiver < n; receiver++ {
		for sender := 0; sender < n; sender++ {
			if sender == receiver {
				continue
			}
			if !ed25519.Verify(setup.pub[sender], prepareMessages[sender], prepareSigs[sender]) {
				result.Success = false
			}
			result.VerificationOperations++
		}
	}

	commitMessages := make([][]byte, n)
	commitSigs := make([][]byte, n)
	for sender := 0; sender < n; sender++ {
		commitMessages[sender] = append(append([]byte("COMMIT"), byte(sender)), digest[:]...)
		commitSigs[sender] = ed25519.Sign(setup.priv[sender], commitMessages[sender])
		result.SignatureOperations++
	}
	for receiver := 0; receiver < n; receiver++ {
		for sender := 0; sender < n; sender++ {
			if sender == receiver {
				continue
			}
			if !ed25519.Verify(setup.pub[sender], commitMessages[sender], commitSigs[sender]) {
				result.Success = false
			}
			result.VerificationOperations++
		}
	}

	if scenario == scenarioMalformed && f > 0 {
		wrong := sha256.Sum256(append([]byte("CONFLICT"), payload...))
		for i := 0; i < f; i++ {
			sender := n - 1 - i
			badMessage := append(append([]byte("PREPARE"), byte(sender)), wrong[:]...)
			badSig := ed25519.Sign(setup.priv[sender], badMessage)
			result.SignatureOperations++
			if !ed25519.Verify(setup.pub[sender], prepareMessages[sender], badSig) {
				result.RejectedInvalid++
			}
			result.VerificationOperations++
		}
	}

	if scenario == scenarioLeader {
		viewMessage := append([]byte("VIEW-CHANGE"), digest[:]...)
		viewSigs := make([][]byte, n)
		for sender := 0; sender < n; sender++ {
			viewSigs[sender] = ed25519.Sign(setup.priv[sender], viewMessage)
			result.SignatureOperations++
		}
		for sender := 0; sender < n; sender++ {
			if !ed25519.Verify(setup.pub[sender], viewMessage, viewSigs[sender]) {
				result.Success = false
			}
			result.VerificationOperations++
		}
		newView := append([]byte("NEW-VIEW"), digest[:]...)
		newViewSig := ed25519.Sign(setup.priv[1%n], newView)
		result.SignatureOperations++
		for receiver := 0; receiver < n; receiver++ {
			if receiver == 1%n {
				continue
			}
			if !ed25519.Verify(setup.pub[1%n], newView, newViewSig) {
				result.Success = false
			}
			result.VerificationOperations++
		}
	}

	result.ProcessingDuration = time.Since(started)
	preprepareBytes := len(payload) + ed25519.SignatureSize + 48
	phaseMessageBytes := 32 + ed25519.SignatureSize + 32
	result.ApplicationMessages = uint64(1 + 2*n)
	result.NetworkDeliveries = uint64((n - 1) + 2*n*(n-1))
	result.NetworkBytes = uint64(preprepareBytes*(n-1) + 2*phaseMessageBytes*n*(n-1))
	result.VoteOrApprovalBytes = phaseMessageBytes
	result.CertificateBytesActual = t * (ed25519.SignatureSize + 4)
	result.CertificateBytesPaper = result.CertificateBytesActual
	if scenario == scenarioLeader {
		viewChangeBytes := 32 + ed25519.SignatureSize + 32
		newViewBytes := viewChangeBytes + t*(ed25519.SignatureSize+4)
		result.ApplicationMessages += uint64(n + 1)
		result.NetworkDeliveries += uint64(n + (n - 1))
		result.NetworkBytes += uint64(viewChangeBytes*n + newViewBytes*(n-1))
	}
	if scenario == scenarioMalformed {
		result.ApplicationMessages += uint64(f)
		result.NetworkDeliveries += uint64(f)
		result.NetworkBytes += uint64(phaseMessageBytes * f)
	}
	result.ImplementationNote = "Standard authenticated PBFT (PRE-PREPARE, all-to-all PREPARE, all-to-all COMMIT) used as a Huo-inspired baseline because the uploaded paper does not specify complete message formats, authentication, quorum certificates, or view-change code."
	return result
}

func honestSignerIDs(n, t, f int) []int {
	start := 0
	if n-f >= t {
		start = f
	}
	ids := make([]int, 0, t)
	for i := start; i < n && len(ids) < t; i++ {
		ids = append(ids, i)
	}
	if len(ids) < t {
		for i := 0; i < start && len(ids) < t; i++ {
			ids = append(ids, i)
		}
	}
	return ids
}

func durationMS(value time.Duration) float64 {
	return float64(value.Nanoseconds()) / 1e6
}

func writeTrial(writer *csv.Writer, row trialRow) error {
	return writer.Write([]string{
		row.Method,
		row.Scenario,
		strconv.Itoa(row.Nodes),
		strconv.Itoa(row.Threshold),
		strconv.Itoa(row.FaultyNodes),
		strconv.Itoa(row.Trial),
		strconv.FormatBool(row.Success),
		strconv.Itoa(row.RejectedInvalid),
		formatFloat(row.SetupMS),
		formatFloat(row.ProcessingMS),
		formatFloat(row.TimeoutMS),
		formatFloat(row.TotalLatencyMS),
		strconv.FormatUint(row.ApplicationMessages, 10),
		strconv.FormatUint(row.NetworkDeliveries, 10),
		strconv.FormatUint(row.NetworkBytes, 10),
		strconv.Itoa(row.VoteOrApprovalBytes),
		strconv.Itoa(row.CertificateBytesActual),
		strconv.Itoa(row.CertificateBytesPaper),
		strconv.FormatUint(row.SignatureOperations, 10),
		strconv.FormatUint(row.VerificationOperations, 10),
		strconv.Itoa(row.PayloadBytes),
		strconv.Itoa(row.BatchSize),
		row.DigestHex,
		row.ImplementationNote,
	})
}

func formatFloat(value float64) string {
	if math.IsNaN(value) || math.IsInf(value, 0) {
		return ""
	}
	return strconv.FormatFloat(value, 'f', 6, 64)
}

func writeJSON(path string, value any) {
	data, err := json.MarshalIndent(value, "", "  ")
	must(err)
	data = append(data, '\n')
	must(os.WriteFile(path, data, 0o644))
}

func must(err error) {
	if err != nil {
		fatalf("%v", err)
	}
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "ERROR: "+format+"\n", args...)
	os.Exit(1)
}
