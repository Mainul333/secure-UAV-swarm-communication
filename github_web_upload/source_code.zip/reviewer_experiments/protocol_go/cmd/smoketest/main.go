package main

import (
	"fmt"

	"github.com/fxamacker/cbor/v2"
	"go.dedis.ch/kyber/v4/pairing/bls12381/kilic"
	"go.dedis.ch/kyber/v4/suites"

	_ "modernc.org/sqlite"
)

type TestMessage struct {
	Epoch uint64 `cbor:"1,keyasint"`
	Round uint64 `cbor:"2,keyasint"`
	Text  string `cbor:"3,keyasint"`
}

func main() {
	// Suite for identity/DKG development.
	dkgSuite := suites.MustFind("Ed25519")

	// Pairing suite for BLS12-381 threshold signatures.
	blsSuite := kilic.NewBLS12381Suite()

	encodingOptions := cbor.CanonicalEncOptions()
	encodingMode, err := encodingOptions.EncMode()
	if err != nil {
		panic(err)
	}

	message := TestMessage{
		Epoch: 1,
		Round: 1,
		Text:  "UAV-BFT smoke test",
	}

	encoded, err := encodingMode.Marshal(message)
	if err != nil {
		panic(err)
	}

	fmt.Println("Go dependencies are working.")
	fmt.Println("DKG suite:", dkgSuite.String())
	fmt.Println("BLS G1 point size:", blsSuite.G1().PointLen(), "bytes")
	fmt.Println("BLS G2 point size:", blsSuite.G2().PointLen(), "bytes")
	fmt.Println("Canonical message size:", len(encoded), "bytes")
}
