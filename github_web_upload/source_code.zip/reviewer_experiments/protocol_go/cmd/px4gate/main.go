package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

type authorizationRecord struct {
	Authorized               bool     `json:"authorized"`
	Scenario                 string   `json:"scenario"`
	NodeCount                int      `json:"node_count"`
	Threshold                int      `json:"threshold"`
	TargetSystemIDs          []uint32 `json:"target_system_ids"`
	TakeoffAltitudeM         float64  `json:"takeoff_altitude_m"`
	CertificateView          *uint64  `json:"certificate_view"`
	SignerIDs                []uint32 `json:"signer_ids,omitempty"`
	ViewTimeoutMS            float64  `json:"view_timeout_ms"`
	ViewChangeDelayMS        float64  `json:"view_change_delay_ms"`
	AuthorizationLatencyMS   float64  `json:"authorization_latency_ms"`
	WithheldCertificateBytes int      `json:"withheld_certificate_bytes,omitempty"`
	CommandDigestHex         string   `json:"command_digest_hex,omitempty"`
	CertificateBytes         int      `json:"certificate_bytes,omitempty"`
	DKGDurationMS            float64  `json:"dkg_duration_ms"`
	ApprovalMS               float64  `json:"approval_ms"`
	RecoveryMS               float64  `json:"recovery_ms"`
	IssuedAt                 string   `json:"issued_at"`
	ExpiresAt                string   `json:"expires_at"`
	Reason                   string   `json:"reason,omitempty"`
	ReleaseCommand           string   `json:"release_command,omitempty"`
	ReleaseExitCode          int      `json:"release_exit_code,omitempty"`
}

func writeRecord(path string, record authorizationRecord) error {
	if path == "" {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	encoded, err := json.MarshalIndent(record, "", "  ")
	if err != nil {
		return err
	}
	encoded = append(encoded, '\n')
	return os.WriteFile(path, encoded, 0o600)
}

func bftThreshold(nodeCount int) int {
	return (2*nodeCount)/3 + 1
}

func main() {
	scenario := flag.String("scenario", "normal", "normal, invalid, proposal-withhold, selective-proposal, or certificate-withhold")
	output := flag.String("output", "", "authorization JSON output path")
	viewTimeout := flag.Duration("view-timeout", 5*time.Second, "leader-failure timeout before replacement view")
	releaseCommand := flag.String("release-cmd", "", "shell command executed only after certificate verification")
	epoch := flag.Uint64("epoch", 1, "protocol epoch")
	round := flag.Uint64("round", uint64(time.Now().Unix()), "protocol round")
	nodeCountFlag := flag.Int("nodes", 4, "swarm node count")
	thresholdFlag := flag.Int("threshold", 0, "threshold; zero selects floor(2n/3)+1")
	takeoffAltitude := flag.Float64("takeoff-altitude", 2.5, "authorized takeoff altitude in metres")
	flag.Parse()

	nodeCount := *nodeCountFlag
	threshold := *thresholdFlag
	if threshold == 0 {
		threshold = bftThreshold(nodeCount)
	}

	supported := map[string]bool{
		"normal":               true,
		"invalid":              true,
		"proposal-withhold":    true,
		"selective-proposal":   true,
		"certificate-withhold": true,
	}
	if !supported[*scenario] {
		fmt.Fprintf(os.Stderr, "unsupported scenario %q\n", *scenario)
		os.Exit(2)
	}
	if nodeCount < 4 || nodeCount > 100 {
		fmt.Fprintln(os.Stderr, "nodes must be between 4 and 100")
		os.Exit(2)
	}
	if threshold < 2 || threshold > nodeCount {
		fmt.Fprintln(os.Stderr, "threshold must satisfy 2 <= threshold <= nodes")
		os.Exit(2)
	}
	if *viewTimeout < 0 || *takeoffAltitude <= 0 {
		fmt.Fprintln(os.Stderr, "timeout must be nonnegative and altitude positive")
		os.Exit(2)
	}

	targets := make([]uint32, nodeCount)
	for index := range targets {
		targets[index] = uint32(index + 2)
	}

	now := time.Now().UTC()
	expires := now.Add(30 * time.Minute)
	record := authorizationRecord{
		Scenario:         *scenario,
		NodeCount:        nodeCount,
		Threshold:        threshold,
		TargetSystemIDs:  targets,
		TakeoffAltitudeM: *takeoffAltitude,
		IssuedAt:         now.Format(time.RFC3339Nano),
		ExpiresAt:        expires.Format(time.RFC3339Nano),
		ReleaseCommand:   *releaseCommand,
		ViewTimeoutMS:    float64(viewTimeout.Microseconds()) / 1000,
	}

	dkgStarted := time.Now()
	dkgResult, err := dkg.RunHonest(nodeCount, threshold)
	record.DKGDurationMS = float64(time.Since(dkgStarted).Microseconds()) / 1000
	if err != nil {
		record.Reason = fmt.Sprintf("GJKR DKG failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(3)
	}

	scheme := tbls.NewThresholdSchemeOnG1(dkgResult.Suite)
	baseStationPublicKey, baseStationPrivateKey, err := identity.GenerateKeyPair()
	if err != nil {
		record.Reason = fmt.Sprintf("base-station key generation failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(4)
	}

	nonce := make([]byte, 32)
	if _, err := rand.Read(nonce); err != nil {
		record.Reason = fmt.Sprintf("nonce generation failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(5)
	}

	payload, _ := json.Marshal(map[string]any{
		"action":     "arm_takeoff_hover_land",
		"targets":    targets,
		"altitude_m": *takeoffAltitude,
	})
	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           *epoch,
		Round:           *round,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: expires.UnixNano(),
		CommandType:     1,
		Payload:         payload,
		Nonce:           nonce,
	}
	approvedCommand, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		command,
		now,
	)
	if err != nil {
		record.Reason = fmt.Sprintf("base-station authorization failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(6)
	}

	signers := make([]*thresholdprotocol.AuthenticatedFollowerSigner, 0, nodeCount)
	registry := make(map[uint32]ed25519.PublicKey, nodeCount)
	stores := make([]*storage.VoteStore, 0, nodeCount)
	voteDirectory, err := os.MkdirTemp("", "uav-bft-px4gate-votes-")
	if err != nil {
		record.Reason = fmt.Sprintf("create temporary vote directory: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(7)
	}
	defer os.RemoveAll(voteDirectory)
	defer func() {
		for _, store := range stores {
			_ = store.Close()
		}
	}()

	for index := 0; index < nodeCount; index++ {
		storePath := filepath.Join(voteDirectory, fmt.Sprintf("node-%d.db", index))
		store, err := storage.OpenVoteStore(storePath)
		if err != nil {
			record.Reason = fmt.Sprintf("node %d vote store failed: %v", index, err)
			_ = writeRecord(*output, record)
			fmt.Fprintln(os.Stderr, record.Reason)
			os.Exit(7)
		}
		stores = append(stores, store)

		follower, err := thresholdprotocol.NewFollowerSigner(
			scheme,
			dkgResult.Shares[index].PriShare(),
			dkgResult.PublicPoly,
			store,
			baseStationPublicKey,
		)
		if err != nil {
			record.Reason = fmt.Sprintf("node %d follower creation failed: %v", index, err)
			_ = writeRecord(*output, record)
			fmt.Fprintln(os.Stderr, record.Reason)
			os.Exit(8)
		}
		publicKey, privateKey, err := identity.GenerateKeyPair()
		if err != nil {
			record.Reason = fmt.Sprintf("node %d identity generation failed: %v", index, err)
			_ = writeRecord(*output, record)
			fmt.Fprintln(os.Stderr, record.Reason)
			os.Exit(9)
		}
		signer, err := thresholdprotocol.NewAuthenticatedFollowerSigner(follower, privateKey)
		if err != nil {
			record.Reason = fmt.Sprintf("node %d authenticated signer failed: %v", index, err)
			_ = writeRecord(*output, record)
			fmt.Fprintln(os.Stderr, record.Reason)
			os.Exit(10)
		}
		signers = append(signers, signer)
		registry[signer.SignerID()] = publicKey
	}

	authorizationStarted := time.Now()
	view := uint64(0)
	if *scenario == "proposal-withhold" ||
		*scenario == "selective-proposal" ||
		*scenario == "certificate-withhold" {
		viewZeroApprovals := make([]wire.Approval, 0, nodeCount)
		viewZeroLimit := 0
		switch *scenario {
		case "selective-proposal":
			viewZeroLimit = threshold - 1
		case "certificate-withhold":
			viewZeroLimit = nodeCount
		}
		for index := 0; index < viewZeroLimit; index++ {
			result, err := signers[index].Approve(
				context.Background(),
				approvedCommand,
				0,
				time.Now().UTC(),
			)
			if err != nil {
				record.Reason = fmt.Sprintf("view-zero approval failed: %v", err)
				_ = writeRecord(*output, record)
				fmt.Fprintln(os.Stderr, record.Reason)
				os.Exit(11)
			}
			viewZeroApprovals = append(viewZeroApprovals, result.Approval)
		}

		if *scenario == "certificate-withhold" {
			withheld, err := thresholdprotocol.RecoverAuthenticatedCertificate(
				scheme,
				dkgResult.PublicPoly,
				dkgResult.PublicKey,
				approvedCommand,
				0,
				viewZeroApprovals,
				registry,
				uint32(threshold),
				uint32(nodeCount),
			)
			if err != nil {
				record.Reason = fmt.Sprintf("withheld view-zero certificate recovery failed: %v", err)
				_ = writeRecord(*output, record)
				fmt.Fprintln(os.Stderr, record.Reason)
				os.Exit(11)
			}
			digest, digestErr := wire.CertificateDigest(approvedCommand)
			if digestErr != nil || scheme.VerifyRecovered(
				dkgResult.PublicKey,
				digest[:],
				withheld.ThresholdBLSSig,
			) != nil {
				record.Reason = "withheld view-zero certificate verification failed"
				_ = writeRecord(*output, record)
				fmt.Fprintln(os.Stderr, record.Reason)
				os.Exit(11)
			}
			record.WithheldCertificateBytes = len(withheld.ThresholdBLSSig)
		}

		timeoutStarted := time.Now()
		time.Sleep(*viewTimeout)
		record.ViewChangeDelayMS = float64(time.Since(timeoutStarted).Microseconds()) / 1000
		view = 1
	}

	approvalStarted := time.Now()
	approvals := make([]wire.Approval, 0, nodeCount)
	approvalLimit := nodeCount
	if *scenario == "invalid" {
		approvalLimit = threshold - 1
	}
	for index := 0; index < approvalLimit; index++ {
		result, err := signers[index].Approve(
			context.Background(),
			approvedCommand,
			view,
			time.Now().UTC(),
		)
		if err != nil {
			record.Reason = fmt.Sprintf("node %d approval failed: %v", index, err)
			_ = writeRecord(*output, record)
			fmt.Fprintln(os.Stderr, record.Reason)
			os.Exit(12)
		}
		approvals = append(approvals, result.Approval)
	}
	record.ApprovalMS = float64(time.Since(approvalStarted).Microseconds()) / 1000

	recoveryStarted := time.Now()
	certificate, err := thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		approvedCommand,
		view,
		approvals,
		registry,
		uint32(threshold),
		uint32(nodeCount),
	)
	record.RecoveryMS = float64(time.Since(recoveryStarted).Microseconds()) / 1000

	if *scenario == "invalid" {
		if err == nil {
			record.Reason = "invalid scenario unexpectedly produced a certificate"
			_ = writeRecord(*output, record)
			fmt.Fprintln(os.Stderr, record.Reason)
			os.Exit(13)
		}
		if !errors.Is(err, thresholdprotocol.ErrInsufficientApprovals) {
			record.Reason = fmt.Sprintf("invalid scenario failed for unexpected reason: %v", err)
			_ = writeRecord(*output, record)
			fmt.Fprintln(os.Stderr, record.Reason)
			os.Exit(14)
		}
		record.Authorized = false
		record.Reason = err.Error()
		if err := writeRecord(*output, record); err != nil {
			fmt.Fprintf(os.Stderr, "write block record: %v\n", err)
			os.Exit(15)
		}
		fmt.Println("THRESHOLD CERTIFICATE: REJECTED")
		fmt.Println("PX4 COMMAND RELEASE: BLOCKED")
		return
	}

	if err != nil {
		record.Reason = fmt.Sprintf("certificate recovery failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(16)
	}

	digest, err := wire.CertificateDigest(approvedCommand)
	if err != nil {
		record.Reason = fmt.Sprintf("certificate digest failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(17)
	}
	if err := scheme.VerifyRecovered(
		dkgResult.PublicKey,
		digest[:],
		certificate.ThresholdBLSSig,
	); err != nil {
		record.Reason = fmt.Sprintf("final certificate verification failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(18)
	}

	record.Authorized = true
	certificateView := certificate.View
	record.CertificateView = &certificateView
	record.AuthorizationLatencyMS = float64(time.Since(authorizationStarted).Microseconds()) / 1000
	record.SignerIDs = certificate.SignerIDs
	record.CommandDigestHex = hex.EncodeToString(certificate.CommandDigest)
	record.CertificateBytes = len(certificate.ThresholdBLSSig)
	if err := writeRecord(*output, record); err != nil {
		fmt.Fprintf(os.Stderr, "write authorization record: %v\n", err)
		os.Exit(19)
	}

	fmt.Printf("GJKR DKG: PASSED (n=%d, t=%d)\n", nodeCount, threshold)
	fmt.Println("AUTHENTICATED APPROVALS: PASSED")
	fmt.Println("THRESHOLD CERTIFICATE: VERIFIED")
	fmt.Printf("CERTIFICATE VIEW: %d\n", certificate.View)
	fmt.Printf("CERTIFICATE SIGNERS: %v\n", certificate.SignerIDs)
	fmt.Printf("CERTIFICATE BYTES: %d\n", len(certificate.ThresholdBLSSig))
	fmt.Println("PX4 COMMAND RELEASE: AUTHORIZED")

	if *releaseCommand == "" {
		return
	}
	released := exec.Command("/bin/bash", "-lc", *releaseCommand)
	released.Stdout = os.Stdout
	released.Stderr = os.Stderr
	released.Stdin = os.Stdin
	if err := released.Run(); err != nil {
		exitCode := 1
		var exitError *exec.ExitError
		if errors.As(err, &exitError) {
			exitCode = exitError.ExitCode()
		}
		record.ReleaseExitCode = exitCode
		record.Reason = fmt.Sprintf("released command failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(20)
	}
	record.ReleaseExitCode = 0
	if err := writeRecord(*output, record); err != nil {
		fmt.Fprintf(os.Stderr, "update authorization record: %v\n", err)
		os.Exit(21)
	}
}
