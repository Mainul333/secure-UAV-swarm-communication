package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/consensus"
	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

func main() {
	const (
		nodeCount = 4
		threshold = 3
	)

	ctx := context.Background()
	now := time.Now().UTC()
	viewTimeout := 100 * time.Millisecond

	dkgResult, err := dkg.RunHonest(nodeCount, threshold)
	if err != nil {
		panic(fmt.Errorf("run GJKR DKG: %w", err))
	}
	scheme := tbls.NewThresholdSchemeOnG1(dkgResult.Suite)

	baseStationPublicKey, baseStationPrivateKey, err :=
		identity.GenerateKeyPair()
	if err != nil {
		panic(err)
	}

	authorized, err := identity.AuthorizeCommand(
		baseStationPrivateKey,
		1,
		wire.Command{
			ProtocolVersion: wire.CurrentProtocolVersion,
			Epoch:           1,
			Round:           8,
			IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
			ExpiresAtUnixNs: now.Add(5 * time.Minute).UnixNano(),
			CommandType:     1,
			Payload:         []byte("MOVE:X=5,Y=5,Z=-5"),
			Nonce:           []byte("0123456789ABCDEF"),
		},
		now,
	)
	if err != nil {
		panic(err)
	}

	stateDirectory, err := os.MkdirTemp("", "uav-bft-view-change-*")
	if err != nil {
		panic(err)
	}
	defer os.RemoveAll(stateDirectory)

	signers := make(
		[]*thresholdprotocol.AuthenticatedFollowerSigner,
		nodeCount,
	)
	registry := make(map[uint32]ed25519.PublicKey, nodeCount)
	privateIdentities := make(map[uint32]ed25519.PrivateKey, nodeCount)
	stores := make([]*storage.VoteStore, 0, nodeCount)
	defer func() {
		for _, store := range stores {
			_ = store.Close()
		}
	}()

	for index := 0; index < nodeCount; index++ {
		store, err := storage.OpenVoteStore(filepath.Join(
			stateDirectory,
			fmt.Sprintf("node%d.db", index),
		))
		if err != nil {
			panic(err)
		}
		stores = append(stores, store)

		follower, err := thresholdprotocol.NewFollowerSigner(
			scheme,
			dkgResult.Shares[index].PriShare(),
			dkgResult.PublicPoly,
			store,
			baseStationPublicKey,
		)
		if err != nil {
			panic(err)
		}

		publicKey, privateKey, err := identity.GenerateKeyPair()
		if err != nil {
			panic(err)
		}
		authenticated, err :=
			thresholdprotocol.NewAuthenticatedFollowerSigner(
				follower,
				privateKey,
			)
		if err != nil {
			panic(err)
		}

		signerID := authenticated.SignerID()
		signers[index] = authenticated
		registry[signerID] = publicKey
		privateIdentities[signerID] = privateKey
	}

	state, err := consensus.NewRoundState(
		1,
		8,
		[]uint32{0, 1, 2, 3},
		threshold,
		viewTimeout,
		now,
	)
	if err != nil {
		panic(err)
	}
	if state.Leader() != 0 {
		panic("unexpected view-zero leader")
	}
	if err := state.AcceptProposal(0, 1, 8, 0); err != nil {
		panic(err)
	}

	viewZeroApprovals := make([]wire.Approval, 0, threshold)
	for index := 0; index < threshold; index++ {
		approval, err := signers[index].Approve(ctx, authorized, 0, now)
		if err != nil {
			panic(err)
		}
		if err := state.RecordApproval(approval.Approval); err != nil {
			panic(err)
		}
		viewZeroApprovals = append(viewZeroApprovals, approval.Approval)
	}
	if !state.ReadyToCertify() {
		panic("view-zero leader did not receive threshold approvals")
	}

	commandDigest, err := wire.CertificateDigest(authorized)
	if err != nil {
		panic(err)
	}
	timeoutCollector, err := consensus.NewTimeoutCollector(
		1,
		8,
		1,
		commandDigest[:],
		threshold,
		registry,
	)
	if err != nil {
		panic(err)
	}

	// Node 0 is the withholding leader. Nodes 1, 2, and 3 establish view 1.
	for _, senderID := range []uint32{1, 2, 3} {
		change, err := identity.SignViewChange(
			privateIdentities[senderID],
			wire.ViewChange{
				Epoch:         1,
				Round:         8,
				NewView:       1,
				CommandDigest: commandDigest[:],
				SenderID:      senderID,
			},
		)
		if err != nil {
			panic(err)
		}
		if err := timeoutCollector.Add(change); err != nil {
			panic(err)
		}
	}

	timeoutCertificate, err := timeoutCollector.Build()
	if err != nil {
		panic(err)
	}
	if err := consensus.VerifyTimeoutCertificate(
		timeoutCertificate,
		threshold,
		registry,
	); err != nil {
		panic(err)
	}

	replacementLeader, err := state.OnTimeout(now.Add(viewTimeout))
	if err != nil {
		panic(err)
	}
	if replacementLeader != 1 {
		panic("unexpected replacement leader")
	}
	if err := state.AcceptProposal(1, 1, 8, 1); err != nil {
		panic(err)
	}

	viewOneApprovals := make([]wire.Approval, 0, threshold)
	for index := 0; index < threshold; index++ {
		approval, err := signers[index].Approve(ctx, authorized, 1, now)
		if err != nil {
			panic(err)
		}
		if approval.Created {
			panic("replacement view created a second BLS partial")
		}
		if !bytes.Equal(
			viewZeroApprovals[index].PartialBLSSig,
			approval.Approval.PartialBLSSig,
		) {
			panic("persistent partial changed")
		}
		if bytes.Equal(
			viewZeroApprovals[index].IdentitySig,
			approval.Approval.IdentitySig,
		) {
			panic("old-view identity envelope was reused")
		}
		if err := state.RecordApproval(approval.Approval); err != nil {
			panic(err)
		}
		viewOneApprovals = append(viewOneApprovals, approval.Approval)
	}

	certificate, err := thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		authorized,
		1,
		viewOneApprovals,
		registry,
		threshold,
		nodeCount,
	)
	if err != nil {
		panic(err)
	}
	if err := state.MarkCertified(certificate); err != nil {
		panic(err)
	}

	fmt.Println("GJKR DKG: PASSED")
	fmt.Println("Malicious certificate withholding: DETECTED")
	fmt.Println("Authenticated timeout certificate: PASSED")
	fmt.Println("Replacement leader: node", replacementLeader)
	fmt.Println("Persistent BLS partial reuse: PASSED")
	fmt.Println("New-view Ed25519 reauthentication: PASSED")
	fmt.Println("Replacement-view threshold recovery: PASSED")
	fmt.Println("Final certificate bytes:", len(certificate.ThresholdBLSSig))
	fmt.Println("Final phase:", state.Phase())
}
