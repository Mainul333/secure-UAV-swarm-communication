// Command frostdkgbench runs GJKR distributed key generation over the
// Edwards25519 group (the code of internal/dkg with the group changed) and
// then times the online threshold-Schnorr operations with the generated
// shares: nonce commitments, share computation, share verification against
// public key shares computed once, aggregation, and verification of the
// combined signature with the standard Ed25519 verifier of the Go library.
package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/binary"
	"flag"
	"fmt"
	"math/big"
	"os"
	"time"

	"go.dedis.ch/kyber/v4"
	"go.dedis.ch/kyber/v4/group/edwards25519"
)

var groupOrder, _ = new(big.Int).SetString("7237005577332262213973186563042994240857116359379907606001950938285454250989", 10)

// rfc8032Challenge returns SHA-512(R || A || M) reduced modulo the group order.
func rfc8032Challenge(suite *edwards25519.SuiteEd25519, R, A kyber.Point, msg []byte) kyber.Scalar {
	rb, _ := R.MarshalBinary()
	ab, _ := A.MarshalBinary()
	h := sha512.New()
	h.Write(rb)
	h.Write(ab)
	h.Write(msg)
	return leScalar(suite, h.Sum(nil))
}

func leScalar(suite *edwards25519.SuiteEd25519, littleEndian []byte) kyber.Scalar {
	be := make([]byte, len(littleEndian))
	for i := range littleEndian {
		be[len(littleEndian)-1-i] = littleEndian[i]
	}
	v := new(big.Int).Mod(new(big.Int).SetBytes(be), groupOrder)
	out := make([]byte, 32)
	vb := v.Bytes()
	for i := range vb {
		out[i] = vb[len(vb)-1-i]
	}
	s := suite.Scalar()
	if err := s.UnmarshalBinary(out); err != nil {
		panic(err)
	}
	return s
}

func bindingFactor(suite *edwards25519.SuiteEd25519, id uint32, msg, commitments []byte) kyber.Scalar {
	var b [4]byte
	binary.LittleEndian.PutUint32(b[:], id)
	h := sha512.New()
	h.Write([]byte("FROST-ED25519-SHA512-rho"))
	h.Write(b[:])
	h.Write(msg)
	h.Write(commitments)
	return leScalar(suite, h.Sum(nil))
}

func lagrange(suite *edwards25519.SuiteEd25519, i uint32, ids []uint32) kyber.Scalar {
	num := suite.Scalar().One()
	den := suite.Scalar().One()
	xi := suite.Scalar().SetInt64(int64(i) + 1)
	for _, j := range ids {
		if j == i {
			continue
		}
		xj := suite.Scalar().SetInt64(int64(j) + 1)
		num.Mul(num, xj)
		den.Mul(den, suite.Scalar().Sub(xj, xi))
	}
	return suite.Scalar().Div(num, den)
}

func main() {
	n := flag.Int("n", 4, "number of members")
	t := flag.Int("t", 3, "threshold")
	flag.Parse()
	started := time.Now()
	result, err := RunHonest(*n, *t)
	if err != nil {
		fmt.Fprintln(os.Stderr, "dkg failed:", err)
		os.Exit(1)
	}
	dkgDuration := time.Since(started)
	suite := result.Suite
	st := result.Statistics
	fmt.Printf("gjkr_status=passed\nqual_size=%d\ndkg_ms=%.3f\n", len(result.QUAL), float64(dkgDuration.Microseconds())/1000)
	fmt.Printf("deal_objects=%d\nresponse_objects=%d\nresponse_deliveries=%d\nsecret_commit_deliveries=%d\n",
		st.DealObjects, st.ResponseObjects, st.ResponseDeliveries, st.SecretCommitDeliveries)

	ids := make([]uint32, *t)
	for k := 0; k < *t; k++ {
		ids[k] = uint32(k)
	}
	pubShares := make([]kyber.Point, *t)
	for _, id := range ids {
		pubShares[id] = result.PublicPoly.Eval(id).V
	}
	msg := sha256.Sum256([]byte("UAV-CMD-FROST-v1 benchmark command"))

	// nonce commitments (FROST preprocessing)
	mark := time.Now()
	d := make([]kyber.Scalar, *t)
	e := make([]kyber.Scalar, *t)
	D := make([]kyber.Point, *t)
	E := make([]kyber.Point, *t)
	blob := make([]byte, 0, 68*(*t))
	for k := range ids {
		d[k] = suite.Scalar().Pick(suite.RandomStream())
		e[k] = suite.Scalar().Pick(suite.RandomStream())
		D[k] = suite.Point().Mul(d[k], nil)
		E[k] = suite.Point().Mul(e[k], nil)
		var b [4]byte
		binary.LittleEndian.PutUint32(b[:], ids[k])
		db, _ := D[k].MarshalBinary()
		eb, _ := E[k].MarshalBinary()
		blob = append(append(append(blob, b[:]...), db...), eb...)
	}
	preprocessing := time.Since(mark)

	// share computation (all t signers) together with share verification
	mark = time.Now()
	rho := make([]kyber.Scalar, *t)
	Ri := make([]kyber.Point, *t)
	R := suite.Point().Null()
	for k, id := range ids {
		rho[k] = bindingFactor(suite, id, msg[:], blob)
		Ri[k] = suite.Point().Add(D[k], suite.Point().Mul(rho[k], E[k]))
		R.Add(R, Ri[k])
	}
	c := rfc8032Challenge(suite, R, result.PublicKey, msg[:])
	z := make([]kyber.Scalar, *t)
	ok := true
	for k, id := range ids {
		var share kyber.Scalar
		for _, s := range result.Shares {
			if s.Share.I == id {
				share = s.Share.V
			}
		}
		lam := lagrange(suite, id, ids)
		z[k] = suite.Scalar().Add(d[k], suite.Scalar().Mul(e[k], rho[k]))
		z[k].Add(z[k], suite.Scalar().Mul(suite.Scalar().Mul(lam, share), c))
		left := suite.Point().Mul(z[k], nil)
		right := suite.Point().Add(Ri[k], suite.Point().Mul(suite.Scalar().Mul(lam, c), pubShares[id]))
		if !left.Equal(right) {
			ok = false
		}
	}
	signVerify := time.Since(mark)

	// aggregation
	mark = time.Now()
	zsum := suite.Scalar().Zero()
	for k := range ids {
		zsum.Add(zsum, z[k])
	}
	rb, _ := R.MarshalBinary()
	zb, _ := zsum.MarshalBinary()
	signature := append(append([]byte{}, rb...), zb...)
	aggregation := time.Since(mark)

	// final verification with the standard Ed25519 verifier
	pk, _ := result.PublicKey.MarshalBinary()
	mark = time.Now()
	valid := ed25519.Verify(ed25519.PublicKey(pk), msg[:], signature)
	finalVerify := time.Since(mark)
	if !ok || !valid {
		fmt.Println("threshold_schnorr_status=failed")
		os.Exit(2)
	}
	ms := func(x time.Duration) float64 { return float64(x.Nanoseconds()) / 1e6 }
	fmt.Printf("threshold_schnorr_status=passed\nsignature_bytes=%d\n", len(signature))
	fmt.Printf("preprocessing_ms=%.4f\npartial_sign_verify_ms=%.4f\nreconstruction_ms=%.4f\nfinal_verification_ms=%.4f\n",
		ms(preprocessing), ms(signVerify), ms(aggregation), ms(finalVerify))
}
