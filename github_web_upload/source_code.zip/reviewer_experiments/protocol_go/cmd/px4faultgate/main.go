package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	thresholdprotocol "uav-bft/internal/threshold"
	"uav-bft/internal/wire"
)

type authorizationRecord struct {
	Authorized             bool     `json:"authorized"`
	Scenario               string   `json:"scenario"`
	FaultMode              string   `json:"fault_mode"`
	NodeCount              int      `json:"node_count"`
	Threshold              int      `json:"threshold"`
	FaultBound             int      `json:"fault_bound"`
	FaultyCount            int      `json:"faulty_count"`
	MaliciousIDs           []uint32 `json:"malicious_ids"`
	TargetSystemIDs        []uint32 `json:"target_system_ids"`
	TakeoffAltitudeM       float64  `json:"takeoff_altitude_m"`
	CertificateView        *uint64  `json:"certificate_view"`
	SignerIDs              []uint32 `json:"signer_ids,omitempty"`
	MissingApprovals       int      `json:"missing_approvals"`
	RejectedApprovals      int      `json:"rejected_approvals"`
	CandidateApprovals     int      `json:"candidate_approvals"`
	ValidApprovals         int      `json:"valid_approvals"`
	CommandDigestHex       string   `json:"command_digest_hex,omitempty"`
	CertificateBytes       int      `json:"certificate_bytes,omitempty"`
	DKGDurationMS          float64  `json:"dkg_duration_ms"`
	CandidateGenerationMS  float64  `json:"candidate_generation_ms"`
	ValidationMS           float64  `json:"validation_ms"`
	RecoveryMS             float64  `json:"recovery_ms"`
	AuthorizationLatencyMS float64  `json:"authorization_latency_ms"`
	IssuedAt               string   `json:"issued_at"`
	ExpiresAt              string   `json:"expires_at"`
	Reason                 string   `json:"reason,omitempty"`
	ReleaseCommand         string   `json:"release_command,omitempty"`
	ReleaseExitCode        int      `json:"release_exit_code,omitempty"`
}

func bftThreshold(nodeCount int) int { return (2*nodeCount)/3 + 1 }
func faultBound(nodeCount int) int   { return (nodeCount - 1) / 3 }

func writeRecord(path string, record authorizationRecord) error {
	if path == "" {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	encoded, err := json.MarshalIndent(record, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(encoded, '\n'), 0o600)
}

func makeAuthorizedCommand(
	privateKey ed25519.PrivateKey,
	epoch uint64,
	round uint64,
	now time.Time,
	expires time.Time,
	targets []uint32,
	altitude float64,
	variant string,
) (wire.AuthorizedCommand, error) {
	nonce := make([]byte, 32)
	if _, err := rand.Read(nonce); err != nil {
		return wire.AuthorizedCommand{}, err
	}
	payload, err := json.Marshal(map[string]any{
		"action":     "arm_takeoff_hover_land",
		"targets":    targets,
		"altitude_m": altitude,
		"variant":    variant,
	})
	if err != nil {
		return wire.AuthorizedCommand{}, err
	}
	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           epoch,
		Round:           round,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: expires.UnixNano(),
		CommandType:     1,
		Payload:         payload,
		Nonce:           nonce,
	}
	return identity.AuthorizeCommand(privateKey, 1, command, now)
}

func main() {
	faultMode := flag.String("fault-mode", "silent", "silent, malformed, or equivocation")
	output := flag.String("output", "", "authorization JSON output path")
	releaseCommand := flag.String("release-cmd", "", "shell command executed only after certificate verification")
	epoch := flag.Uint64("epoch", 1, "protocol epoch")
	round := flag.Uint64("round", uint64(time.Now().Unix()), "protocol round")
	nodeCountFlag := flag.Int("nodes", 7, "swarm node count")
	thresholdFlag := flag.Int("threshold", 0, "threshold; zero selects floor(2n/3)+1")
	takeoffAltitude := flag.Float64("takeoff-altitude", 2.5, "authorized takeoff altitude in metres")
	flag.Parse()

	nodeCount := *nodeCountFlag
	threshold := *thresholdFlag
	if threshold == 0 {
		threshold = bftThreshold(nodeCount)
	}
	f := faultBound(nodeCount)
	if nodeCount < 4 || nodeCount > 20 || threshold < 2 || threshold > nodeCount || f < 1 {
		fmt.Fprintln(os.Stderr, "invalid node/threshold configuration")
		os.Exit(2)
	}
	if *faultMode != "silent" && *faultMode != "malformed" && *faultMode != "equivocation" {
		fmt.Fprintf(os.Stderr, "unsupported fault mode %q\n", *faultMode)
		os.Exit(2)
	}

	targets := make([]uint32, nodeCount)
	for i := range targets {
		targets[i] = uint32(i + 2)
	}
	maliciousIDs := make([]uint32, 0, f)
	for i := nodeCount - f; i < nodeCount; i++ {
		maliciousIDs = append(maliciousIDs, uint32(i))
	}

	now := time.Now().UTC()
	expires := now.Add(30 * time.Minute)
	record := authorizationRecord{
		Scenario:         "faulty-followers",
		FaultMode:        *faultMode,
		NodeCount:        nodeCount,
		Threshold:        threshold,
		FaultBound:       f,
		FaultyCount:      f,
		MaliciousIDs:     maliciousIDs,
		TargetSystemIDs:  targets,
		TakeoffAltitudeM: *takeoffAltitude,
		IssuedAt:         now.Format(time.RFC3339Nano),
		ExpiresAt:        expires.Format(time.RFC3339Nano),
		ReleaseCommand:   *releaseCommand,
	}

	dkgStarted := time.Now()
	dkgResult, err := dkg.RunHonest(nodeCount, threshold)
	record.DKGDurationMS = float64(time.Since(dkgStarted).Microseconds()) / 1000
	if err != nil {
		record.Reason = fmt.Sprintf("GJKR DKG failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(3)
	}
	scheme := tbls.NewThresholdSchemeOnG1(dkgResult.Suite)
	basePublic, basePrivate, err := identity.GenerateKeyPair()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(4)
	}
	authorized, err := makeAuthorizedCommand(basePrivate, *epoch, *round, now, expires, targets, *takeoffAltitude, "primary")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(5)
	}
	alternate, err := makeAuthorizedCommand(basePrivate, *epoch, *round, now, expires, targets, *takeoffAltitude+1.0, "conflicting")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(5)
	}

	signers := make([]*thresholdprotocol.AuthenticatedFollowerSigner, 0, nodeCount)
	identityPrivateKeys := make([]ed25519.PrivateKey, 0, nodeCount)
	registry := make(map[uint32]ed25519.PublicKey, nodeCount)
	stores := make([]*storage.VoteStore, 0, nodeCount)
	voteDirectory, err := os.MkdirTemp("", "uav-bft-faultgate-votes-")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(6)
	}
	defer os.RemoveAll(voteDirectory)
	defer func() {
		for _, store := range stores {
			_ = store.Close()
		}
	}()

	for i := 0; i < nodeCount; i++ {
		store, err := storage.OpenVoteStore(filepath.Join(voteDirectory, fmt.Sprintf("node-%d.db", i)))
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(7)
		}
		stores = append(stores, store)
		follower, err := thresholdprotocol.NewFollowerSigner(
			scheme,
			dkgResult.Shares[i].PriShare(),
			dkgResult.PublicPoly,
			store,
			basePublic,
		)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(8)
		}
		publicKey, privateKey, err := identity.GenerateKeyPair()
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(9)
		}
		signer, err := thresholdprotocol.NewAuthenticatedFollowerSigner(follower, privateKey)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(10)
		}
		signers = append(signers, signer)
		identityPrivateKeys = append(identityPrivateKeys, privateKey)
		registry[signer.SignerID()] = publicKey
	}

	authorizationStarted := time.Now()
	generationStarted := time.Now()
	candidates := make([]wire.Approval, 0, nodeCount)
	honestCount := nodeCount - f
	for i := 0; i < honestCount; i++ {
		result, err := signers[i].Approve(context.Background(), authorized, 0, time.Now().UTC())
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(11)
		}
		candidates = append(candidates, result.Approval)
	}

	switch *faultMode {
	case "silent":
		record.MissingApprovals = f
	case "malformed":
		for i := honestCount; i < nodeCount; i++ {
			result, err := signers[i].Approve(context.Background(), authorized, 0, time.Now().UTC())
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(11)
			}
			malformed := result.Approval
			malformed.IdentitySig = append([]byte(nil), malformed.IdentitySig...)
			if len(malformed.IdentitySig) > 0 {
				malformed.IdentitySig[0] ^= 0x80
			}
			candidates = append(candidates, malformed)
		}
	case "equivocation":
		alternateDigest, err := wire.CertificateDigest(alternate)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(11)
		}
		for i := honestCount; i < nodeCount; i++ {
			partial, err := scheme.Sign(dkgResult.Shares[i].PriShare(), alternateDigest[:])
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(11)
			}
			approval := wire.Approval{
				Epoch:         alternate.Command.Epoch,
				Round:         alternate.Command.Round,
				View:          0,
				CommandDigest: append([]byte(nil), alternateDigest[:]...),
				SignerID:      uint32(i),
				PartialBLSSig: append([]byte(nil), partial...),
			}
			sig, err := identity.SignApprovalEnvelope(identityPrivateKeys[i], approval)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(11)
			}
			approval.IdentitySig = sig
			candidates = append(candidates, approval)
		}
	}
	record.CandidateGenerationMS = float64(time.Since(generationStarted).Microseconds()) / 1000
	record.CandidateApprovals = len(candidates)

	expectedDigest, err := wire.CertificateDigest(authorized)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(12)
	}
	validationStarted := time.Now()
	valid := make([]wire.Approval, 0, len(candidates))
	for _, approval := range candidates {
		if approval.Epoch != authorized.Command.Epoch ||
			approval.Round != authorized.Command.Round ||
			approval.View != 0 ||
			!bytes.Equal(approval.CommandDigest, expectedDigest[:]) {
			record.RejectedApprovals++
			continue
		}
		publicKey, exists := registry[approval.SignerID]
		if !exists || identity.VerifyApprovalEnvelope(publicKey, approval) != nil {
			record.RejectedApprovals++
			continue
		}
		partialIndex, err := scheme.IndexOf(approval.PartialBLSSig)
		if err != nil || partialIndex < 0 || uint32(partialIndex) != approval.SignerID {
			record.RejectedApprovals++
			continue
		}
		if err := scheme.VerifyPartial(dkgResult.PublicPoly, expectedDigest[:], approval.PartialBLSSig); err != nil {
			record.RejectedApprovals++
			continue
		}
		valid = append(valid, approval)
	}
	record.ValidationMS = float64(time.Since(validationStarted).Microseconds()) / 1000
	record.ValidApprovals = len(valid)

	recoveryStarted := time.Now()
	certificate, err := thresholdprotocol.RecoverAuthenticatedCertificate(
		scheme,
		dkgResult.PublicPoly,
		dkgResult.PublicKey,
		authorized,
		0,
		valid,
		registry,
		uint32(threshold),
		uint32(nodeCount),
	)
	record.RecoveryMS = float64(time.Since(recoveryStarted).Microseconds()) / 1000
	if err != nil {
		record.Reason = fmt.Sprintf("certificate recovery failed after filtering faulty followers: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(13)
	}
	if err := scheme.VerifyRecovered(dkgResult.PublicKey, expectedDigest[:], certificate.ThresholdBLSSig); err != nil {
		record.Reason = fmt.Sprintf("final certificate verification failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(14)
	}

	record.Authorized = true
	view := certificate.View
	record.CertificateView = &view
	record.SignerIDs = certificate.SignerIDs
	record.CommandDigestHex = hex.EncodeToString(certificate.CommandDigest)
	record.CertificateBytes = len(certificate.ThresholdBLSSig)
	record.AuthorizationLatencyMS = float64(time.Since(authorizationStarted).Microseconds()) / 1000
	if err := writeRecord(*output, record); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(15)
	}

	fmt.Printf("FAULTY FOLLOWER MODE: %s\n", *faultMode)
	fmt.Printf("FAULTY FOLLOWERS: %d/%d\n", f, nodeCount)
	fmt.Printf("CANDIDATE APPROVALS: %d\n", len(candidates))
	fmt.Printf("REJECTED APPROVALS: %d\n", record.RejectedApprovals)
	fmt.Printf("VALID APPROVALS: %d\n", len(valid))
	fmt.Println("THRESHOLD CERTIFICATE: VERIFIED")
	fmt.Println("PX4 COMMAND RELEASE: AUTHORIZED")

	if *releaseCommand == "" {
		return
	}
	released := exec.Command("/bin/bash", "-lc", *releaseCommand)
	released.Stdout = os.Stdout
	released.Stderr = os.Stderr
	released.Stdin = os.Stdin
	if err := released.Run(); err != nil {
		exitCode := 1
		var exitError *exec.ExitError
		if errors.As(err, &exitError) {
			exitCode = exitError.ExitCode()
		}
		record.ReleaseExitCode = exitCode
		record.Reason = fmt.Sprintf("released command failed: %v", err)
		_ = writeRecord(*output, record)
		fmt.Fprintln(os.Stderr, record.Reason)
		os.Exit(20)
	}
	record.ReleaseExitCode = 0
	if err := writeRecord(*output, record); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(21)
	}
}
