package main

import (
	"crypto/sha256"
	"flag"
	"fmt"
	"log"
	"time"

	"go.dedis.ch/kyber/v4/sign/tbls"

	"uav-bft/internal/dkg"
)

func main() {
	nodeCount := flag.Int(
		"n",
		4,
		"number of GJKR participants",
	)

	threshold := flag.Int(
		"t",
		3,
		"threshold required for certification",
	)

	flag.Parse()

	result, err := dkg.RunHonest(*nodeCount, *threshold)
	if err != nil {
		log.Fatal(err)
	}

	scheme := tbls.NewThresholdSchemeOnG1(result.Suite)

	message := sha256.Sum256(
		[]byte("AUTHORIZED-UAV-COMMAND"),
	)

	partials := make([][]byte, 0, *threshold)

	signingStarted := time.Now()

	for index := 0; index < *threshold; index++ {
		partial, err := scheme.Sign(
			result.Shares[index].PriShare(),
			message[:],
		)
		if err != nil {
			log.Fatalf(
				"node %d partial signing: %v",
				index,
				err,
			)
		}

		if err := scheme.VerifyPartial(
			result.PublicPoly,
			message[:],
			partial,
		); err != nil {
			log.Fatalf(
				"node %d partial verification: %v",
				index,
				err,
			)
		}

		partials = append(partials, partial)
	}

	partialPhaseDuration := time.Since(signingStarted)

	reconstructionStarted := time.Now()

	recovered, err := scheme.Recover(
		result.PublicPoly,
		message[:],
		partials,
		uint32(*threshold),
		uint32(*nodeCount),
	)
	if err != nil {
		log.Fatal(err)
	}

	reconstructionDuration := time.Since(
		reconstructionStarted,
	)

	verificationStarted := time.Now()

	if err := scheme.VerifyRecovered(
		result.PublicKey,
		message[:],
		recovered,
	); err != nil {
		log.Fatalf("final certificate verification: %v", err)
	}

	finalVerificationDuration := time.Since(
		verificationStarted,
	)

	publicKeyBytes, err := result.PublicKey.MarshalBinary()
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("GJKR DKG: PASSED")
	fmt.Println("Threshold BLS: PASSED")
	fmt.Println("n:", result.NodeCount)
	fmt.Println("t:", result.Threshold)
	fmt.Println("QUAL:", result.QUAL)
	fmt.Println("DKG duration:", result.Statistics.Duration)
	fmt.Println("Deal objects:", result.Statistics.DealObjects)
	fmt.Println("Response objects:", result.Statistics.ResponseObjects)
	fmt.Println(
		"Response deliveries:",
		result.Statistics.ResponseDeliveries,
	)
	fmt.Println(
		"Secret-commit deliveries:",
		result.Statistics.SecretCommitDeliveries,
	)
	fmt.Println("Group public-key size:", len(publicKeyBytes), "bytes")
	fmt.Println("Partial-signature size:", len(partials[0]), "bytes")
	fmt.Println("Recovered-signature size:", len(recovered), "bytes")
	fmt.Println("Partial sign+verify duration:", partialPhaseDuration)
	fmt.Println("Reconstruction duration:", reconstructionDuration)
	fmt.Println("Final verification duration:", finalVerificationDuration)
}
