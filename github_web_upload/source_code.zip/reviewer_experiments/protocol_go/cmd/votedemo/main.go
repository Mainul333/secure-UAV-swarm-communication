package main

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"uav-bft/internal/identity"
	"uav-bft/internal/storage"
	"uav-bft/internal/wire"
)

func command(
	now time.Time,
	payload string,
	nonce string,
) wire.Command {
	return wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           15,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte(payload),
		Nonce:           []byte(nonce),
	}
}

func placeholderPartial(digest []byte) []byte {
	hasher := sha256.New()
	_, _ = hasher.Write([]byte("DEMO-PARTIAL-V1"))
	_, _ = hasher.Write(digest)
	return hasher.Sum(nil)
}

func main() {
	ctx := context.Background()
	now := time.Now().UTC()

	tempDirectory, err := os.MkdirTemp("", "uav-bft-votedemo-*")
	if err != nil {
		panic(err)
	}
	defer os.RemoveAll(tempDirectory)

	databasePath := filepath.Join(tempDirectory, "votes.db")

	store, err := storage.OpenVoteStore(databasePath)
	if err != nil {
		panic(err)
	}
	defer store.Close()

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		panic(err)
	}

	firstAuthorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		command(
			now,
			"MOVE:X=5,Y=5,Z=-5",
			"NONCE-0000000001",
		),
		now,
	)
	if err != nil {
		panic(err)
	}

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		firstAuthorized,
		now,
	); err != nil {
		panic(err)
	}

	firstDigestArray, err := wire.CertificateDigest(firstAuthorized)
	if err != nil {
		panic(err)
	}

	signerCalls := 0

	firstResult, err := store.GetOrCreateVote(
		ctx,
		firstAuthorized.Command.Epoch,
		firstAuthorized.Command.Round,
		firstDigestArray[:],
		func() ([]byte, error) {
			signerCalls++
			return placeholderPartial(firstDigestArray[:]), nil
		},
	)
	if err != nil {
		panic(err)
	}

	fmt.Println("First authorized command: VERIFIED")
	fmt.Println("First vote created:", firstResult.Created)
	fmt.Println(
		"Stored partial-signature size:",
		len(firstResult.Vote.PartialSignature),
		"bytes",
	)

	reusedResult, err := store.GetOrCreateVote(
		ctx,
		firstAuthorized.Command.Epoch,
		firstAuthorized.Command.Round,
		firstDigestArray[:],
		func() ([]byte, error) {
			signerCalls++
			return nil, errors.New("reused vote called signer")
		},
	)
	if err != nil {
		panic(err)
	}

	fmt.Println("Same command reused stored vote:", !reusedResult.Created)

	// This is a different but independently valid base-station command
	// for the same epoch and round.
	secondAuthorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		command(
			now,
			"LAND",
			"NONCE-0000000002",
		),
		now,
	)
	if err != nil {
		panic(err)
	}

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		secondAuthorized,
		now,
	); err != nil {
		panic(err)
	}

	secondDigestArray, err := wire.CertificateDigest(secondAuthorized)
	if err != nil {
		panic(err)
	}

	_, err = store.GetOrCreateVote(
		ctx,
		secondAuthorized.Command.Epoch,
		secondAuthorized.Command.Round,
		secondDigestArray[:],
		func() ([]byte, error) {
			signerCalls++
			return placeholderPartial(secondDigestArray[:]), nil
		},
	)

	if !errors.Is(err, storage.ErrConflictingVote) {
		panic(fmt.Sprintf(
			"expected conflicting vote rejection, got %v",
			err,
		))
	}

	fmt.Println("Second authorized conflicting command: REJECTED")
	fmt.Println("Reason:", err)
	fmt.Println("Total partial-signature generations:", signerCalls)

	if signerCalls != 1 {
		panic("one-vote rule failed")
	}

	fmt.Println("Persistent one-vote rule: PASSED")
}
