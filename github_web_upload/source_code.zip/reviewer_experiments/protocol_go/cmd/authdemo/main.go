package main

import (
	"encoding/hex"
	"fmt"
	"time"

	"uav-bft/internal/identity"
	"uav-bft/internal/wire"
)

func main() {
	now := time.Now().UTC()

	publicKey, privateKey, err := identity.GenerateKeyPair()
	if err != nil {
		panic(err)
	}

	command := wire.Command{
		ProtocolVersion: wire.CurrentProtocolVersion,
		Epoch:           1,
		Round:           1,
		IssuedAtUnixNs:  now.Add(-time.Second).UnixNano(),
		ExpiresAtUnixNs: now.Add(time.Minute).UnixNano(),
		CommandType:     1,
		Payload:         []byte("TAKEOFF:5M"),
		Nonce:           []byte("1234567890ABCDEF"),
	}

	authorized, err := identity.AuthorizeCommand(
		privateKey,
		1,
		command,
		now,
	)
	if err != nil {
		panic(err)
	}

	digest, err := wire.AuthorizationDigest(
		authorized.Command,
		authorized.BaseStationID,
	)
	if err != nil {
		panic(err)
	}

	fmt.Println("Authorization digest:", hex.EncodeToString(digest[:]))
	fmt.Println("Ed25519 signature size:", len(authorized.BaseStationSig), "bytes")

	if err := identity.VerifyAuthorizedCommand(
		publicKey,
		authorized,
		now,
	); err != nil {
		panic(err)
	}

	fmt.Println("Valid authorized command: ACCEPTED")

	tampered := authorized
	tampered.Command.Payload = []byte("LAND")

	err = identity.VerifyAuthorizedCommand(
		publicKey,
		tampered,
		now,
	)

	if err == nil {
		panic("tampered command was incorrectly accepted")
	}

	fmt.Println("Tampered command: REJECTED")
	fmt.Println("Reason:", err)
}
