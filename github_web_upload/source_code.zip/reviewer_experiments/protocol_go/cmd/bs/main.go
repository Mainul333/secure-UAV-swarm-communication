package main

import (
	"context"
	"flag"
	"fmt"
	"net"
	"os"
	"time"

	"uav-bft/internal/transport"
	"uav-bft/internal/wire"
)

func main() {
	targetText := flag.String(
		"target",
		"127.0.0.1:9100",
		"UAV node UDP address",
	)
	listenText := flag.String(
		"listen",
		"0.0.0.0:0",
		"base-station UDP listen address",
	)
	baseStationID := flag.Uint("id", 900, "base-station ID")
	receiverID := flag.Uint("receiver", 1, "UAV receiver ID")
	payload := flag.String(
		"payload",
		"MOVE:X=5,Y=5,Z=-5",
		"command payload",
	)
	timeout := flag.Duration("timeout", 5*time.Second, "reply timeout")
	flag.Parse()

	target, err := net.ResolveUDPAddr("udp", *targetText)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	endpoint, err := transport.ListenUDP(*listenText)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer endpoint.Close()

	envelope := wire.NetworkEnvelope{
		Type:       wire.MessageTypeCommand,
		SenderID:   uint32(*baseStationID),
		ReceiverID: uint32(*receiverID),
		Sequence:   1,
		Payload:    []byte(*payload),
	}
	encoded, err := wire.CanonicalBytes(envelope)
	if err != nil {
		panic(err)
	}

	ctx, cancel := context.WithTimeout(context.Background(), *timeout)
	defer cancel()
	if err := endpoint.Send(
		ctx,
		target,
		transport.Frame{
			Type:       wire.MessageTypeCommand,
			SenderID:   uint32(*baseStationID),
			ReceiverID: uint32(*receiverID),
			Sequence:   1,
			Payload:    encoded,
		},
	); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Println("command sent to", target)

	ackFrame, _, err := endpoint.Receive(ctx)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	var ack wire.NetworkEnvelope
	if err := wire.DecodeCanonical(ackFrame.Payload, &ack); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Printf(
		"ack type=%d sender=%d sequence=%d payload=%q\n",
		ack.Type,
		ack.SenderID,
		ack.Sequence,
		string(ack.Payload),
	)
}
