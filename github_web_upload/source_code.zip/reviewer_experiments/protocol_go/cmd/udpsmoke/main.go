package main

import (
	"context"
	"fmt"
	"time"

	"uav-bft/internal/transport"
	"uav-bft/internal/wire"
)

func main() {
	ctx, cancel := context.WithTimeout(
		context.Background(),
		3*time.Second,
	)
	defer cancel()

	baseStation, err := transport.ListenUDP("127.0.0.1:0")
	if err != nil {
		panic(err)
	}
	defer baseStation.Close()

	uavNode, err := transport.ListenUDP("127.0.0.1:0")
	if err != nil {
		panic(err)
	}
	defer uavNode.Close()

	envelope := wire.NetworkEnvelope{
		Type:       wire.MessageTypeCommand,
		SenderID:   900,
		ReceiverID: 1,
		Sequence:   1,
		Payload:    []byte("MOVE:X=5,Y=5,Z=-5"),
	}
	encodedEnvelope, err := wire.CanonicalBytes(envelope)
	if err != nil {
		panic(err)
	}

	if err := baseStation.Send(
		ctx,
		uavNode.LocalAddr(),
		transport.Frame{
			Type:       wire.MessageTypeCommand,
			SenderID:   900,
			ReceiverID: 1,
			Sequence:   1,
			Payload:    encodedEnvelope,
		},
	); err != nil {
		panic(err)
	}

	receivedFrame, remote, err := uavNode.Receive(ctx)
	if err != nil {
		panic(err)
	}
	var receivedEnvelope wire.NetworkEnvelope
	if err := wire.DecodeCanonical(
		receivedFrame.Payload,
		&receivedEnvelope,
	); err != nil {
		panic(err)
	}
	if receivedEnvelope.Sequence != 1 ||
		receivedEnvelope.ReceiverID != 1 {
		panic("decoded UDP envelope mismatch")
	}

	ackEnvelope := wire.NetworkEnvelope{
		Type:       wire.MessageTypeAcknowledgement,
		SenderID:   1,
		ReceiverID: 900,
		Sequence:   receivedEnvelope.Sequence,
		Payload:    []byte("ACK"),
	}
	encodedACK, err := wire.CanonicalBytes(ackEnvelope)
	if err != nil {
		panic(err)
	}
	if err := uavNode.Send(
		ctx,
		remote,
		transport.Frame{
			Type:       wire.MessageTypeAcknowledgement,
			SenderID:   1,
			ReceiverID: 900,
			Sequence:   receivedEnvelope.Sequence,
			Payload:    encodedACK,
		},
	); err != nil {
		panic(err)
	}

	ackFrame, _, err := baseStation.Receive(ctx)
	if err != nil {
		panic(err)
	}
	var decodedACK wire.NetworkEnvelope
	if err := wire.DecodeCanonical(ackFrame.Payload, &decodedACK); err != nil {
		panic(err)
	}
	if decodedACK.Type != wire.MessageTypeAcknowledgement {
		panic("acknowledgement type mismatch")
	}

	fmt.Println("UDP loopback frame encoding: PASSED")
	fmt.Println("CRC32 corruption check: COVERED BY TEST")
	fmt.Println("Canonical CBOR envelope decoding: PASSED")
	fmt.Println("Command payload bytes:", len(envelope.Payload))
	fmt.Println("Encoded envelope bytes:", len(encodedEnvelope))
}
