#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path


REQUIRED_SIZES = (4, 10, 20, 50, 100)


def extract(
    text: str,
    pattern: str,
    *,
    required: bool = True,
    default: str = "",
) -> str:
    match = re.search(pattern, text, flags=re.MULTILINE)

    if match:
        return match.group(1).strip()

    if required:
        raise ValueError(f"Could not find pattern: {pattern}")

    return default


def duration_to_ms(value: str) -> float:
    """Convert a Go duration string, such as 1m2.5s, into milliseconds."""

    value = value.strip()

    units_to_ms = {
        "ns": 1e-6,
        "µs": 1e-3,
        "μs": 1e-3,
        "us": 1e-3,
        "ms": 1.0,
        "s": 1000.0,
        "m": 60_000.0,
        "h": 3_600_000.0,
    }

    token_pattern = re.compile(
        r"([0-9]+(?:\.[0-9]+)?)(ns|µs|μs|us|ms|s|m|h)"
    )

    matches = list(token_pattern.finditer(value))

    if not matches:
        raise ValueError(f"Invalid Go duration: {value!r}")

    reconstructed = "".join(match.group(0) for match in matches)

    if reconstructed != value:
        raise ValueError(
            f"Duration contains unsupported text: {value!r}"
        )

    total_ms = 0.0

    for match in matches:
        amount = float(match.group(1))
        unit = match.group(2)
        total_ms += amount * units_to_ms[unit]

    return total_ms


def parse_integer_field(
    text: str,
    label: str,
    *,
    required: bool = True,
    default: int = 0,
) -> int:
    result = extract(
        text,
        rf"^{re.escape(label)}:\s*([0-9]+)",
        required=required,
        default=str(default),
    )
    return int(result)


def parse_duration_field(
    text: str,
    label: str,
    *,
    required: bool = True,
) -> float | None:
    result = extract(
        text,
        rf"^{re.escape(label)}:\s*(\S+)",
        required=required,
        default="",
    )

    if not result:
        return None

    return duration_to_ms(result)


def parse_log(path: Path) -> dict[str, object]:
    text = path.read_text(encoding="utf-8", errors="replace")

    node_count = parse_integer_field(text, "n")
    threshold = parse_integer_field(text, "t")
    fault_bound = (node_count - 1) // 3

    gjkr_passed = bool(
        re.search(r"^GJKR DKG:\s*PASSED\s*$", text, re.MULTILINE)
    )
    bls_passed = bool(
        re.search(r"^Threshold BLS:\s*PASSED\s*$", text, re.MULTILINE)
    )

    qual_text = extract(
        text,
        r"^QUAL:\s*\[([^\]]*)\]",
    )

    qual_members = [
        int(value)
        for value in re.findall(r"\d+", qual_text)
    ]

    expected_threshold = node_count - fault_bound

    if threshold != expected_threshold:
        raise ValueError(
            f"{path}: t={threshold}, expected {expected_threshold}"
        )

    if len(qual_members) != node_count:
        raise ValueError(
            f"{path}: QUAL size={len(qual_members)}, "
            f"expected {node_count}"
        )

    return {
        "n": node_count,
        "f": fault_bound,
        "t": threshold,
        "run": 1,
        "gjkr_status": "passed" if gjkr_passed else "failed",
        "threshold_bls_status": "passed" if bls_passed else "failed",
        "qual_size": len(qual_members),
        "dkg_ms": parse_duration_field(text, "DKG duration"),
        "deal_objects": parse_integer_field(text, "Deal objects"),
        "response_objects": parse_integer_field(
            text,
            "Response objects",
        ),
        "response_deliveries": parse_integer_field(
            text,
            "Response deliveries",
        ),
        "secret_commit_deliveries": parse_integer_field(
            text,
            "Secret-commit deliveries",
        ),
        "group_public_key_bytes": parse_integer_field(
            text,
            "Group public-key size",
        ),
        "partial_signature_bytes": parse_integer_field(
            text,
            "Partial-signature size",
        ),
        "recovered_signature_bytes": parse_integer_field(
            text,
            "Recovered-signature size",
        ),
        "partial_sign_verify_ms": parse_duration_field(
            text,
            "Partial sign+verify duration",
        ),
        "reconstruction_ms": parse_duration_field(
            text,
            "Reconstruction duration",
        ),
        "final_verification_ms": parse_duration_field(
            text,
            "Final verification duration",
        ),
        "source_log": str(path.resolve()),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input-dir",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
    )

    args = parser.parse_args()

    rows: list[dict[str, object]] = []
    missing: list[int] = []

    for node_count in REQUIRED_SIZES:
        path = args.input_dir / f"dkg_n{node_count}_run1.txt"

        if not path.is_file() or path.stat().st_size == 0:
            missing.append(node_count)
            continue

        try:
            row = parse_log(path)
        except Exception as exc:
            print(f"ERROR parsing {path}: {exc}", file=sys.stderr)
            return 1

        if row["n"] != node_count:
            print(
                f"ERROR: {path} contains n={row['n']}, "
                f"expected n={node_count}",
                file=sys.stderr,
            )
            return 1

        rows.append(row)

    if missing:
        print(
            "Missing result files for n="
            + ",".join(str(value) for value in missing),
            file=sys.stderr,
        )
        return 1

    rows.sort(key=lambda row: int(row["n"]))

    args.output.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "n",
        "f",
        "t",
        "run",
        "gjkr_status",
        "threshold_bls_status",
        "qual_size",
        "dkg_ms",
        "deal_objects",
        "response_objects",
        "response_deliveries",
        "secret_commit_deliveries",
        "group_public_key_bytes",
        "partial_signature_bytes",
        "recovered_signature_bytes",
        "partial_sign_verify_ms",
        "reconstruction_ms",
        "final_verification_ms",
        "source_log",
    ]

    with args.output.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as output_file:
        writer = csv.DictWriter(
            output_file,
            fieldnames=fieldnames,
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"Saved: {args.output.resolve()}")
    print("Included n values:", [row["n"] for row in rows])

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
