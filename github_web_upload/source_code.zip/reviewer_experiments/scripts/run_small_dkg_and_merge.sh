#!/usr/bin/env bash

set -euo pipefail

ROOT="$HOME/uav_bft/reviewer_experiments"
PROTOCOL="$ROOT/protocol_go"
RAW="$ROOT/results/raw/dkg_runs"
PROCESSED="$ROOT/results/processed"
LOGS="$ROOT/results/logs"

mkdir -p "$RAW" "$PROCESSED" "$LOGS"

cd "$PROTOCOL"

echo "Building dkgdemo..."
mkdir -p bin
go build -trimpath -o bin/dkgdemo ./cmd/dkgdemo

run_case() {
    local n="$1"
    local t="$2"

    local result_file="$RAW/dkg_n${n}_run1.txt"
    local resource_file="$RAW/dkg_n${n}_run1.resources.txt"

    if [[ -s "$result_file" ]]; then
        echo "Existing nonempty result found for n=$n; skipping."
        return
    fi

    echo
    echo "Starting n=$n, t=$t"

    set -o pipefail

    /usr/bin/time \
        -f $'wall_seconds=%e\nmax_rss_kb=%M\ncpu_percent=%P' \
        -o "$resource_file" \
        ./bin/dkgdemo -n "$n" -t "$t" \
        2>&1 | tee "$result_file"

    echo "Completed n=$n"
}

# Run only the three small cases.
run_case 4 3
run_case 10 7
run_case 20 14

# n=50 and n=100 must already exist from the completed runs.
for n in 50 100; do
    file="$RAW/dkg_n${n}_run1.txt"

    if [[ ! -s "$file" ]]; then
        echo
        echo "Missing saved existing result: $file" >&2
        echo "Copy the previous n=$n terminal output into that file." >&2
        exit 1
    fi
done

python3 "$ROOT/scripts/merge_dkg_results.py" \
    --input-dir "$RAW" \
    --output \
    "$PROCESSED/dkg_scaling_n4_10_20_50_100.csv"

echo
echo "Final combined table:"
column -s, -t \
    < "$PROCESSED/dkg_scaling_n4_10_20_50_100.csv"

echo
echo "The n=50 and n=100 cases were not rerun."
